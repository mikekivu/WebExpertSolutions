import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect } from "react";
import { queryClient } from "./lib/queryClient";
import { initGA } from "./lib/analytics";
import { useAnalytics } from "./hooks/use-analytics";

// Pages
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import NotFound from "@/pages/not-found";
import { WebsitePackages } from "@/pages/WebsitePackages";
import HostingPackages from "@/pages/HostingPackages";
import MobileAppDevelopment from "@/pages/MobileAppDevelopment";
import SoftwareDevelopment from "@/pages/SoftwareDevelopment";
import DomainRegistration from "@/pages/DomainRegistration";
import BulkSMS from "@/pages/BulkSMS";
import DigitalMarketing from "@/pages/DigitalMarketing";
import Contact from "@/pages/Contact";
import Portfolio from "@/pages/Portfolio";
import AboutUs from "@/pages/AboutUs";
import QuoteRequest from "@/pages/QuoteRequest";

// Client Pages
import ClientDashboard from "@/pages/client/Dashboard";
import ClientServices from "@/pages/client/Services";
import ClientInvoices from "@/pages/client/Invoices";
import ClientProfile from "@/pages/client/Profile";
import ClientSettings from "@/pages/client/Settings";
import Support from "@/pages/client/Support";

// Admin Pages
import AdminDashboard from "@/pages/admin/Dashboard";
import AdminClients from "@/pages/admin/Clients";
import AdminQuotes from "@/pages/admin/Quotes";
import AdminInvoices from "@/pages/admin/Invoices";
import AdminPortfolio from "@/pages/admin/Portfolio";
import AdminEmailClients from "@/pages/admin/EmailClients";
import AdminWebPackages from "@/pages/admin/WebPackages";
import AdminHostingPackages from "@/pages/admin/HostingPackages";
import AdminMobileApps from "@/pages/admin/MobileApps";
import AdminSoftwareSolutions from "@/pages/admin/SoftwareSolutions";
import AdminDomainManagement from "@/pages/admin/DomainManagement";
import AdminBulkSMSManagement from "@/pages/admin/BulkSMSManagement";
import AdminDigitalMarketingManagement from "@/pages/admin/DigitalMarketingManagement";
import AnalyticsDashboard from "@/pages/admin/AnalyticsDashboard";
import BillingPlans from "@/pages/admin/BillingPlans";
import ReminderTemplates from "@/pages/admin/ReminderTemplates";
import RecurringInvoices from "@/pages/admin/RecurringInvoices";
import CreateRecurringInvoice from "@/pages/admin/CreateRecurringInvoice";
import ContactSettings from "@/pages/admin/ContactSettings";
import AboutUsSettings from "@/pages/admin/AboutUsSettings";
import ContentSettings from "@/pages/admin/ContentSettings";
import Settings from "@/pages/admin/Settings";

import { TawkChat } from "@/components/TawkChat";
import { BackToTop } from "@/components/BackToTop";

function Router() {
  const [location] = useLocation();
  
  // Track page views when routes change
  useAnalytics();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <Switch>
      {/* Public Pages */}
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/website-packages" component={WebsitePackages} />
      <Route path="/hosting-packages" component={HostingPackages} />
      <Route path="/mobile-app-development" component={MobileAppDevelopment} />
      <Route path="/software-development" component={SoftwareDevelopment} />
      <Route path="/domain-registration" component={DomainRegistration} />
      <Route path="/bulk-sms" component={BulkSMS} />
      <Route path="/digital-marketing" component={DigitalMarketing} />
      <Route path="/contact" component={Contact} />
      <Route path="/contact/quote" component={QuoteRequest} />
      <Route path="/portfolio" component={Portfolio} />
      <Route path="/about-us" component={AboutUs} />
      
      {/* Client Pages */}
      <Route path="/client/dashboard" component={ClientDashboard} />
      <Route path="/client/services" component={ClientServices} />
      <Route path="/client/invoices" component={ClientInvoices} />
      <Route path="/client/profile" component={ClientProfile} />
      <Route path="/client/settings" component={ClientSettings} />
      <Route path="/client/support" component={Support} />
      
      {/* Admin Pages */}
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/clients" component={AdminClients} />
      <Route path="/admin/quotes" component={AdminQuotes} />
      <Route path="/admin/invoices" component={AdminInvoices} />
      <Route path="/admin/portfolio" component={AdminPortfolio} />
      <Route path="/admin/email-clients" component={AdminEmailClients} />
      <Route path="/admin/web-packages" component={AdminWebPackages} />
      <Route path="/admin/hosting-packages" component={AdminHostingPackages} />
      <Route path="/admin/mobile-apps" component={AdminMobileApps} />
      <Route path="/admin/software-solutions" component={AdminSoftwareSolutions} />
      <Route path="/admin/domain-management" component={AdminDomainManagement} />
      <Route path="/admin/bulk-sms" component={AdminBulkSMSManagement} />
      <Route path="/admin/digital-marketing" component={AdminDigitalMarketingManagement} />
      <Route path="/admin/analytics" component={AnalyticsDashboard} />
      <Route path="/admin/billing-plans" component={BillingPlans} />
      <Route path="/admin/reminder-templates" component={ReminderTemplates} />
      <Route path="/admin/recurring-invoices" component={RecurringInvoices} />
      <Route path="/admin/invoices/create" component={CreateRecurringInvoice} />
      <Route path="/admin/content-settings" component={ContentSettings} />
      <Route path="/admin/contact-settings" component={ContactSettings} />
      <Route path="/admin/about-us-settings" component={AboutUsSettings} />
      <Route path="/admin/settings" component={Settings} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Initialize Google Analytics when app loads
  useEffect(() => {
    // Verify required environment variable is present
    if (!import.meta.env.VITE_GA_MEASUREMENT_ID) {
      console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    } else {
      initGA();
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
        <TawkChat />
        <BackToTop />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
