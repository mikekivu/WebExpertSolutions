/**
 * M-Pesa Payment Integration Helper Functions
 * 
 * This library provides functions to interact with the M-Pesa payment API for
 * processing mobile payments in Kenya. In a real implementation, these functions
 * would interact with the actual M-Pesa API endpoints.
 */

interface MpesaPaymentResponse {
  success: boolean;
  transactionId?: string;
  message: string;
}

interface MpesaPaymentRequest {
  phone: string;
  amount: number;
  accountReference?: string;
  description?: string;
}

/**
 * Initiates an M-Pesa STK push payment request to a user's phone
 * 
 * @param {MpesaPaymentRequest} paymentDetails - The payment details
 * @returns {Promise<MpesaPaymentResponse>} - The payment response
 */
export async function initiateMpesaPayment(paymentDetails: MpesaPaymentRequest): Promise<MpesaPaymentResponse> {
  try {
    // Validate phone number (should be in format 254XXXXXXXXX)
    const phoneRegex = /^254\d{9}$/;
    let phone = paymentDetails.phone.replace(/\s/g, "");
    
    // If phone starts with 0, replace with 254
    if (phone.startsWith("0")) {
      phone = "254" + phone.substring(1);
    }
    
    // If phone starts with +254, remove the +
    if (phone.startsWith("+254")) {
      phone = phone.substring(1);
    }
    
    if (!phoneRegex.test(phone)) {
      return {
        success: false,
        message: "Invalid phone number format. Use format: 254XXXXXXXXX"
      };
    }
    
    // Validate amount (should be positive number)
    if (paymentDetails.amount <= 0) {
      return {
        success: false,
        message: "Amount must be greater than zero"
      };
    }
    
    // In a real implementation, you would make an API call to the M-Pesa API here
    // For demonstration purposes, we'll simulate a successful payment
    const transactionId = `MPESA${Date.now()}`;
    
    return {
      success: true,
      transactionId,
      message: "Payment initiated successfully. Please check your phone to complete the transaction."
    };
  } catch (error) {
    console.error("M-Pesa payment error:", error);
    return {
      success: false,
      message: error instanceof Error ? error.message : "An unknown error occurred"
    };
  }
}

/**
 * Checks the status of an M-Pesa transaction
 * 
 * @param {string} transactionId - The M-Pesa transaction ID
 * @returns {Promise<MpesaPaymentResponse>} - The transaction status response
 */
export async function checkMpesaTransactionStatus(transactionId: string): Promise<MpesaPaymentResponse> {
  try {
    // In a real implementation, you would make an API call to the M-Pesa API to check the status
    // For demonstration purposes, we'll simulate a successful check
    
    return {
      success: true,
      transactionId,
      message: "Transaction completed successfully"
    };
  } catch (error) {
    console.error("M-Pesa status check error:", error);
    return {
      success: false,
      message: error instanceof Error ? error.message : "An unknown error occurred"
    };
  }
}

/**
 * Validates an M-Pesa phone number and formats it correctly
 * 
 * @param {string} phoneNumber - The phone number to validate and format
 * @returns {string} - The formatted phone number or an empty string if invalid
 */
export function formatMpesaPhoneNumber(phoneNumber: string): string {
  // Remove spaces and special characters
  let phone = phoneNumber.replace(/[\s-]/g, "");
  
  // If phone starts with 0, replace with 254
  if (phone.startsWith("0")) {
    phone = "254" + phone.substring(1);
  }
  
  // If phone starts with +254, remove the +
  if (phone.startsWith("+254")) {
    phone = phone.substring(1);
  }
  
  // Check if the phone number is valid
  const phoneRegex = /^254\d{9}$/;
  if (!phoneRegex.test(phone)) {
    return "";
  }
  
  return phone;
}
