import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { useLocation } from "wouter";

interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: string;
}

interface Session {
  authenticated: boolean;
  user?: User;
}

// Custom hook to check if user is authenticated
export function useAuth() {
  const { data: session, isLoading, error } = useQuery<Session>({
    queryKey: ["/api/auth/session"],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  return {
    isAuthenticated: session?.authenticated || false,
    user: session?.user,
    isLoading,
    error,
  };
}

// Custom hook to require authentication
export function useRequireAuth(redirectTo = "/login") {
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation(redirectTo);
    }
  }, [isAuthenticated, isLoading, redirectTo, setLocation]);

  return { isLoading, isAuthenticated };
}

// Custom hook to require admin role
export function useRequireAdmin(redirectTo = "/") {
  const { isAuthenticated, user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        setLocation("/login");
      } else if (user?.role !== "admin") {
        setLocation(redirectTo);
      }
    }
  }, [isAuthenticated, isLoading, user, redirectTo, setLocation]);

  return { isLoading, isAdmin: user?.role === "admin" };
}

// Custom hook to check if user is logged in and redirect if already authenticated
export function useRedirectIfAuthenticated(redirectTo = "/") {
  const { isAuthenticated, user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      if (user?.role === "admin") {
        setLocation("/admin/dashboard");
      } else {
        setLocation(redirectTo);
      }
    }
  }, [isAuthenticated, isLoading, user, redirectTo, setLocation]);

  return { isLoading };
}
