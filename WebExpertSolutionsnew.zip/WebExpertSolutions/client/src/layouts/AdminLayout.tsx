import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { AdminSidebar } from "@/components/admin/AdminSidebar";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";

interface AdminLayoutProps {
  children: React.ReactNode;
}

export function AdminLayout({ children }: AdminLayoutProps) {
  const [, setLocation] = useLocation();
  const [isExpanded, setIsExpanded] = useState(true);
  
  // Handle sidebar toggle
  const toggleSidebar = () => {
    setIsExpanded(!isExpanded);
  };
  
  // Check session for authentication and admin role
  const { data: session, isLoading } = useQuery({
    queryKey: ["/api/auth/session"],
  });

  useEffect(() => {
    if (!isLoading) {
      const isAuthenticated = session?.authenticated;
      const isAdmin = session?.user?.role === "admin";

      if (!isAuthenticated) {
        setLocation("/login");
      } else if (!isAdmin) {
        setLocation("/client/dashboard");
      }
    }
  }, [session, isLoading, setLocation]);

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  // Don't render the layout if not authenticated or not admin
  if (!session?.authenticated || session?.user?.role !== "admin") {
    return null;
  }

  return (
    <>
      <Helmet>
        <title>Admin Dashboard | Web Expert Solutions</title>
      </Helmet>
      
      <div className="flex h-screen bg-gray-50">
        <AdminSidebar isExpanded={isExpanded} toggleExpanded={toggleSidebar} />
        
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </>
  );
}
