import { Helmet } from "react-helmet";
import { Separator } from "@/components/ui/separator";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { QuoteRequestForm } from "@/components/QuoteRequestForm";
import { Button } from "@/components/ui/button";
import { Globe, Shield, Search, BarChart, Layers, Link, CheckCircle, XCircle } from "lucide-react";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";

export default function DomainRegistration() {
  const [domainName, setDomainName] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const checkDomainAvailability = () => {
    if (!domainName.trim()) return;
    
    setIsSearching(true);
    setHasSearched(true);

    // Simulate API call with setTimeout
    setTimeout(() => {
      const extensions = ['.com', '.org', '.net', '.co.ke', '.ke', '.info'];
      const results = extensions.map(ext => ({
        domain: `${domainName.toLowerCase()}${ext}`,
        available: Math.random() > 0.5, // Random availability for demo
        price: ext === '.com' ? 1200 : ext === '.org' ? 1500 : ext === '.net' ? 1400 : ext === '.co.ke' ? 900 : ext === '.ke' ? 1200 : 1000
      }));
      
      setSearchResults(results);
      setIsSearching(false);
    }, 1000);
  };
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Domain Registration | Web Expert Solutions</title>
        <meta 
          name="description" 
          content="Register, transfer, and manage domain names with Web Expert Solutions. Secure your online identity with domain registration services and expert support." 
        />
        <meta property="og:title" content="Domain Registration | Web Expert Solutions" />
        <meta 
          property="og:description" 
          content="Register, transfer, and manage domain names with Web Expert Solutions. Secure your online identity with domain registration services and expert support." 
        />
        <meta property="og:type" content="website" />
      </Helmet>

      <Header />

      <main className="flex-grow">
        <section className="bg-gradient-to-b from-slate-50 to-white py-12 md:py-24">
          <div className="container px-4 mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Domain Registration Services</h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-12">
              Secure your online identity with our domain registration services. We provide hassle-free domain 
              registration, transfers, and management with competitive pricing and expert support.
            </p>
            <div className="max-w-xl mx-auto bg-white rounded-lg shadow-md p-6 mb-8">
              <h2 className="text-xl font-semibold mb-4">Check Domain Availability</h2>
              <div className="flex flex-col sm:flex-row gap-2">
                <input 
                  type="text" 
                  placeholder="Enter your domain name..." 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  value={domainName}
                  onChange={(e) => setDomainName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && checkDomainAvailability()}
                />
                <Button 
                  className="whitespace-nowrap" 
                  onClick={checkDomainAvailability}
                  disabled={isSearching || !domainName.trim()}
                >
                  {isSearching ? "Searching..." : "Check Availability"}
                </Button>
              </div>
              
              {hasSearched && (
                <div className="mt-6">
                  {isSearching ? (
                    <div className="flex justify-center items-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                    </div>
                  ) : (
                    <>
                      <h3 className="font-semibold mb-3">Search Results:</h3>
                      <div className="bg-slate-50 rounded-lg p-4">
                        <div className="overflow-x-auto">
                          <table className="w-full">
                            <thead className="border-b">
                              <tr>
                                <th className="text-left py-2 px-4">Domain</th>
                                <th className="text-left py-2 px-4">Status</th>
                                <th className="text-left py-2 px-4">Price (KSh/year)</th>
                                <th className="text-left py-2 px-4">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {searchResults.map((result, index) => (
                                <tr key={index} className={index !== searchResults.length - 1 ? "border-b" : ""}>
                                  <td className="py-3 px-4 font-medium">{result.domain}</td>
                                  <td className="py-3 px-4">
                                    {result.available ? (
                                      <div className="flex items-center">
                                        <CheckCircle className="h-4 w-4 text-green-500 mr-1.5" />
                                        <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-100 border-green-200">
                                          Available
                                        </Badge>
                                      </div>
                                    ) : (
                                      <div className="flex items-center">
                                        <XCircle className="h-4 w-4 text-red-500 mr-1.5" />
                                        <Badge variant="outline" className="bg-red-50 text-red-700 hover:bg-red-100 border-red-200">
                                          Taken
                                        </Badge>
                                      </div>
                                    )}
                                  </td>
                                  <td className="py-3 px-4">{result.price.toLocaleString()}</td>
                                  <td className="py-3 px-4">
                                    {result.available && (
                                      <Button size="sm" variant="outline" asChild>
                                        <a href="#contact-us">Register</a>
                                      </Button>
                                    )}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <a href="#contact-us">Register a Domain</a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#domain-services">Our Services</a>
              </Button>
            </div>
          </div>
        </section>

        <section id="domain-services" className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Our Domain Services</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                We provide comprehensive domain registration and management services to secure your online presence.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
              <div className="bg-slate-50 p-8 rounded-lg">
                <Globe className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Domain Registration</h3>
                <p className="text-muted-foreground">
                  Register new domains with a wide range of TLDs including .com, .org, .net, .co.ke, and many more.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Link className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Domain Transfer</h3>
                <p className="text-muted-foreground">
                  Transfer your existing domains to us for better management, pricing, and support services.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Layers className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Domain Management</h3>
                <p className="text-muted-foreground">
                  Easily manage DNS records, forwarding, subdomains, and other settings through our user-friendly dashboard.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Shield className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Domain Privacy</h3>
                <p className="text-muted-foreground">
                  Protect your personal information with domain privacy services that shield your details from public WHOIS searches.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <BarChart className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Domain Monitoring</h3>
                <p className="text-muted-foreground">
                  Continuous monitoring of your domain expiration, DNS health, and security to ensure uninterrupted service.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Search className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Domain Consultation</h3>
                <p className="text-muted-foreground">
                  Expert advice on domain strategy, branding, and selection to maximize your online visibility.
                </p>
              </div>
            </div>
          </div>
        </section>

        <Separator />

        <section className="py-16 bg-slate-50">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Domain Pricing</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                Competitive pricing for domain registration and renewals across popular TLDs.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full bg-white rounded-lg shadow-sm">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="p-4 text-left">Domain Extension</th>
                    <th className="p-4 text-left">Registration</th>
                    <th className="p-4 text-left">Renewal</th>
                    <th className="p-4 text-left">Transfer</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="p-4">.com</td>
                    <td className="p-4">Ksh 1,200/year</td>
                    <td className="p-4">Ksh 1,200/year</td>
                    <td className="p-4">Ksh 1,200/year</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">.org</td>
                    <td className="p-4">Ksh 1,500/year</td>
                    <td className="p-4">Ksh 1,500/year</td>
                    <td className="p-4">Ksh 1,500/year</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">.net</td>
                    <td className="p-4">Ksh 1,400/year</td>
                    <td className="p-4">Ksh 1,400/year</td>
                    <td className="p-4">Ksh 1,400/year</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">.co.ke</td>
                    <td className="p-4">Ksh 900/year</td>
                    <td className="p-4">Ksh 900/year</td>
                    <td className="p-4">Ksh 900/year</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">.ke</td>
                    <td className="p-4">Ksh 1,200/year</td>
                    <td className="p-4">Ksh 1,200/year</td>
                    <td className="p-4">Ksh 1,200/year</td>
                  </tr>
                  <tr>
                    <td className="p-4">.info</td>
                    <td className="p-4">Ksh 1,000/year</td>
                    <td className="p-4">Ksh 1,000/year</td>
                    <td className="p-4">Ksh 1,000/year</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-center text-sm text-muted-foreground mt-4">
              Contact us for pricing on other TLDs or bulk domain registrations.
            </p>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold mb-6">Why Choose Us for Domain Services?</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  We provide reliable domain registration services with competitive pricing, professional management, and exceptional support.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Competitive pricing with no hidden fees</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Free domain with hosting package purchases</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Easy-to-use domain management dashboard</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Expert technical support available 24/7</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Automated renewal system with early notifications</p>
                  </div>
                </div>
              </div>
              <div id="contact-us">
                <QuoteRequestForm serviceType="domain" />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}