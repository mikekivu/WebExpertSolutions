import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Helmet } from "react-helmet";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { PortfolioItem } from "@/components/PortfolioItem";
import type { PortfolioItemType } from "@/components/Portfolio";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Portfolio() {
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  
  // Fetch portfolio items from the API
  const { data: portfolioItems = [], isLoading } = useQuery<PortfolioItemType[]>({
    queryKey: ["/api/portfolio"],
  });

  // Get unique categories
  const categories = Array.from(
    new Set(portfolioItems.map((item) => item.category))
  );

  // Filter items by category
  const filteredItems = categoryFilter === "all" 
    ? portfolioItems 
    : portfolioItems.filter((item) => item.category === categoryFilter);

  return (
    <>
      <Helmet>
        <title>Our Portfolio - Web Expert Solutions</title>
        <meta 
          name="description" 
          content="Explore our portfolio of web development, mobile apps, custom software, and digital marketing projects. View our work and see how we can help your business succeed."
        />
      </Helmet>
      
      <div className="flex flex-col min-h-screen">
        <Header />
        
        <main className="flex-grow">
          <section className="bg-gradient-to-b from-primary/10 to-white py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-12">
                <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Portfolio</h1>
                <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                  Explore our diverse range of projects spanning web development, mobile apps,
                  custom software solutions, and digital marketing campaigns.
                </p>
              </div>
            </div>
          </section>
          
          <section className="py-12">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col md:flex-row justify-between items-center mb-8">
                <h2 className="text-2xl font-bold mb-4 md:mb-0">Our Recent Projects</h2>
                
                <div className="w-full md:w-auto">
                  <Select 
                    value={categoryFilter} 
                    onValueChange={(value) => setCategoryFilter(value)}
                  >
                    <SelectTrigger className="w-full md:w-[200px]">
                      <SelectValue placeholder="Filter by category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Projects</SelectItem>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              {isLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                  {[1, 2, 3, 4, 5, 6].map((item) => (
                    <div key={item} className="rounded-lg overflow-hidden shadow-md bg-white h-80 animate-pulse">
                      <div className="w-full h-48 bg-gray-300"></div>
                      <div className="p-6">
                        <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-full mb-3"></div>
                        <div className="flex flex-wrap gap-2">
                          <div className="h-3 bg-blue-100 rounded-full w-16"></div>
                          <div className="h-3 bg-blue-100 rounded-full w-20"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredItems.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-lg text-muted-foreground mb-4">No projects found in this category.</p>
                  <Button onClick={() => setCategoryFilter("all")}>View All Projects</Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                  {filteredItems.map((item) => (
                    <PortfolioItem key={item.id} item={item} />
                  ))}
                </div>
              )}
            </div>
          </section>
          
          <section className="bg-gray-50 py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="max-w-3xl mx-auto text-center">
                <h2 className="text-3xl font-bold mb-6">Have a Project in Mind?</h2>
                <p className="text-lg text-muted-foreground mb-8">
                  Let's discuss how we can help bring your vision to life. Our team of experts is ready to 
                  create custom solutions tailored to your business needs.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
                    <a href="/contact">Get in Touch</a>
                  </Button>
                  <Button asChild variant="outline" size="lg">
                    <a href="/website-packages">View Our Services</a>
                  </Button>
                </div>
              </div>
            </div>
          </section>
        </main>
        
        <Footer />
      </div>
    </>
  );
}