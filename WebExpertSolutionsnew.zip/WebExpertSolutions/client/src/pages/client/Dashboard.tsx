import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { ClientLayout } from "@/layouts/ClientLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Helmet } from "react-helmet";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, Server, Database, MessageSquare, CreditCard } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function ClientDashboard() {
  const { data: session } = useQuery({
    queryKey: ["/api/auth/session"],
  });

  const userId = session?.user?.id;
  
  const { data: services = [], isLoading: isLoadingServices } = useQuery({
    queryKey: ["/api/client-services/user/" + userId],
    enabled: !!userId,
  });
  
  const { data: invoices = [], isLoading: isLoadingInvoices } = useQuery({
    queryKey: ["/api/invoices/user/" + userId],
    enabled: !!userId,
  });

  const unpaidInvoices = invoices.filter((invoice: any) => invoice.status === "unpaid" || invoice.status === "overdue");
  const activeServices = services.filter((service: any) => service.status === "active");

  return (
    <>
      <Helmet>
        <title>Dashboard | Client Portal | Web Expert Solutions</title>
        <meta name="description" content="Manage your Web Expert Solutions services, invoices, and account from your client dashboard" />
      </Helmet>
      
      <ClientLayout>
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-gray-500">
              Welcome back, {session?.user?.fullName || "Client"}
            </p>
          </div>

          {unpaidInvoices.length > 0 && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Attention Required</AlertTitle>
              <AlertDescription>
                You have {unpaidInvoices.length} unpaid {unpaidInvoices.length === 1 ? "invoice" : "invoices"}. Please review your invoices and make payments.
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Active Services
                </CardTitle>
                <Server className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{activeServices.length}</div>
                <p className="text-xs text-muted-foreground">
                  {activeServices.length === 0 ? "No active services" : `${activeServices.length} service${activeServices.length === 1 ? "" : "s"} in your account`}
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/client/services" className="text-sm text-primary hover:underline">
                  View all services
                </Link>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Invoices
                </CardTitle>
                <CreditCard className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{invoices.length}</div>
                <p className="text-xs text-muted-foreground">
                  {unpaidInvoices.length > 0 ? `${unpaidInvoices.length} unpaid invoice${unpaidInvoices.length === 1 ? "" : "s"}` : "All invoices paid"}
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/client/invoices" className="text-sm text-primary hover:underline">
                  View all invoices
                </Link>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Support
                </CardTitle>
                <MessageSquare className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">24/7</div>
                <p className="text-xs text-muted-foreground">
                  Support available via live chat or email
                </p>
              </CardContent>
              <CardFooter>
                <span className="text-sm text-primary cursor-pointer hover:underline" onClick={() => window.Tawk_API.toggle()}>
                  Start a chat
                </span>
              </CardFooter>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Services</CardTitle>
                <CardDescription>
                  Overview of your currently active services
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingServices ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-gray-200 animate-pulse"></div>
                        <div className="space-y-2 flex-1">
                          <div className="h-4 bg-gray-200 rounded w-1/3 animate-pulse"></div>
                          <div className="h-3 bg-gray-200 rounded w-full animate-pulse"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : services.length === 0 ? (
                  <div className="text-center py-4">
                    <p className="text-muted-foreground mb-4">You don't have any services yet.</p>
                    <Button asChild>
                      <Link href="/#services">Browse Services</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {services.slice(0, 5).map((service: any) => (
                      <div key={service.id} className="flex flex-col space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Database className="h-5 w-5 text-primary" />
                            <span className="font-medium">{service.name || "Service"}</span>
                          </div>
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            service.status === "active" ? "bg-green-100 text-green-800" :
                            service.status === "expired" ? "bg-red-100 text-red-800" :
                            "bg-yellow-100 text-yellow-800"
                          }`}>
                            {service.status}
                          </span>
                        </div>
                        <div className="text-sm text-gray-500">
                          {service.startDate ? new Date(service.startDate).toLocaleDateString() : "N/A"} - 
                          {service.endDate ? new Date(service.endDate).toLocaleDateString() : "N/A"}
                        </div>
                        {service.endDate && (
                          <Progress 
                            value={
                              Math.max(0, Math.min(100, 
                                ((new Date().getTime() - new Date(service.startDate).getTime()) / 
                                (new Date(service.endDate).getTime() - new Date(service.startDate).getTime())) * 100
                              ))
                            } 
                            className="h-2" 
                          />
                        )}
                      </div>
                    ))}
                    {services.length > 5 && (
                      <div className="pt-2 text-center">
                        <Link href="/client/services" className="text-primary hover:underline text-sm">
                          View all services
                        </Link>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Invoices</CardTitle>
                <CardDescription>
                  Review your recent invoices and payment status
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingInvoices ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center gap-4">
                        <div className="space-y-2 flex-1">
                          <div className="h-4 bg-gray-200 rounded w-1/3 animate-pulse"></div>
                          <div className="h-3 bg-gray-200 rounded w-full animate-pulse"></div>
                        </div>
                        <div className="h-6 w-20 bg-gray-200 rounded animate-pulse"></div>
                      </div>
                    ))}
                  </div>
                ) : invoices.length === 0 ? (
                  <div className="text-center py-4">
                    <p className="text-muted-foreground">You don't have any invoices yet.</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {invoices.slice(0, 5).map((invoice: any) => (
                      <div key={invoice.id} className="flex items-center justify-between py-2">
                        <div>
                          <div className="font-medium">{invoice.invoiceNumber}</div>
                          <div className="text-sm text-gray-500">
                            Due: {new Date(invoice.dueDate).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <div className="font-medium">KES {invoice.amount}</div>
                            <div className={`text-xs px-2 py-1 rounded-full ${
                              invoice.status === "paid" ? "bg-green-100 text-green-800" :
                              invoice.status === "overdue" ? "bg-red-100 text-red-800" :
                              "bg-yellow-100 text-yellow-800"
                            }`}>
                              {invoice.status}
                            </div>
                          </div>
                          <Link href={`/client/invoices`}>
                            <Button variant="outline" size="sm">View</Button>
                          </Link>
                        </div>
                      </div>
                    ))}
                    {invoices.length > 5 && (
                      <div className="pt-2 text-center">
                        <Link href="/client/invoices" className="text-primary hover:underline text-sm">
                          View all invoices
                        </Link>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </ClientLayout>
    </>
  );
}
