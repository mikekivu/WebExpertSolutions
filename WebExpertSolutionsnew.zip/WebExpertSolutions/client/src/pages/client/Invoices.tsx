import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ClientLayout } from "@/layouts/ClientLayout";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, AlertCircle, CheckCircle, Clock, Download } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { format } from "date-fns";
import PayPalButton from "@/components/PayPalButton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface Invoice {
  id: number;
  userId: number;
  quoteId?: number;
  invoiceNumber: string;
  items: InvoiceItem[];
  amount: string;
  tax?: string;
  status: "unpaid" | "paid" | "overdue" | "cancelled";
  dueDate: string;
  createdAt: string;
}

interface InvoiceItem {
  description: string;
  quantity: number;
  unitPrice: string;
  total: string;
}

export default function ClientInvoices() {
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<"mpesa" | "paypal">("mpesa");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);

  const { data: session } = useQuery({
    queryKey: ["/api/auth/session"],
  });

  const userId = session?.user?.id;
  
  const { data: invoices = [], isLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices/user/" + userId],
    enabled: !!userId,
  });

  const payWithMpesa = useMutation({
    mutationFn: async () => {
      if (!selectedInvoice) return;
      
      const response = await apiRequest("POST", "/api/payments/mpesa", {
        invoiceId: selectedInvoice.id,
        phone: phoneNumber,
        amount: selectedInvoice.amount
      });
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment successful",
        description: "Your payment has been processed successfully.",
      });
      setIsPaymentDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/invoices/user/" + userId] });
    },
    onError: (error) => {
      toast({
        title: "Payment failed",
        description: error.message || "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const categorizedInvoices = {
    all: invoices,
    unpaid: invoices.filter(invoice => invoice.status === "unpaid" || invoice.status === "overdue"),
    paid: invoices.filter(invoice => invoice.status === "paid"),
    overdue: invoices.filter(invoice => invoice.status === "overdue"),
  };

  const getStatusBadge = (status: string) => {
    switch(status) {
      case "paid":
        return <Badge className="bg-green-500">Paid</Badge>;
      case "overdue":
        return <Badge variant="destructive">Overdue</Badge>;
      case "cancelled":
        return <Badge variant="outline">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">Unpaid</Badge>;
    }
  };

  const handlePayment = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setIsPaymentDialogOpen(true);
  };

  const handleMpesaPayment = () => {
    if (!phoneNumber) {
      toast({
        title: "Phone number required",
        description: "Please enter your M-Pesa phone number",
        variant: "destructive"
      });
      return;
    }
    
    payWithMpesa.mutate();
  };

  return (
    <>
      <Helmet>
        <title>My Invoices | Client Portal | Web Expert Solutions</title>
        <meta name="description" content="View and pay your Web Expert Solutions invoices" />
      </Helmet>
      
      <ClientLayout>
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">My Invoices</h1>
            <p className="text-gray-500">
              View and manage all your invoices
            </p>
          </div>

          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Invoices</TabsTrigger>
              <TabsTrigger value="unpaid">Unpaid</TabsTrigger>
              <TabsTrigger value="paid">Paid</TabsTrigger>
              <TabsTrigger value="overdue">Overdue</TabsTrigger>
            </TabsList>
            
            {Object.entries(categorizedInvoices).map(([category, invoices]) => (
              <TabsContent key={category} value={category} className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {category === "all" ? "All Invoices" : 
                       category === "unpaid" ? "Unpaid Invoices" : 
                       category === "paid" ? "Paid Invoices" : 
                       "Overdue Invoices"}
                    </CardTitle>
                    <CardDescription>
                      {category === "all" ? "View all your invoices" : 
                       category === "unpaid" ? "Invoices that require payment" : 
                       category === "paid" ? "Successfully paid invoices" : 
                       "Invoices past their due date"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="space-y-4">
                        {[1, 2, 3].map((i) => (
                          <div key={i} className="animate-pulse flex items-center gap-4 py-4">
                            <div className="flex-1">
                              <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                              <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                            </div>
                            <div className="h-6 w-16 bg-gray-200 rounded"></div>
                            <div className="h-6 w-20 bg-gray-200 rounded"></div>
                            <div className="h-8 w-20 bg-gray-200 rounded"></div>
                          </div>
                        ))}
                      </div>
                    ) : invoices.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-8 text-center">
                        {category === "all" ? (
                          <>
                            <FileText className="h-12 w-12 text-gray-400 mb-4" />
                            <h3 className="text-lg font-medium mb-2">No invoices yet</h3>
                            <p className="text-sm text-gray-500">
                              You don't have any invoices at the moment.
                            </p>
                          </>
                        ) : category === "unpaid" ? (
                          <>
                            <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
                            <h3 className="text-lg font-medium mb-2">All caught up!</h3>
                            <p className="text-sm text-gray-500">
                              You don't have any unpaid invoices.
                            </p>
                          </>
                        ) : category === "overdue" ? (
                          <>
                            <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
                            <h3 className="text-lg font-medium mb-2">No overdue invoices</h3>
                            <p className="text-sm text-gray-500">
                              You don't have any overdue invoices.
                            </p>
                          </>
                        ) : (
                          <>
                            <Clock className="h-12 w-12 text-gray-400 mb-4" />
                            <h3 className="text-lg font-medium mb-2">No paid invoices</h3>
                            <p className="text-sm text-gray-500">
                              You haven't paid any invoices yet.
                            </p>
                          </>
                        )}
                      </div>
                    ) : (
                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Invoice</TableHead>
                              <TableHead>Date</TableHead>
                              <TableHead>Due Date</TableHead>
                              <TableHead>Amount</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {invoices.map((invoice) => (
                              <TableRow key={invoice.id}>
                                <TableCell className="font-medium">{invoice.invoiceNumber}</TableCell>
                                <TableCell>{format(new Date(invoice.createdAt), 'MMM d, yyyy')}</TableCell>
                                <TableCell>{format(new Date(invoice.dueDate), 'MMM d, yyyy')}</TableCell>
                                <TableCell>KES {invoice.amount}</TableCell>
                                <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                                <TableCell className="text-right space-x-2">
                                  <Button variant="outline" size="sm">
                                    <Download className="h-4 w-4 mr-1" /> PDF
                                  </Button>
                                  
                                  {(invoice.status === "unpaid" || invoice.status === "overdue") && (
                                    <Button size="sm" onClick={() => handlePayment(invoice)}>
                                      Pay Now
                                    </Button>
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </ClientLayout>

      {/* Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Pay Invoice</DialogTitle>
            <DialogDescription>
              {selectedInvoice && (
                <>Invoice #{selectedInvoice.invoiceNumber} - KES {selectedInvoice.amount}</>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="mpesa" className="w-full" onValueChange={(value) => setPaymentMethod(value as "mpesa" | "paypal")}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="mpesa">M-Pesa</TabsTrigger>
              <TabsTrigger value="paypal">PayPal</TabsTrigger>
            </TabsList>
            
            <TabsContent value="mpesa">
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">M-Pesa Phone Number</Label>
                  <Input
                    id="phone"
                    placeholder="+254XXXXXXXXX"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                </div>
                <div className="text-sm text-gray-500">
                  You will receive a prompt on your phone to complete the payment.
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="paypal">
              <div className="py-4">
                <div className="mb-4 text-sm text-gray-500">
                  You will be redirected to PayPal to complete your payment.
                </div>
                <div id="paypal-button-container" className="flex justify-center">
                  {selectedInvoice && (
                    <PayPalButton
                      amount={selectedInvoice.amount}
                      currency="USD"
                      intent="capture"
                    />
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="secondary" onClick={() => setIsPaymentDialogOpen(false)}>
              Cancel
            </Button>
            {paymentMethod === "mpesa" && (
              <Button 
                onClick={handleMpesaPayment} 
                disabled={payWithMpesa.isPending}
              >
                {payWithMpesa.isPending ? "Processing..." : "Pay with M-Pesa"}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
