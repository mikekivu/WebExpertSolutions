import { useState } from "react";
import { Helmet } from "react-helmet";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { ClientLayout } from "@/components/client/ClientLayout";
import { 
  LifeBuoy, 
  MessageSquare, 
  TicketCheck, 
  Clock, 
  CheckCircle2, 
  ChevronRight,
  Paperclip,
  Send,
  AlertCircle,
  VideoIcon,
  HelpCircle,
  FileText,
  Download,
  ExternalLink
} from "lucide-react";
import { trackEvent } from "@/lib/analytics";
import { useToast } from "@/hooks/use-toast";

// Validation schema for support ticket form
const ticketFormSchema = z.object({
  subject: z.string().min(5, {
    message: "Subject must be at least 5 characters.",
  }),
  category: z.string().min(1, {
    message: "Please select a category.",
  }),
  priority: z.string().min(1, {
    message: "Please select a priority level.",
  }),
  message: z.string().min(20, {
    message: "Message must be at least 20 characters.",
  }),
  attachments: z.any().optional(),
});

type TicketFormValues = z.infer<typeof ticketFormSchema>;

// Sample FAQ data
const faqItems = [
  {
    question: "How do I update my contact information?",
    answer: "You can update your contact information by navigating to your account settings. Click on your profile icon in the top right corner, select 'Account Settings', and then update your information in the 'Contact Information' section."
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept various payment methods including M-Pesa, PayPal, credit/debit cards, and bank transfers. You can view all available payment options when processing an invoice payment."
  },
  {
    question: "How do I renew my domain name?",
    answer: "Domain renewal notifications are sent via email 30, 15, and 7 days before expiration. You can renew your domain from your client dashboard by navigating to 'Services' > 'Domains' and clicking the 'Renew' button next to the domain you wish to renew."
  },
  {
    question: "What is your refund policy?",
    answer: "Our refund policy varies depending on the service. For hosting services, we offer a 14-day money-back guarantee. Domain registrations are generally non-refundable once the domain has been registered. For custom development projects, please refer to the terms outlined in your specific contract."
  },
  {
    question: "How can I upgrade my hosting package?",
    answer: "To upgrade your hosting package, go to 'Services' > 'Hosting', select the hosting account you want to upgrade, and click the 'Upgrade' button. You'll be presented with available upgrade options and the prorated cost."
  },
];

// Sample support tickets for demonstration
const sampleTickets = [
  {
    id: "TKT-1001",
    subject: "Website not loading properly",
    status: "open",
    priority: "high",
    category: "Technical Support",
    created: "2025-05-15T10:30:00",
    lastUpdate: "2025-05-15T14:45:00",
    messages: 3
  },
  {
    id: "TKT-982",
    subject: "Email configuration assistance needed",
    status: "in-progress",
    priority: "medium",
    category: "Email Services",
    created: "2025-05-10T09:15:00",
    lastUpdate: "2025-05-14T16:20:00",
    messages: 2
  },
  {
    id: "TKT-976",
    subject: "Domain renewal question",
    status: "closed",
    priority: "normal",
    category: "Billing & Accounts",
    created: "2025-05-05T11:45:00",
    lastUpdate: "2025-05-06T13:30:00",
    messages: 4
  }
];

// Knowledge base articles
const knowledgeBaseArticles = [
  {
    id: 1,
    title: "Setting Up Email Forwarding on Your Domain",
    category: "Email Services",
    views: 1245,
    publishDate: "2025-04-15",
    excerpt: "Learn how to set up email forwarding to redirect messages from one address to another."
  },
  {
    id: 2,
    title: "How to Connect a Custom Domain to Your Website",
    category: "Domain Management",
    views: 2380,
    publishDate: "2025-04-10",
    excerpt: "Step-by-step guide to pointing your domain name to our hosting services."
  },
  {
    id: 3,
    title: "Troubleshooting Common WordPress Issues",
    category: "WordPress",
    views: 3567,
    publishDate: "2025-05-05",
    excerpt: "Solutions for the most common WordPress problems including white screen of death, plugin conflicts, and database errors."
  },
  {
    id: 4,
    title: "Understanding Hosting Package Resource Limits",
    category: "Web Hosting",
    views: 1892,
    publishDate: "2025-05-01",
    excerpt: "Explanation of CPU, memory, and bandwidth limits on different hosting packages."
  },
  {
    id: 5,
    title: "Securing Your Website: Best Practices",
    category: "Security",
    views: 4125,
    publishDate: "2025-04-22",
    excerpt: "Essential security measures to protect your website from common threats."
  },
];

// Function to get status badge style
const getStatusBadge = (status: string) => {
  switch (status) {
    case "open":
      return "bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium";
    case "in-progress":
      return "bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium";
    case "closed":
      return "bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium";
    default:
      return "bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs font-medium";
  }
};

// Function to get priority badge style
const getPriorityBadge = (priority: string) => {
  switch (priority) {
    case "high":
      return "bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-medium";
    case "medium":
      return "bg-orange-100 text-orange-800 px-2 py-1 rounded-full text-xs font-medium";
    case "normal":
      return "bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium";
    case "low":
      return "bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs font-medium";
    default:
      return "bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs font-medium";
  }
};

export default function Support() {
  const [activeTab, setActiveTab] = useState("tickets");
  const { toast } = useToast();
  
  // Form for creating new support tickets
  const form = useForm<TicketFormValues>({
    resolver: zodResolver(ticketFormSchema),
    defaultValues: {
      subject: "",
      category: "",
      priority: "normal",
      message: "",
    },
  });

  const onSubmit = async (values: TicketFormValues) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Track event in Google Analytics
      trackEvent(
        'support_ticket',
        'client_activity',
        `ticket_${values.category}`,
      );
      
      toast({
        title: "Support ticket submitted",
        description: "Your ticket has been created and our team will respond shortly.",
      });
      
      form.reset();
    } catch (error) {
      toast({
        title: "Error submitting ticket",
        description: "There was a problem creating your ticket. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <ClientLayout>
      <Helmet>
        <title>Support Center - Web Expert Solutions</title>
        <meta 
          name="description" 
          content="Get assistance with your Web Expert Solutions services. Submit support tickets, browse our knowledge base, and find answers to frequently asked questions."
        />
      </Helmet>
      
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-6">Client Support Center</h1>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-4 lg:w-[600px]">
            <TabsTrigger value="tickets" className="flex items-center gap-2 justify-center">
              <TicketCheck className="h-4 w-4" />
              <span className="hidden sm:inline">Support Tickets</span>
              <span className="sm:hidden">Tickets</span>
            </TabsTrigger>
            <TabsTrigger value="faq" className="flex items-center gap-2 justify-center">
              <HelpCircle className="h-4 w-4" />
              <span>FAQ</span>
            </TabsTrigger>
            <TabsTrigger value="knowledge" className="flex items-center gap-2 justify-center">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Knowledge Base</span>
              <span className="sm:hidden">KB</span>
            </TabsTrigger>
            <TabsTrigger value="contact" className="flex items-center gap-2 justify-center">
              <MessageSquare className="h-4 w-4" />
              <span className="hidden sm:inline">Contact Us</span>
              <span className="sm:hidden">Contact</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Support Tickets Tab */}
          <TabsContent value="tickets" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Create New Ticket</CardTitle>
                  <CardDescription>Submit a new support request</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="subject"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Subject</FormLabel>
                            <FormControl>
                              <Input placeholder="Brief description of the issue" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Category</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="technical">Technical Support</SelectItem>
                                <SelectItem value="billing">Billing & Accounts</SelectItem>
                                <SelectItem value="hosting">Web Hosting</SelectItem>
                                <SelectItem value="domain">Domain Names</SelectItem>
                                <SelectItem value="email">Email Services</SelectItem>
                                <SelectItem value="website">Website Issues</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="priority"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Priority</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select priority" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="normal">Normal</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Message</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Please describe your issue in detail..." 
                                className="min-h-[120px]"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="attachments"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Attachments (Optional)</FormLabel>
                            <FormControl>
                              <div className="flex items-center gap-2">
                                <Input
                                  type="file"
                                  id="file-upload"
                                  className="hidden"
                                  multiple
                                  onChange={(e) => field.onChange(e.target.files)}
                                />
                                <Button
                                  type="button"
                                  variant="outline"
                                  onClick={() => document.getElementById('file-upload')?.click()}
                                  className="w-full"
                                >
                                  <Paperclip className="h-4 w-4 mr-2" />
                                  Attach Files
                                </Button>
                              </div>
                            </FormControl>
                            <FormDescription>
                              Max 5 files, 5MB each (PNG, JPG, PDF, DOC)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button type="submit" className="w-full">
                        <Send className="h-4 w-4 mr-2" />
                        Submit Ticket
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
              
              <Card className="md:col-span-2">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Your Support Tickets</CardTitle>
                  <CardDescription>View and manage your existing support requests</CardDescription>
                </CardHeader>
                <CardContent>
                  {sampleTickets.length === 0 ? (
                    <div className="text-center py-8">
                      <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-blue-50 mb-4">
                        <TicketCheck className="h-6 w-6 text-blue-500" />
                      </div>
                      <h3 className="text-lg font-medium mb-2">No Support Tickets</h3>
                      <p className="text-muted-foreground">
                        You don't have any support tickets yet. Create a new ticket for assistance.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {sampleTickets.map((ticket) => (
                        <div key={ticket.id} className="flex flex-col border rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center">
                              <span className="font-medium text-gray-900">{ticket.id}</span>
                              <ChevronRight className="h-4 w-4 mx-2 text-gray-400" />
                              <span className="text-gray-700">{ticket.subject}</span>
                            </div>
                            <span className={getStatusBadge(ticket.status)}>
                              {ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1)}
                            </span>
                          </div>
                          <div className="flex flex-wrap items-center text-sm text-gray-500 gap-3 mt-1">
                            <div className="flex items-center">
                              <Clock className="h-3.5 w-3.5 mr-1" />
                              <span>Created: {new Date(ticket.created).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center">
                              <MessageSquare className="h-3.5 w-3.5 mr-1" />
                              <span>{ticket.messages} messages</span>
                            </div>
                            <div>
                              <span className={getPriorityBadge(ticket.priority)}>
                                {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)}
                              </span>
                            </div>
                            <div>
                              <span className="bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs font-medium">
                                {ticket.category}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Support Options</CardTitle>
                <CardDescription>Additional ways to get assistance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-blue-50 rounded-lg p-4 flex flex-col items-center text-center">
                    <LifeBuoy className="h-10 w-10 text-blue-600 mb-3" />
                    <h3 className="font-medium text-gray-900 mb-1">Live Chat</h3>
                    <p className="text-sm text-gray-500 mb-3">
                      Chat with our support team in real-time
                    </p>
                    <Button className="w-full mt-auto" variant="outline">
                      Start Chat
                    </Button>
                  </div>
                  
                  <div className="bg-green-50 rounded-lg p-4 flex flex-col items-center text-center">
                    <VideoIcon className="h-10 w-10 text-green-600 mb-3" />
                    <h3 className="font-medium text-gray-900 mb-1">Video Meeting</h3>
                    <p className="text-sm text-gray-500 mb-3">
                      Schedule a video call with a support specialist
                    </p>
                    <Button className="w-full mt-auto" variant="outline">
                      Book Meeting
                    </Button>
                  </div>
                  
                  <div className="bg-purple-50 rounded-lg p-4 flex flex-col items-center text-center">
                    <FileText className="h-10 w-10 text-purple-600 mb-3" />
                    <h3 className="font-medium text-gray-900 mb-1">Documentation</h3>
                    <p className="text-sm text-gray-500 mb-3">
                      Browse our detailed product documentation
                    </p>
                    <Button className="w-full mt-auto" variant="outline">
                      View Docs
                    </Button>
                  </div>
                  
                  <div className="bg-amber-50 rounded-lg p-4 flex flex-col items-center text-center">
                    <AlertCircle className="h-10 w-10 text-amber-600 mb-3" />
                    <h3 className="font-medium text-gray-900 mb-1">System Status</h3>
                    <p className="text-sm text-gray-500 mb-3">
                      Check our system status and uptime
                    </p>
                    <Button className="w-full mt-auto" variant="outline">
                      View Status
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* FAQ Tab */}
          <TabsContent value="faq" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Frequently Asked Questions</CardTitle>
                <CardDescription>Find answers to common questions about our services</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {faqItems.map((item, index) => (
                    <div key={index} className="border rounded-lg">
                      <details className="group">
                        <summary className="flex cursor-pointer items-center justify-between gap-1.5 rounded-lg bg-white p-4 text-gray-900">
                          <h3 className="font-medium">{item.question}</h3>
                          <svg
                            className="h-5 w-5 shrink-0 transition duration-300 group-open:-rotate-180"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth="2"
                              d="M19 9l-7 7-7-7"
                            />
                          </svg>
                        </summary>

                        <div className="border-t border-gray-200 p-4">
                          <p className="text-sm text-gray-700">
                            {item.answer}
                          </p>
                        </div>
                      </details>
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 bg-blue-50 p-4 rounded-lg">
                  <h3 className="text-lg font-medium mb-2 flex items-center">
                    <HelpCircle className="h-5 w-5 mr-2 text-blue-600" />
                    Can't find what you're looking for?
                  </h3>
                  <p className="mb-4">
                    If you can't find the answer you need, our support team is ready to help.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Button onClick={() => setActiveTab("tickets")}>
                      Create Support Ticket
                    </Button>
                    <Button variant="outline">
                      Browse Knowledge Base
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Knowledge Base Tab */}
          <TabsContent value="knowledge" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Knowledge Base</CardTitle>
                <CardDescription>Browse our collection of guides and tutorials</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  {knowledgeBaseArticles.map((article) => (
                    <div key={article.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-medium text-blue-600 hover:underline">
                            {article.title}
                          </h3>
                          <p className="text-sm text-gray-500 mt-1">
                            {article.excerpt}
                          </p>
                          <div className="flex flex-wrap items-center text-xs text-gray-500 gap-3 mt-3">
                            <span className="bg-gray-100 text-gray-800 px-2 py-1 rounded-full">
                              {article.category}
                            </span>
                            <div className="flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              <span>Published: {article.publishDate}</span>
                            </div>
                            <div className="flex items-center">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                              </svg>
                              <span>{article.views.toLocaleString()} views</span>
                            </div>
                          </div>
                        </div>
                        <ExternalLink className="h-4 w-4 text-gray-400 mt-1 ml-2 flex-shrink-0" />
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="flex justify-center">
                  <Button variant="outline" className="w-full md:w-auto">
                    View All Articles
                  </Button>
                </div>
                
                <div className="mt-8 bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-lg font-medium mb-2">Popular Downloads</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-2 border border-gray-200 rounded bg-white">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 text-blue-600 mr-3" />
                        <div>
                          <h4 className="font-medium">Getting Started Guide</h4>
                          <p className="text-xs text-gray-500">PDF • 2.4MB</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between p-2 border border-gray-200 rounded bg-white">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 text-blue-600 mr-3" />
                        <div>
                          <h4 className="font-medium">cPanel User Manual</h4>
                          <p className="text-xs text-gray-500">PDF • 5.7MB</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between p-2 border border-gray-200 rounded bg-white">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 text-blue-600 mr-3" />
                        <div>
                          <h4 className="font-medium">WordPress Setup Guide</h4>
                          <p className="text-xs text-gray-500">PDF • 3.1MB</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Contact Us Tab */}
          <TabsContent value="contact" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
                <CardDescription>Get in touch with our team via multiple channels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-medium mb-4">Our Contact Details</h3>
                    <div className="space-y-4">
                      <div className="flex items-start">
                        <div className="bg-blue-100 p-2 rounded-full mr-3">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">Phone</h4>
                          <p className="text-gray-600">+254 112 345 366</p>
                          <p className="text-gray-600">+254 715 026 405</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <div className="bg-blue-100 p-2 rounded-full mr-3">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">Email</h4>
                          <p className="text-gray-600">support@webexpertsolutions.co.ke</p>
                          <p className="text-gray-600">info@webexpertsolutions.co.ke</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <div className="bg-blue-100 p-2 rounded-full mr-3">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">Office Address</h4>
                          <p className="text-gray-600">CBD, Nairobi, Kenya</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <div className="bg-blue-100 p-2 rounded-full mr-3">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">Support Hours</h4>
                          <p className="text-gray-600">Monday - Friday: 8:00 AM - 6:00 PM</p>
                          <p className="text-gray-600">Saturday: 9:00 AM - 1:00 PM</p>
                          <p className="text-gray-600">Sunday: Closed</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium mb-4">Emergency Support</h3>
                    <div className="bg-red-50 border border-red-100 rounded-lg p-4 mb-6">
                      <div className="flex items-start">
                        <AlertCircle className="h-6 w-6 text-red-600 mr-3 mt-0.5" />
                        <div>
                          <h4 className="font-medium text-red-800">24/7 Emergency Support</h4>
                          <p className="text-gray-700 mb-3">
                            For critical issues outside of business hours, please use our emergency contact number:
                          </p>
                          <p className="text-red-800 font-bold">+254 715 026 405</p>
                          <p className="text-xs text-gray-500 mt-2">
                            Note: This line is for emergencies only such as website downtime or major service disruptions.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <h3 className="text-lg font-medium mb-4">Connect With Us</h3>
                    <div className="flex space-x-3 mb-6">
                      <a href="#" className="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z" />
                        </svg>
                      </a>
                      <a href="#" className="bg-blue-400 text-white p-2 rounded-full hover:bg-blue-500 transition">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" />
                        </svg>
                      </a>
                      <a href="#" className="bg-pink-600 text-white p-2 rounded-full hover:bg-pink-700 transition">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                        </svg>
                      </a>
                      <a href="#" className="bg-blue-800 text-white p-2 rounded-full hover:bg-blue-900 transition">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z" />
                        </svg>
                      </a>
                    </div>
                    
                    <div className="bg-blue-50 rounded-lg p-4">
                      <h4 className="font-medium mb-2">Subscribe to our Newsletter</h4>
                      <p className="text-sm text-gray-600 mb-3">
                        Stay updated with our latest services, updates, and tech tips.
                      </p>
                      <div className="flex gap-2">
                        <Input placeholder="Your email address" className="flex-grow" />
                        <Button>Subscribe</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </ClientLayout>
  );
}