import { useQuery } from "@tanstack/react-query";
import { ClientLayout } from "@/layouts/ClientLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Helmet } from "react-helmet";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Database, Server, Globe, LifeBuoy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface ClientService {
  id: number;
  userId: number;
  serviceId: number;
  startDate: string;
  endDate?: string;
  status: string;
  details?: any;
  service?: {
    id: number;
    name: string;
    description: string;
    category: string;
    price: string;
    features: string[];
  };
}

export default function ClientServices() {
  const { data: session } = useQuery({
    queryKey: ["/api/auth/session"],
  });

  const userId = session?.user?.id;
  
  const { data: clientServices = [], isLoading } = useQuery<ClientService[]>({
    queryKey: ["/api/client-services/user/" + userId],
    enabled: !!userId,
  });
  
  // Get related service details for each client service
  const { data: services = [] } = useQuery({
    queryKey: ["/api/services"],
    enabled: clientServices.length > 0,
  });

  // Combine client services with their service details
  const enrichedServices = clientServices.map(cs => {
    const serviceDetails = services.find((s: any) => s.id === cs.serviceId);
    return {
      ...cs,
      service: serviceDetails
    };
  });

  // Group services by category
  const servicesByCategory = {
    all: enrichedServices,
    active: enrichedServices.filter(s => s.status === "active"),
    expired: enrichedServices.filter(s => s.status === "expired" || s.status === "cancelled"),
    hosting: enrichedServices.filter(s => s.service?.category === "hosting"),
    domain: enrichedServices.filter(s => s.service?.category === "domain"),
    other: enrichedServices.filter(s => 
      s.service?.category !== "hosting" && 
      s.service?.category !== "domain"
    ),
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "hosting":
        return <Server className="h-5 w-5" />;
      case "domain":
        return <Globe className="h-5 w-5" />;
      default:
        return <Database className="h-5 w-5" />;
    }
  };

  // Calculate service status and remaining days
  const getServiceTimeRemaining = (service: ClientService) => {
    if (!service.endDate) return { percent: 100, status: "Unlimited" };
    
    const now = new Date();
    const startDate = new Date(service.startDate);
    const endDate = new Date(service.endDate);
    
    const totalDuration = endDate.getTime() - startDate.getTime();
    const elapsedDuration = now.getTime() - startDate.getTime();
    
    const percent = Math.max(0, Math.min(100, (elapsedDuration / totalDuration) * 100));
    
    const daysRemaining = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    return {
      percent,
      daysRemaining,
      status: daysRemaining <= 0 ? "Expired" : `${daysRemaining} days remaining`
    };
  };

  return (
    <>
      <Helmet>
        <title>My Services | Client Portal | Web Expert Solutions</title>
        <meta name="description" content="Manage your Web Expert Solutions services from your client dashboard" />
      </Helmet>
      
      <ClientLayout>
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">My Services</h1>
            <p className="text-gray-500">
              Manage and monitor all your services
            </p>
          </div>

          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Services</TabsTrigger>
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="hosting">Hosting</TabsTrigger>
              <TabsTrigger value="domain">Domains</TabsTrigger>
              <TabsTrigger value="other">Other Services</TabsTrigger>
            </TabsList>
            
            {Object.entries(servicesByCategory).map(([category, services]) => (
              <TabsContent key={category} value={category} className="mt-0">
                {isLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[1, 2, 3, 4].map((i) => (
                      <Card key={i} className="animate-pulse">
                        <CardHeader className="pb-2">
                          <div className="h-5 bg-gray-200 rounded w-1/3 mb-2"></div>
                          <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                        </CardHeader>
                        <CardContent>
                          <div className="h-4 bg-gray-200 rounded w-full mb-4"></div>
                          <div className="h-4 bg-gray-200 rounded w-full mb-4"></div>
                          <div className="h-2 bg-gray-200 rounded w-full"></div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : services.length === 0 ? (
                  <Card>
                    <CardContent className="pt-6 flex flex-col items-center justify-center text-center">
                      <LifeBuoy className="h-12 w-12 text-gray-400 mb-4" />
                      <h3 className="text-lg font-medium mb-2">No services found</h3>
                      <p className="text-sm text-gray-500 mb-4">
                        {category === "all" 
                          ? "You don't have any services yet. Browse our service offerings to get started."
                          : `You don't have any ${category} services.`}
                      </p>
                      <Button asChild>
                        <Link href="/#services">Browse Services</Link>
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {services.map((service) => {
                      const timeRemaining = getServiceTimeRemaining(service);
                      
                      return (
                        <Card key={service.id} className="overflow-hidden">
                          <CardHeader className="pb-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                {getCategoryIcon(service.service?.category || "")}
                                <CardTitle>{service.service?.name || "Unknown Service"}</CardTitle>
                              </div>
                              <Badge variant={service.status === "active" ? "default" : "destructive"}>
                                {service.status}
                              </Badge>
                            </div>
                            <CardDescription>
                              {service.service?.description || "No description available"}
                            </CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              {service.details && (
                                <div className="grid grid-cols-2 gap-2 text-sm">
                                  {Object.entries(service.details).map(([key, value]) => (
                                    <div key={key}>
                                      <span className="font-medium capitalize">{key}: </span>
                                      <span className="text-gray-600">{String(value)}</span>
                                    </div>
                                  ))}
                                </div>
                              )}
                              
                              <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                  <span>Subscription period:</span>
                                  <span>{timeRemaining.status}</span>
                                </div>
                                <Progress 
                                  value={100 - timeRemaining.percent} 
                                  className="h-2" 
                                />
                                <div className="flex justify-between text-xs text-gray-500">
                                  <span>Started: {new Date(service.startDate).toLocaleDateString()}</span>
                                  <span>
                                    {service.endDate 
                                      ? `Expires: ${new Date(service.endDate).toLocaleDateString()}`
                                      : "Never expires"}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </ClientLayout>
    </>
  );
}
