import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ClientLayout } from "@/layouts/ClientLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Helmet } from "react-helmet";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function ClientSettings() {
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [invoiceReminders, setInvoiceReminders] = useState(true);
  const [serviceUpdates, setServiceUpdates] = useState(true);
  const [promotionalEmails, setPromotionalEmails] = useState(false);
  
  const [isLoading, setIsLoading] = useState(false);
  
  const handleSaveSettings = async () => {
    setIsLoading(true);
    
    try {
      // This would be connected to a backend API in a real implementation
      // await apiRequest("PATCH", "/api/user/notification-settings", {
      //   emailNotifications,
      //   smsNotifications,
      //   invoiceReminders,
      //   serviceUpdates,
      //   promotionalEmails
      // });
      
      toast({
        title: "Settings updated",
        description: "Your notification preferences have been saved successfully.",
      });
    } catch (error) {
      toast({
        title: "Update failed",
        description: "Could not update your settings. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Settings | Client Portal | Web Expert Solutions</title>
        <meta name="description" content="Manage your notification settings and preferences" />
      </Helmet>
      
      <ClientLayout>
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
            <p className="text-gray-500">
              Manage your notification preferences and account settings
            </p>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Control how and when we contact you</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-notifications">Email Notifications</Label>
                    <p className="text-sm text-gray-500">
                      Receive important updates about your services and account via email
                    </p>
                  </div>
                  <Switch
                    id="email-notifications"
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="sms-notifications">SMS Notifications</Label>
                    <p className="text-sm text-gray-500">
                      Receive text messages for urgent notifications
                    </p>
                  </div>
                  <Switch
                    id="sms-notifications"
                    checked={smsNotifications}
                    onCheckedChange={setSmsNotifications}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="invoice-reminders">Invoice Reminders</Label>
                    <p className="text-sm text-gray-500">
                      Receive notifications about upcoming and overdue invoices
                    </p>
                  </div>
                  <Switch
                    id="invoice-reminders"
                    checked={invoiceReminders}
                    onCheckedChange={setInvoiceReminders}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="service-updates">Service Updates</Label>
                    <p className="text-sm text-gray-500">
                      Get notified about changes or updates to your services
                    </p>
                  </div>
                  <Switch
                    id="service-updates"
                    checked={serviceUpdates}
                    onCheckedChange={setServiceUpdates}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="promotional-emails">Promotional Emails</Label>
                    <p className="text-sm text-gray-500">
                      Receive special offers and promotional content from us
                    </p>
                  </div>
                  <Switch
                    id="promotional-emails"
                    checked={promotionalEmails}
                    onCheckedChange={setPromotionalEmails}
                  />
                </div>
                
                <Button 
                  onClick={handleSaveSettings} 
                  className="w-full mt-6" 
                  disabled={isLoading}
                >
                  {isLoading ? "Saving..." : "Save Settings"}
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>Manage your account preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button variant="outline" className="w-full">
                  Change Language
                </Button>
                
                <Button variant="outline" className="w-full">
                  Export My Data
                </Button>
                
                <Button variant="destructive" className="w-full">
                  Delete Account
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </ClientLayout>
    </>
  );
}