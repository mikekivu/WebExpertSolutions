import React from 'react';
import { Helmet } from 'react-helmet';
import { useQuery } from '@tanstack/react-query';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { 
  Card, 
  CardContent
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { 
  FaLinkedin, 
  FaTwitter, 
  FaGithub, 
  FaEnvelope 
} from 'react-icons/fa';

const AboutUs = () => {
  // Direct fetch approach for About Us information
  const [aboutUs, setAboutUs] = React.useState<any>({});
  const [aboutUsLoading, setAboutUsLoading] = React.useState(true);

  // Fetch the data directly without caching
  React.useEffect(() => {
    const fetchAboutUsData = async () => {
      try {
        setAboutUsLoading(true);
        const response = await fetch('/api/about-us');
        const data = await response.json();
        console.log("Fetched About Us data:", data);
        setAboutUs(data);
      } catch (error) {
        console.error("Error fetching About Us data:", error);
      } finally {
        setAboutUsLoading(false);
      }
    };

    fetchAboutUsData();
  }, []);

  // Direct fetch approach for Team Members
  const [teamMembers, setTeamMembers] = React.useState<any[]>([]);
  const [teamLoading, setTeamLoading] = React.useState(true);

  // Fetch the team members directly without caching
  React.useEffect(() => {
    const fetchTeamMembersData = async () => {
      try {
        setTeamLoading(true);
        const response = await fetch('/api/team-members');
        const data = await response.json();
        console.log("Fetched Team Members data:", data);
        
        // Ensure we have an array even if the response is not as expected
        if (Array.isArray(data)) {
          setTeamMembers(data);
        } else {
          console.log("Team members data is not an array, using empty array instead");
          setTeamMembers([]);
        }
      } catch (error) {
        console.error("Error fetching Team Members data:", error);
        setTeamMembers([]);
      } finally {
        setTeamLoading(false);
      }
    };

    fetchTeamMembersData();
  }, []);

  // Loading state
  if (aboutUsLoading || teamLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
        <Footer />
      </div>
    );
  }

  // Safely handle values with proper null checking
  const values = aboutUs && aboutUs.values ? aboutUs.values.split('\n').filter(Boolean) : [];

  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>About Us | Web Expert Solutions</title>
        <meta name="description" content={aboutUs?.metaDescription || "Learn about our web development company"} />
        <meta property="og:title" content="About Us | Web Expert Solutions" />
        <meta property="og:description" content={aboutUs?.metaDescription || "Learn about our web development company"} />
        <meta property="og:type" content="website" />
      </Helmet>

      <Header />

      <main className="flex-1 container mx-auto px-4 py-12">
        {/* Hero Section */}
        <section className="mb-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-primary">{aboutUs?.title || 'About Our Company'}</h1>
            <div className="h-1 w-20 bg-primary mx-auto mb-8"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We are a team of passionate tech experts dedicated to delivering innovative digital solutions that help businesses thrive in the digital world.
            </p>
          </div>
        </section>

        {/* Mission, Vision, Values Tabs */}
        <section className="mb-16">
          <Tabs defaultValue="mission" className="w-full max-w-4xl mx-auto">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="mission">Our Mission</TabsTrigger>
              <TabsTrigger value="vision">Our Vision</TabsTrigger>
              <TabsTrigger value="values">Our Values</TabsTrigger>
            </TabsList>
            <TabsContent value="mission" className="p-8 bg-white rounded-lg shadow-md">
              <h2 className="text-2xl font-bold mb-4 text-primary">Our Mission</h2>
              <div className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                {aboutUs?.mission}
              </div>
            </TabsContent>
            <TabsContent value="vision" className="p-8 bg-white rounded-lg shadow-md">
              <h2 className="text-2xl font-bold mb-4 text-primary">Our Vision</h2>
              <div className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                {aboutUs?.vision}
              </div>
            </TabsContent>
            <TabsContent value="values" className="p-8 bg-white rounded-lg shadow-md">
              <h2 className="text-2xl font-bold mb-4 text-primary">Our Values</h2>
              <div className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                {aboutUs?.values}
              </div>
            </TabsContent>
          </Tabs>
        </section>

        {/* Our History Section */}
        <section className="mb-16">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-6 text-center text-primary">Our History</h2>
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                {aboutUs?.history}
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="mb-16">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-6 text-center text-primary">Our Team</h2>
            <div className="text-gray-700 leading-relaxed whitespace-pre-wrap max-w-4xl mx-auto mb-12">
              {aboutUs?.teamDescription}
            </div>

            {teamMembers && teamMembers.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {teamMembers.map((member: any) => (
                  <Card key={member.id} className="overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                    <div className="aspect-square overflow-hidden">
                      <img 
                        src={member.imageUrl} 
                        alt={member.name}
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                      />
                    </div>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                      <p className="text-primary font-medium mb-3">{member.position}</p>
                      <p className="text-gray-600 text-sm mb-4 line-clamp-4">{member.bio}</p>
                      
                      <div className="flex space-x-3">
                        {member.socialLinks?.linkedin && (
                          <a href={member.socialLinks.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-primary transition-colors">
                            <FaLinkedin size={20} />
                          </a>
                        )}
                        {member.socialLinks?.twitter && (
                          <a href={member.socialLinks.twitter} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-primary transition-colors">
                            <FaTwitter size={20} />
                          </a>
                        )}
                        {member.socialLinks?.github && (
                          <a href={member.socialLinks.github} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-primary transition-colors">
                            <FaGithub size={20} />
                          </a>
                        )}
                        {member.socialLinks?.email && (
                          <a href={`mailto:${member.socialLinks.email}`} className="text-gray-500 hover:text-primary transition-colors">
                            <FaEnvelope size={20} />
                          </a>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="bg-gray-50 p-8 rounded-lg text-center mt-6">
                <p className="text-gray-500">Team members will be added by the administrator soon.</p>
                <p className="text-gray-400 text-sm mt-2">Check back later to meet our amazing team!</p>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default AboutUs;