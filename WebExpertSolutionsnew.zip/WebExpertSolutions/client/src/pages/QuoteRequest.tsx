import { useState, useEffect } from 'react';
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { 
  Card, 
  CardContent,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { trackEvent } from "@/lib/analytics";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertCircle, CalendarIcon, CheckCircle2, Clipboard, FileText } from "lucide-react";
import type { ContactInfo } from "@shared/schema";
import { 
  FormFeedback, 
  LiveValidationMessage, 
  CharacterCounter, 
  FieldIndicator 
} from "@/components/ui/form-feedback";
import { motion } from "framer-motion";

const quoteFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Phone number must be at least 10 digits"),
  company: z.string().optional(),
  serviceType: z.string().min(1, "Please select a service type"),
  budget: z.string().min(1, "Please select your budget range"),
  timeline: z.string().min(1, "Please select your timeline"),
  requirements: z.string().min(10, "Please provide some details about your requirements"),
  additionalInfo: z.string().optional(),
  privacyPolicy: z.boolean().refine(val => val === true, {
    message: "You must agree to our privacy policy",
  }),
});

type QuoteFormValues = z.infer<typeof quoteFormSchema>;

export default function QuoteRequest() {
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const { data: contactInfo } = useQuery<ContactInfo>({
    queryKey: ['/api/contact'],
  });
  
  // Check if user is already logged in
  const { data: session } = useQuery<{
    authenticated: boolean;
    user: {
      id: number;
      username: string;
      email: string;
      fullName: string;
      phone?: string;
      company?: string;
    }
  }>({
    queryKey: ['/api/auth/session'],
  });
  
  const isLoggedIn = session?.authenticated;
  const loggedInUser = session?.user;

  // Track form field changes for real-time validation
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    phone: "",
    requirements: ""
  });
  
  // Set default values based on logged-in status
  const form = useForm<QuoteFormValues>({
    resolver: zodResolver(quoteFormSchema),
    defaultValues: {
      name: loggedInUser?.fullName || "",
      email: loggedInUser?.email || "",
      phone: loggedInUser?.phone || "",
      company: loggedInUser?.company || "",
      serviceType: "",
      budget: "",
      timeline: "",
      requirements: "",
      additionalInfo: "",
      privacyPolicy: false,
    },
    mode: "onChange" // Enable validations on change
  });
  
  // Update form values when user session data loads
  useEffect(() => {
    if (isLoggedIn && loggedInUser) {
      form.setValue('name', loggedInUser.fullName || "");
      form.setValue('email', loggedInUser.email || "");
      form.setValue('phone', loggedInUser.phone || "");
      form.setValue('company', loggedInUser.company || "");
      
      // Update the form state for real-time validation
      setFormState(prev => ({
        ...prev,
        name: loggedInUser.fullName || "",
        email: loggedInUser.email || "",
        phone: loggedInUser.phone || "",
      }));
    }
  }, [isLoggedIn, loggedInUser, form]);

  // Watch form values for real-time validation
  useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (name === 'name' || name === 'email' || name === 'phone' || name === 'requirements') {
        setFormState(prev => ({
          ...prev,
          [name as string]: value[name as keyof typeof value] as string || ""
        }));
      }
    });
    
    return () => subscription.unsubscribe();
  }, [form.watch]);
  
  const [submitting, setSubmitting] = useState(false);
  
  const onSubmit = async (values: QuoteFormValues) => {
    try {
      setSubmitting(true);
      
      // Make the actual API call to submit the quote request
      await apiRequest('POST', '/api/quote-requests', {
        name: values.name,
        email: values.email,
        phone: values.phone,
        serviceType: values.serviceType,
        message: `
Budget: ${values.budget}
Timeline: ${values.timeline}
Requirements: ${values.requirements}
Additional Info: ${values.additionalInfo || 'None provided'}
Company: ${values.company || 'None provided'}
        `.trim()
      });
      
      // Track successful quote request submission
      trackEvent(
        'quote_request', 
        'lead_generation', 
        `service_${values.serviceType}`,
        values.budget ? parseInt(values.budget) : undefined
      );
      
      toast({
        title: "Quote request submitted",
        description: "Thank you for your interest. We'll review your requirements and get back to you soon!",
      });
      
      setIsSubmitted(true);
    } catch (error) {
      // Track quote request submission errors
      trackEvent(
        'form_error',
        'lead_generation',
        'quote_request_error'
      );
      
      toast({
        title: "Error submitting quote request",
        description: "There was a problem submitting your request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <>
        <Helmet>
          <title>Quote Request Submitted - Web Expert Solutions</title>
          <meta name="description" content="Thank you for submitting your quote request to Web Expert Solutions. We'll review your requirements and get back to you soon." />
        </Helmet>
        
        <div className="flex flex-col min-h-screen">
          <Header />
          
          <main className="flex-grow">
            <div className="container mx-auto py-12 px-4 md:px-6">
              <Card className="max-w-2xl mx-auto border-0 shadow-lg">
                <CardContent className="p-8 text-center">
                  <div className="mb-6 text-primary">
                    <CheckCircle2 className="h-16 w-16 mx-auto" />
                  </div>
                  <h1 className="text-2xl md:text-3xl font-bold mb-4">Quote Request Submitted</h1>
                  <p className="text-muted-foreground mb-6">
                    Thank you for your interest in our services. We've received your quote request and will review it promptly.
                  </p>
                  <p className="mb-8">
                    One of our team members will contact you via email or phone within 24-48 hours to discuss your project in detail.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button asChild variant="outline" className="gap-2">
                      <a href="/services">
                        <FileText className="h-4 w-4" />
                        Explore our Services
                      </a>
                    </Button>
                    <Button asChild className="gap-2">
                      <a href="/">
                        <Clipboard className="h-4 w-4" />
                        Back to Home
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </main>
          
          <Footer />
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Request a Free Quote - Web Expert Solutions</title>
        <meta name="description" content="Get a free, no-obligation quote for your web development, mobile app, hosting, or digital marketing project. Fill out our simple form and we'll respond within 24 hours." />
      </Helmet>
      
      <div className="flex flex-col min-h-screen">
        <Header />
        
        <main className="flex-grow">
          <div className="container mx-auto py-10 px-4 md:px-6">
            <div className="text-center mb-10">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Request a Free Quote</h1>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Tell us about your project, and we'll provide you with a detailed, no-obligation quote. 
                Our team will analyze your requirements and respond within 24 hours.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              <Card className="col-span-3 md:col-span-1 text-center shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex flex-col space-y-2 items-center mb-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <CalendarIcon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-medium text-lg">How It Works</h3>
                  </div>
                  <ol className="text-left space-y-4">
                    <li className="flex items-start gap-3">
                      <span className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">1</span>
                      <span>Fill out the quote request form with your project details</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">2</span>
                      <span>Our team reviews your requirements within 24 hours</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">3</span>
                      <span>We reach out to discuss your project in more detail</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">4</span>
                      <span>You receive a detailed proposal with timeline and pricing</span>
                    </li>
                  </ol>
                </CardContent>
              </Card>

              <Card className="col-span-3 md:col-span-2 shadow-md">
                <CardContent className="pt-6">
                  <h2 className="text-2xl font-bold mb-6">Your Project Details</h2>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Full Name */}
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name*</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Your name" 
                                  {...field} 
                                  onChange={(e) => {
                                    field.onChange(e);
                                    setFormState(prev => ({ ...prev, name: e.target.value }));
                                  }}
                                  className={formState.name.length > 0 ? (formState.name.length >= 2 ? "border-green-400 focus-visible:ring-green-400" : "border-red-400 focus-visible:ring-red-400") : ""}
                                  readOnly={isLoggedIn}
                                  disabled={isLoggedIn}
                                />
                              </FormControl>
                              {isLoggedIn ? (
                                <FormDescription className="text-sm text-primary mt-1">
                                  Using your account information
                                </FormDescription>
                              ) : (
                                <div className="mt-1">
                                  <LiveValidationMessage
                                    value={formState.name}
                                    validationFn={(value) => value.length >= 2}
                                    errorMessage="Name must be at least 2 characters"
                                    successMessage="Name looks good!"
                                  />
                                </div>
                              )}
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        {/* Email */}
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address*</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Your email" 
                                  {...field} 
                                  onChange={(e) => {
                                    field.onChange(e);
                                    setFormState(prev => ({ ...prev, email: e.target.value }));
                                  }}
                                  className={formState.email.length > 0 ? (
                                    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formState.email) 
                                      ? "border-green-400 focus-visible:ring-green-400" 
                                      : "border-red-400 focus-visible:ring-red-400"
                                  ) : ""}
                                  readOnly={isLoggedIn}
                                  disabled={isLoggedIn}
                                />
                              </FormControl>
                              {isLoggedIn ? (
                                <FormDescription className="text-sm text-primary mt-1">
                                  Using your account email
                                </FormDescription>
                              ) : (
                                <div className="mt-1">
                                  <LiveValidationMessage
                                    value={formState.email}
                                    validationFn={(value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)}
                                    errorMessage="Please enter a valid email address"
                                    successMessage="Email format is correct!"
                                  />
                                </div>
                              )}
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* Phone */}
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number*</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Your phone number" 
                                  {...field} 
                                  onChange={(e) => {
                                    field.onChange(e);
                                    setFormState(prev => ({ ...prev, phone: e.target.value }));
                                  }}
                                  className={formState.phone.length > 0 ? (
                                    formState.phone.length >= 10 
                                      ? "border-green-400 focus-visible:ring-green-400" 
                                      : "border-red-400 focus-visible:ring-red-400"
                                  ) : ""}
                                  readOnly={isLoggedIn}
                                  disabled={isLoggedIn}
                                />
                              </FormControl>
                              {isLoggedIn ? (
                                <FormDescription className="text-sm text-primary mt-1">
                                  Using your account phone number
                                </FormDescription>
                              ) : (
                                <div className="mt-1">
                                  <LiveValidationMessage
                                    value={formState.phone}
                                    validationFn={(value) => value.length >= 10}
                                    errorMessage="Phone number must be at least 10 digits"
                                    successMessage="Phone number format is valid!"
                                  />
                                </div>
                              )}
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* Company */}
                        <FormField
                          control={form.control}
                          name="company"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Company Name (Optional)</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Your company name" 
                                  {...field} 
                                  readOnly={isLoggedIn && !!loggedInUser?.company}
                                  disabled={isLoggedIn && !!loggedInUser?.company}
                                />
                              </FormControl>
                              {isLoggedIn && loggedInUser?.company ? (
                                <FormDescription className="text-sm text-primary mt-1">
                                  Using your account company information
                                </FormDescription>
                              ) : null}
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* Service Type */}
                        <FormField
                          control={form.control}
                          name="serviceType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Service Type*</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select service type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="website">Website Development</SelectItem>
                                  <SelectItem value="e-commerce">E-Commerce Website</SelectItem>
                                  <SelectItem value="mobile-app">Mobile App Development</SelectItem>
                                  <SelectItem value="pos">Point of Sale (POS) System</SelectItem>
                                  <SelectItem value="microfinance">Microfinance System</SelectItem>
                                  <SelectItem value="school-management">School Management System</SelectItem>
                                  <SelectItem value="web-hosting">Web Hosting</SelectItem>
                                  <SelectItem value="domain-registration">Domain Registration</SelectItem>
                                  <SelectItem value="bulk-sms">Bulk SMS</SelectItem>
                                  <SelectItem value="digital-marketing">Digital Marketing</SelectItem>
                                  <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* Budget */}
                        <FormField
                          control={form.control}
                          name="budget"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Estimated Budget*</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select budget range" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="5000">Less than KSh 5,000</SelectItem>
                                  <SelectItem value="15000">KSh 5,000 - KSh 15,000</SelectItem>
                                  <SelectItem value="25000">KSh 15,000 - KSh 25,000</SelectItem>
                                  <SelectItem value="50000">KSh 25,000 - KSh 50,000</SelectItem>
                                  <SelectItem value="100000">KSh 50,000 - KSh 100,000</SelectItem>
                                  <SelectItem value="200000">KSh 100,000 - KSh 200,000</SelectItem>
                                  <SelectItem value="500000">KSh 200,000 - KSh 500,000</SelectItem>
                                  <SelectItem value="1000000">Above KSh 500,000</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        {/* Timeline */}
                        <FormField
                          control={form.control}
                          name="timeline"
                          render={({ field }) => (
                            <FormItem className="col-span-1 md:col-span-2">
                              <FormLabel>Project Timeline*</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select timeline" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="urgent">Urgent (Less than 1 week)</SelectItem>
                                  <SelectItem value="short">Short-term (1-2 weeks)</SelectItem>
                                  <SelectItem value="medium">Medium-term (2-4 weeks)</SelectItem>
                                  <SelectItem value="standard">Standard (1-2 months)</SelectItem>
                                  <SelectItem value="extended">Extended (3+ months)</SelectItem>
                                  <SelectItem value="flexible">Flexible / Not sure yet</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      {/* Project Requirements */}
                      <FormField
                        control={form.control}
                        name="requirements"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Project Requirements*</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Textarea 
                                  placeholder="Describe your project requirements, goals and any specific features you need..." 
                                  className="resize-y min-h-[120px]"
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(e);
                                    setFormState(prev => ({ ...prev, requirements: e.target.value }));
                                  }}
                                />
                                <div className="absolute bottom-2 right-2 text-xs text-muted-foreground">
                                  <CharacterCounter 
                                    value={formState.requirements}
                                    min={10}
                                    className="text-xs"
                                  />
                                </div>
                              </div>
                            </FormControl>
                            <div className="mt-1">
                              <LiveValidationMessage
                                value={formState.requirements}
                                validationFn={(value) => value.length >= 10}
                                errorMessage="Please provide at least 10 characters"
                                successMessage="Thank you for the details!"
                              />
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {/* Additional Information */}
                      <FormField
                        control={form.control}
                        name="additionalInfo"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Additional Information (Optional)</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Any other information that would help us understand your project better..." 
                                className="resize-y min-h-[80px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {/* Privacy Policy */}
                      <FormField
                        control={form.control}
                        name="privacyPolicy"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                I agree to the <a href="/privacy-policy" className="text-primary underline">privacy policy</a> and consent to being contacted about my request
                              </FormLabel>
                              <FormMessage />
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <Button type="submit" className="w-full" disabled={submitting}>
                        {submitting ? (
                          <div className="flex items-center">
                            <span className="animate-spin mr-2 h-4 w-4 border-2 border-b-transparent rounded-full" />
                            Submitting Request...
                          </div>
                        ) : (
                          "Submit Quote Request"
                        )}
                      </Button>
                      
                      <div className="text-center text-sm text-muted-foreground">
                        <p>Usually responded to within 24 hours</p>
                        {contactInfo && (
                          <p className="mt-2">Questions? Call us at {contactInfo.phone1}</p>
                        )}
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}