import { Helmet } from "react-helmet";
import { Separator } from "@/components/ui/separator";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { QuoteRequestForm } from "@/components/QuoteRequestForm";
import { Button } from "@/components/ui/button";
import { Search, BarChart, Globe, Instagram, Facebook, Twitter } from "lucide-react";

export default function DigitalMarketing() {
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Digital Marketing Services | Web Expert Solutions</title>
        <meta 
          name="description" 
          content="Comprehensive digital marketing services including SEO, social media management, content marketing, and PPC advertising. Grow your online presence and reach your target audience." 
        />
        <meta property="og:title" content="Digital Marketing Services | Web Expert Solutions" />
        <meta 
          property="og:description" 
          content="Comprehensive digital marketing services including SEO, social media management, content marketing, and PPC advertising. Grow your online presence and reach your target audience." 
        />
        <meta property="og:type" content="website" />
      </Helmet>

      <Header />

      <main className="flex-grow">
        <section className="bg-gradient-to-b from-slate-50 to-white py-12 md:py-24">
          <div className="container px-4 mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Digital Marketing Services</h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-12">
              Elevate your online presence with our comprehensive digital marketing services. 
              We help businesses grow their brand, reach target audiences, and drive conversions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <Button size="lg" asChild>
                <a href="#services">Our Services</a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#contact-us">Get a Quote</a>
              </Button>
            </div>
          </div>
        </section>

        <section id="services" className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Our Digital Marketing Services</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                We offer a full range of digital marketing solutions to help you connect with your audience and achieve your business goals.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
              <div className="bg-slate-50 p-8 rounded-lg">
                <Search className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Search Engine Optimization (SEO)</h3>
                <p className="text-muted-foreground mb-4">
                  Improve your website's visibility in search engine results to drive organic traffic and reach potential customers.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Keyword research and strategy</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>On-page and off-page optimization</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Technical SEO audits</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Local SEO for businesses</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <div className="flex gap-2 mb-4">
                  <Facebook className="h-10 w-10 text-primary" />
                  <Instagram className="h-10 w-10 text-primary" />
                  <Twitter className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Social Media Marketing</h3>
                <p className="text-muted-foreground mb-4">
                  Build your brand, engage with your audience, and drive traffic through strategic social media marketing.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Social media strategy development</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Content creation and curation</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Community management</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Paid social media advertising</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <BarChart className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Pay-Per-Click (PPC) Advertising</h3>
                <p className="text-muted-foreground mb-4">
                  Drive targeted traffic and generate leads quickly with strategically managed paid advertising campaigns.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Google Ads management</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Social media advertising</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Retargeting campaigns</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Landing page optimization</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Globe className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Content Marketing</h3>
                <p className="text-muted-foreground mb-4">
                  Engage your audience with valuable content that builds trust, demonstrates expertise, and drives conversions.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Content strategy development</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Blog writing and management</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Email marketing campaigns</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Infographics and visual content</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary mb-4">
                  <path d="M12 20h9"></path>
                  <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
                </svg>
                <h3 className="text-xl font-semibold mb-3">Copywriting & Content Creation</h3>
                <p className="text-muted-foreground mb-4">
                  Compelling, conversion-focused copy and content that resonates with your target audience.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Website copy</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Blog and article writing</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Product descriptions</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Email marketing content</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary mb-4">
                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                  <line x1="8" y1="21" x2="16" y2="21"></line>
                  <line x1="12" y1="17" x2="12" y2="21"></line>
                </svg>
                <h3 className="text-xl font-semibold mb-3">Analytics & Reporting</h3>
                <p className="text-muted-foreground mb-4">
                  Data-driven insights and comprehensive reporting to track performance and optimize your marketing strategy.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Custom dashboard setup</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Campaign performance analysis</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Conversion tracking</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Regular performance reports</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <Separator />

        <section className="py-16 bg-slate-50">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Our Digital Marketing Process</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                We follow a strategic approach to digital marketing that's tailored to your business goals and target audience.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-12">
              <div className="relative">
                <div className="bg-white p-8 rounded-lg shadow-sm text-center h-full">
                  <div className="bg-primary/10 text-primary h-16 w-16 rounded-full flex items-center justify-center font-bold text-2xl mx-auto mb-6">1</div>
                  <h3 className="text-xl font-semibold mb-3">Research & Strategy</h3>
                  <p className="text-muted-foreground">
                    We analyze your business, competitors, and target audience to develop a tailored digital marketing strategy.
                  </p>
                </div>
                <div className="hidden md:block absolute -right-3 top-1/2 transform -translate-y-1/2 z-10">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="9 18 15 12 9 6"></polyline>
                  </svg>
                </div>
              </div>
              
              <div className="relative">
                <div className="bg-white p-8 rounded-lg shadow-sm text-center h-full">
                  <div className="bg-primary/10 text-primary h-16 w-16 rounded-full flex items-center justify-center font-bold text-2xl mx-auto mb-6">2</div>
                  <h3 className="text-xl font-semibold mb-3">Implementation</h3>
                  <p className="text-muted-foreground">
                    We execute the strategy with precision, setting up campaigns, creating content, and optimizing channels.
                  </p>
                </div>
                <div className="hidden md:block absolute -right-3 top-1/2 transform -translate-y-1/2 z-10">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="9 18 15 12 9 6"></polyline>
                  </svg>
                </div>
              </div>
              
              <div className="relative">
                <div className="bg-white p-8 rounded-lg shadow-sm text-center h-full">
                  <div className="bg-primary/10 text-primary h-16 w-16 rounded-full flex items-center justify-center font-bold text-2xl mx-auto mb-6">3</div>
                  <h3 className="text-xl font-semibold mb-3">Monitoring & Analysis</h3>
                  <p className="text-muted-foreground">
                    We continuously track performance metrics, analyze results, and gather insights to guide improvements.
                  </p>
                </div>
                <div className="hidden md:block absolute -right-3 top-1/2 transform -translate-y-1/2 z-10">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="9 18 15 12 9 6"></polyline>
                  </svg>
                </div>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm text-center h-full">
                <div className="bg-primary/10 text-primary h-16 w-16 rounded-full flex items-center justify-center font-bold text-2xl mx-auto mb-6">4</div>
                <h3 className="text-xl font-semibold mb-3">Optimization & Growth</h3>
                <p className="text-muted-foreground">
                  We refine strategies based on data to continuously improve performance and maximize your ROI.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold mb-6">Why Choose Us for Digital Marketing?</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  We combine technical expertise, creative strategies, and data-driven insights to deliver measurable results for your business.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Customized strategies tailored to your business goals</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Experienced team of digital marketing specialists</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Comprehensive approach covering all digital channels</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Transparent reporting and clear communication</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Focus on ROI and measurable results</p>
                  </div>
                </div>
              </div>
              <div id="contact-us">
                <QuoteRequestForm serviceType="digital-marketing" />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}