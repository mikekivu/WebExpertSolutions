import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { HeroSection } from "@/components/HeroSection";
import { ServicesOverview } from "@/components/ServicesOverview";
import { FeaturedServices } from "@/components/FeaturedServices";
import { HostingDomain } from "@/components/HostingDomain";
import { Portfolio } from "@/components/Portfolio";
import { Testimonials } from "@/components/Testimonials";
import { CallToAction } from "@/components/CallToAction";
import { ContactSection } from "@/components/ContactSection";
import { Helmet } from "react-helmet";

export default function Home() {
  return (
    <>
      <Helmet>
        <title>Web Expert Solutions Kenya - Web Development, Mobile Apps, Software & Hosting</title>
        <meta 
          name="description" 
          content="Complete digital solutions including web development, mobile apps, custom software, domain registration, web hosting, and digital marketing services to help your business grow."
        />
      </Helmet>
      
      <div className="flex flex-col min-h-screen">
        <Header />
        
        <main className="flex-grow">
          <HeroSection />
          <ServicesOverview />
          <FeaturedServices />
          <HostingDomain />
          <Portfolio />
          <Testimonials />
          <CallToAction />
          <ContactSection />
        </main>
        
        <Footer />
      </div>
    </>
  );
}
