import { Helmet } from "react-helmet";
import { Separator } from "@/components/ui/separator";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { QuoteRequestForm } from "@/components/QuoteRequestForm";
import { Button } from "@/components/ui/button";
import { Phone, Smartphone, Tablet, Settings, Code, Shield } from "lucide-react";

export default function MobileAppDevelopment() {
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Mobile App Development | Web Expert Solutions</title>
        <meta 
          name="description" 
          content="Professional mobile app development services for iOS and Android. Build custom, responsive, and feature-rich mobile applications for your business." 
        />
        <meta property="og:title" content="Mobile App Development | Web Expert Solutions" />
        <meta 
          property="og:description" 
          content="Professional mobile app development services for iOS and Android. Build custom, responsive, and feature-rich mobile applications for your business." 
        />
        <meta property="og:type" content="website" />
      </Helmet>

      <Header />

      <main className="flex-grow">
        <section className="bg-gradient-to-b from-slate-50 to-white py-12 md:py-24">
          <div className="container px-4 mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Mobile App Development</h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-12">
              We create stunning, high-performance mobile applications for iOS and Android platforms
              that help businesses engage customers, streamline operations, and drive growth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <Button size="lg" asChild>
                <a href="#contact-us">Request a Quote</a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#our-process">Our Process</a>
              </Button>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Our Mobile App Development Services</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                We offer end-to-end mobile app development services, from concept and design to development, testing, and deployment.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
              <div className="bg-slate-50 p-8 rounded-lg">
                <Smartphone className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">iOS Development</h3>
                <p className="text-muted-foreground">
                  Create sleek, high-performance apps for iPhone and iPad users with native Swift development.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Phone className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Android Development</h3>
                <p className="text-muted-foreground">
                  Build feature-rich Android applications that work across the diverse ecosystem of Android devices.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Code className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Cross-Platform Apps</h3>
                <p className="text-muted-foreground">
                  Develop apps that work seamlessly on both iOS and Android platforms using React Native or Flutter.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Tablet className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">UI/UX Design</h3>
                <p className="text-muted-foreground">
                  Create intuitive, engaging user interfaces that provide an exceptional user experience.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Settings className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">App Maintenance</h3>
                <p className="text-muted-foreground">
                  Ongoing support, updates, and maintenance to ensure your app continues to perform at its best.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Shield className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">App Security</h3>
                <p className="text-muted-foreground">
                  Implement robust security measures to protect user data and ensure compliance with regulations.
                </p>
              </div>
            </div>
          </div>
        </section>

        <Separator />

        <section id="our-process" className="py-16 bg-slate-50">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Our Development Process</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                We follow a structured approach to mobile app development, ensuring quality, efficiency, and transparency.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-16 mt-12">
              <div className="space-y-8">
                <div className="flex gap-4">
                  <div className="bg-primary/10 text-primary h-10 w-10 rounded-full flex items-center justify-center font-bold text-lg">1</div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Discovery & Planning</h3>
                    <p className="text-muted-foreground">We analyze your requirements, define the scope, and create a detailed project plan.</p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="bg-primary/10 text-primary h-10 w-10 rounded-full flex items-center justify-center font-bold text-lg">2</div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">UI/UX Design</h3>
                    <p className="text-muted-foreground">Our designers create wireframes and prototypes to visualize the app's interface and user flow.</p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="bg-primary/10 text-primary h-10 w-10 rounded-full flex items-center justify-center font-bold text-lg">3</div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Development</h3>
                    <p className="text-muted-foreground">Our developers build the app using clean, efficient code and modern development practices.</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-8">
                <div className="flex gap-4">
                  <div className="bg-primary/10 text-primary h-10 w-10 rounded-full flex items-center justify-center font-bold text-lg">4</div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Quality Assurance</h3>
                    <p className="text-muted-foreground">Thorough testing to identify and fix bugs, ensuring a smooth user experience.</p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="bg-primary/10 text-primary h-10 w-10 rounded-full flex items-center justify-center font-bold text-lg">5</div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Deployment</h3>
                    <p className="text-muted-foreground">We help you launch your app on the App Store and Google Play Store.</p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="bg-primary/10 text-primary h-10 w-10 rounded-full flex items-center justify-center font-bold text-lg">6</div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Post-Launch Support</h3>
                    <p className="text-muted-foreground">Ongoing maintenance, updates, and support to ensure your app continues to perform optimally.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold mb-6">Why Choose Us for Mobile App Development?</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  We combine technical expertise with creative design to build mobile apps that stand out in today's competitive marketplace.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Experienced team of mobile developers and designers</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Custom solutions tailored to your specific business needs</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Focus on user experience and interface design</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Transparent development process with regular updates</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Post-launch support and maintenance services</p>
                  </div>
                </div>
              </div>
              <div id="contact-us">
                <QuoteRequestForm serviceType="mobile-app" />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}