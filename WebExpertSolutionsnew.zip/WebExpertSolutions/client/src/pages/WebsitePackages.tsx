import { WebPackages } from "@/components/WebPackages";
import { QuoteRequestForm } from "@/components/QuoteRequestForm";
import { Helmet } from "react-helmet";
import { Separator } from "@/components/ui/separator";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";

export function WebsitePackages() {
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Website Packages | Web Expert Solutions</title>
        <meta 
          name="description" 
          content="Explore our website development packages. From simple static websites to complex e-commerce platforms, we have the perfect solution for your business needs." 
        />
      </Helmet>

      <Header />

      <main className="flex-grow">
        <section className="bg-gradient-to-b from-slate-50 to-white py-12 md:py-24">
          <div className="container px-4 mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Website Development Packages</h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-12">
              Choose from our range of website packages designed to suit your business requirements. 
              From simple landing pages to complex e-commerce solutions, we have the perfect option for you.
            </p>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <WebPackages />
          </div>
        </section>

        <Separator />

        <section className="py-16 bg-slate-50">
          <div className="container px-4 mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold mb-6">Custom Website Requirements?</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  Our packages are designed to cover most common needs, but we understand that every business is unique.
                  If you have specific requirements that aren't covered by our standard packages, we're happy to create a custom solution for you.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Tailored to your specific business needs</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Custom functionalities and integrations</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Dedicated project manager and development team</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Priority support and maintenance</p>
                  </div>
                </div>
              </div>
              <div>
                <QuoteRequestForm serviceType="website" />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}