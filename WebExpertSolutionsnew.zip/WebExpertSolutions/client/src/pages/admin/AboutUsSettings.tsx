import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { AdminLayout } from '@/layouts/AdminLayout';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent,
  CardFooter 
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { AlertCircle, PlusCircle, Trash2, Edit, Eye } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

// Form schemas
const aboutUsFormSchema = z.object({
  title: z.string().min(1, "Title is required"),
  mission: z.string().min(1, "Mission statement is required"),
  vision: z.string().min(1, "Vision statement is required"),
  history: z.string().min(1, "Company history is required"),
  values: z.string().min(1, "Company values are required"),
  teamDescription: z.string().min(1, "Team description is required"),
  metaDescription: z.string().min(1, "Meta description is required"),
});

const teamMemberFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  position: z.string().min(1, "Position is required"),
  bio: z.string().min(1, "Bio is required"),
  imageUrl: z.string().url("Valid image URL is required"),
  socialLinks: z.object({
    linkedin: z.string().url("Valid LinkedIn URL is required").optional().or(z.literal("")),
    twitter: z.string().url("Valid Twitter URL is required").optional().or(z.literal("")),
    github: z.string().url("Valid GitHub URL is required").optional().or(z.literal("")),
    email: z.string().email("Valid email is required").optional().or(z.literal("")),
  }),
  order: z.number().int().positive(),
  isActive: z.boolean().default(true),
});

type AboutUsFormValues = z.infer<typeof aboutUsFormSchema>;
type TeamMemberFormValues = z.infer<typeof teamMemberFormSchema>;

const AboutUsSettings = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("about");
  const [editingTeamMember, setEditingTeamMember] = useState<any | null>(null);
  const [isTeamMemberDialogOpen, setIsTeamMemberDialogOpen] = useState(false);

  // Queries
  const { data: aboutUs, isLoading: aboutUsLoading } = useQuery({
    queryKey: ['/api/about-us'],
  });

  const { data: teamMembers, isLoading: teamMembersLoading } = useQuery({
    queryKey: ['/api/admin/team-members'],
  });

  // About Us form
  const aboutUsForm = useForm<AboutUsFormValues>({
    resolver: zodResolver(aboutUsFormSchema),
    defaultValues: {
      title: aboutUs?.title || '',
      mission: aboutUs?.mission || '',
      vision: aboutUs?.vision || '',
      history: aboutUs?.history || '',
      values: aboutUs?.values || '',
      teamDescription: aboutUs?.teamDescription || '',
      metaDescription: aboutUs?.metaDescription || '',
    },
  });

  // Team Member form
  const teamMemberForm = useForm<TeamMemberFormValues>({
    resolver: zodResolver(teamMemberFormSchema),
    defaultValues: {
      name: '',
      position: '',
      bio: '',
      imageUrl: '',
      socialLinks: {
        linkedin: '',
        twitter: '',
        github: '',
        email: '',
      },
      order: 1,
      isActive: true,
    },
  });

  // Update forms when data loads
  React.useEffect(() => {
    if (aboutUs) {
      aboutUsForm.reset({
        title: aboutUs.title || '',
        mission: aboutUs.mission || '',
        vision: aboutUs.vision || '',
        history: aboutUs.history || '',
        values: aboutUs.values || '',
        teamDescription: aboutUs.teamDescription || '',
        metaDescription: aboutUs.metaDescription || '',
      });
    }
  }, [aboutUs, aboutUsForm]);

  React.useEffect(() => {
    if (editingTeamMember) {
      teamMemberForm.reset({
        name: editingTeamMember.name || '',
        position: editingTeamMember.position || '',
        bio: editingTeamMember.bio || '',
        imageUrl: editingTeamMember.imageUrl || '',
        socialLinks: {
          linkedin: editingTeamMember.socialLinks?.linkedin || '',
          twitter: editingTeamMember.socialLinks?.twitter || '',
          github: editingTeamMember.socialLinks?.github || '',
          email: editingTeamMember.socialLinks?.email || '',
        },
        order: editingTeamMember.order || 1,
        isActive: editingTeamMember.isActive !== false,
      });
    } else {
      teamMemberForm.reset({
        name: '',
        position: '',
        bio: '',
        imageUrl: '',
        socialLinks: {
          linkedin: '',
          twitter: '',
          github: '',
          email: '',
        },
        order: teamMembers?.length ? teamMembers.length + 1 : 1,
        isActive: true,
      });
    }
  }, [editingTeamMember, teamMemberForm, teamMembers]);

  // Mutations
  const updateAboutUsMutation = useMutation({
    mutationFn: async (data: AboutUsFormValues) => {
      return await apiRequest('POST', '/api/admin/about-us', data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "About Us information has been updated.",
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({queryKey: ['/api/about-us']});
      queryClient.invalidateQueries({queryKey: ['/api/team-members']});
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update About Us information.",
        variant: "destructive",
      });
      console.error("Error updating About Us:", error);
    }
  });

  const createTeamMemberMutation = useMutation({
    mutationFn: async (data: TeamMemberFormValues) => {
      return await apiRequest('POST', '/api/admin/team-members', data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Team member has been added.",
      });
      setIsTeamMemberDialogOpen(false);
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({queryKey: ['/api/admin/team-members']});
      queryClient.invalidateQueries({queryKey: ['/api/team-members']});
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add team member.",
        variant: "destructive",
      });
      console.error("Error adding team member:", error);
    }
  });

  const updateTeamMemberMutation = useMutation({
    mutationFn: async (data: {id: number, data: TeamMemberFormValues}) => {
      return await apiRequest('PUT', `/api/admin/team-members/${data.id}`, data.data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Team member has been updated.",
      });
      setIsTeamMemberDialogOpen(false);
      setEditingTeamMember(null);
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({queryKey: ['/api/admin/team-members']});
      queryClient.invalidateQueries({queryKey: ['/api/team-members']});
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update team member.",
        variant: "destructive",
      });
      console.error("Error updating team member:", error);
    }
  });

  const updateTeamMemberStatusMutation = useMutation({
    mutationFn: async (data: {id: number, isActive: boolean}) => {
      return await apiRequest('PUT', `/api/admin/team-members/${data.id}/status`, { isActive: data.isActive });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Team member status has been updated.",
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({queryKey: ['/api/admin/team-members']});
      queryClient.invalidateQueries({queryKey: ['/api/team-members']});
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update team member status.",
        variant: "destructive",
      });
      console.error("Error updating team member status:", error);
    }
  });

  const deleteTeamMemberMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest('DELETE', `/api/admin/team-members/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Team member has been deleted.",
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({queryKey: ['/api/admin/team-members']});
      queryClient.invalidateQueries({queryKey: ['/api/team-members']});
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete team member.",
        variant: "destructive",
      });
      console.error("Error deleting team member:", error);
    }
  });

  // Form submissions
  const onSubmitAboutUs = (data: AboutUsFormValues) => {
    updateAboutUsMutation.mutate(data);
  };

  const onSubmitTeamMember = (data: TeamMemberFormValues) => {
    if (editingTeamMember) {
      updateTeamMemberMutation.mutate({
        id: editingTeamMember.id,
        data
      });
    } else {
      createTeamMemberMutation.mutate(data);
    }
  };

  const handleAddTeamMember = () => {
    setEditingTeamMember(null);
    setIsTeamMemberDialogOpen(true);
  };

  const handleEditTeamMember = (member: any) => {
    setEditingTeamMember(member);
    setIsTeamMemberDialogOpen(true);
  };

  const handleDeleteTeamMember = (id: number) => {
    if (window.confirm("Are you sure you want to delete this team member?")) {
      deleteTeamMemberMutation.mutate(id);
    }
  };

  const handleStatusChange = (id: number, isActive: boolean) => {
    updateTeamMemberStatusMutation.mutate({ id, isActive });
  };

  if (aboutUsLoading || teamMembersLoading) {
    return (
      <AdminLayout>
        <div className="flex justify-center items-center h-64">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-bold mb-8">About Us Settings</h1>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="about">About Us Information</TabsTrigger>
            <TabsTrigger value="team">Team Members</TabsTrigger>
          </TabsList>
          
          <TabsContent value="about">
            <Card>
              <CardHeader>
                <CardTitle>Edit About Us Information</CardTitle>
                <CardDescription>
                  Update the company information displayed on the About Us page
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...aboutUsForm}>
                  <form onSubmit={aboutUsForm.handleSubmit(onSubmitAboutUs)} className="space-y-6">
                    <FormField
                      control={aboutUsForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Page Title</FormLabel>
                          <FormControl>
                            <Input placeholder="About Our Company" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={aboutUsForm.control}
                      name="mission"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Mission Statement</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Our mission is..." 
                              className="min-h-[100px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={aboutUsForm.control}
                      name="vision"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Vision Statement</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Our vision is..." 
                              className="min-h-[100px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={aboutUsForm.control}
                      name="values"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Values</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Excellence - We strive for the best in everything we do.&#10;Integrity - We operate with honesty and transparency." 
                              className="min-h-[150px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                          <p className="text-sm text-gray-500">Enter each value on a new line</p>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={aboutUsForm.control}
                      name="history"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company History</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Our company was founded in..." 
                              className="min-h-[150px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={aboutUsForm.control}
                      name="teamDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Team Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Our team consists of..." 
                              className="min-h-[100px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={aboutUsForm.control}
                      name="metaDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Meta Description (SEO)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Learn about our web development company..." 
                              className="min-h-[80px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                          <p className="text-sm text-gray-500">Used for search engine optimization</p>
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="ml-auto"
                      disabled={updateAboutUsMutation.isPending}
                    >
                      {updateAboutUsMutation.isPending ? "Saving..." : "Save Changes"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="team">
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-2xl font-bold">Team Members</h2>
              <Button onClick={handleAddTeamMember}>
                <PlusCircle className="mr-2 h-4 w-4" /> Add Team Member
              </Button>
            </div>
            
            {teamMembers?.length === 0 ? (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>No team members found</AlertTitle>
                <AlertDescription>
                  Add team members to showcase on your About Us page.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="bg-white rounded-md shadow overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Position</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {teamMembers?.map((member: any) => (
                      <TableRow key={member.id}>
                        <TableCell>{member.order}</TableCell>
                        <TableCell className="font-medium">{member.name}</TableCell>
                        <TableCell>{member.position}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Switch 
                              checked={member.isActive} 
                              onCheckedChange={(checked) => handleStatusChange(member.id, checked)}
                            />
                            <span className={member.isActive ? "text-green-600" : "text-gray-400"}>
                              {member.isActive ? "Active" : "Hidden"}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button 
                              variant="outline" 
                              size="icon"
                              onClick={() => handleEditTeamMember(member)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="outline" 
                              size="icon"
                              onClick={() => handleDeleteTeamMember(member.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
            
            {/* Team Member Dialog */}
            <Dialog 
              open={isTeamMemberDialogOpen} 
              onOpenChange={setIsTeamMemberDialogOpen}
            >
              <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>
                    {editingTeamMember ? "Edit Team Member" : "Add Team Member"}
                  </DialogTitle>
                  <DialogDescription>
                    {editingTeamMember 
                      ? "Update the information for this team member" 
                      : "Add a new team member to showcase on your About Us page"}
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...teamMemberForm}>
                  <form onSubmit={teamMemberForm.handleSubmit(onSubmitTeamMember)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={teamMemberForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name</FormLabel>
                            <FormControl>
                              <Input placeholder="John Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={teamMemberForm.control}
                        name="position"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Position</FormLabel>
                            <FormControl>
                              <Input placeholder="CEO & Founder" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={teamMemberForm.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bio</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="John is a visionary leader with over 10 years of experience..." 
                              className="min-h-[100px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={teamMemberForm.control}
                      name="imageUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Profile Image URL</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="https://example.com/image.jpg" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                          <p className="text-sm text-gray-500">Use a square image (1:1 ratio) for best results</p>
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={teamMemberForm.control}
                        name="socialLinks.linkedin"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>LinkedIn URL (optional)</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="https://linkedin.com/in/username" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={teamMemberForm.control}
                        name="socialLinks.twitter"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Twitter URL (optional)</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="https://twitter.com/username" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={teamMemberForm.control}
                        name="socialLinks.github"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>GitHub URL (optional)</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="https://github.com/username" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={teamMemberForm.control}
                        name="socialLinks.email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email (optional)</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="name@example.com" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={teamMemberForm.control}
                        name="order"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Display Order</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="1"
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                            <p className="text-sm text-gray-500">Lower numbers appear first</p>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={teamMemberForm.control}
                        name="isActive"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                            <div className="space-y-0.5">
                              <FormLabel className="text-base">Active Status</FormLabel>
                              <FormDescription>
                                Show this team member on the website
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <DialogFooter>
                      <Button 
                        type="submit" 
                        disabled={createTeamMemberMutation.isPending || updateTeamMemberMutation.isPending}
                      >
                        {createTeamMemberMutation.isPending || updateTeamMemberMutation.isPending
                          ? "Saving..."
                          : editingTeamMember ? "Update Team Member" : "Add Team Member"
                        }
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
};

export default AboutUsSettings;