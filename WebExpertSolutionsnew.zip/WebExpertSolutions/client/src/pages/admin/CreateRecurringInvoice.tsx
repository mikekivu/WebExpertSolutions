import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { AdminLayout } from "@/layouts/AdminLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { format, addDays, parseISO } from "date-fns";
import {
  Calendar as CalendarIcon,
  Loader2,
  X,
  Plus,
  UserPlus,
  Link,
  Save,
  Trash,
  ArrowLeft,
  CalendarClock,
  CreditCard,
} from "lucide-react";
import { cn } from "@/lib/utils";

// Item Schema
const invoiceItemSchema = z.object({
  description: z.string().min(1, { message: "Description is required" }),
  quantity: z.number().min(1, { message: "Quantity must be at least 1" }),
  unitPrice: z.number().min(0, { message: "Unit price must be at least 0" }),
});

// Form schema for recurring invoice
const recurringInvoiceSchema = z.object({
  userId: z.number().or(z.string()).transform(val => Number(val)),
  billingPlanId: z.number().or(z.string()).transform(val => Number(val)),
  serviceId: z.number().optional().nullable(),
  startDate: z.date(),
  nextBillingDate: z.date(),
  endDate: z.date().optional().nullable(),
  description: z.string().optional(),
  amount: z.number().min(0, { message: "Amount must be at least 0" }),
  tax: z.number().optional(),
  notes: z.string().optional(),
  items: z.array(invoiceItemSchema).optional(),
  status: z.enum(["active", "paused", "cancelled"]).default("active"),
});

export default function CreateRecurringInvoice() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [items, setItems] = useState<any[]>([]);
  const [currentItem, setCurrentItem] = useState<any>({
    description: "",
    quantity: 1,
    unitPrice: 0,
  });
  const [editingItemIndex, setEditingItemIndex] = useState<number | null>(null);

  // Fetch available billing plans
  const { data: billingPlans, isLoading: isLoadingBillingPlans } = useQuery({
    queryKey: ["/api/billing/billing-plans"],
  });

  // Fetch available services
  const { data: services, isLoading: isLoadingServices } = useQuery({
    queryKey: ["/api/services"],
  });

  // Fetch available users
  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
  });

  // Filter only active plans
  const activeBillingPlans = billingPlans?.filter((plan: any) => plan.active) || [];

  // Create form
  const form = useForm<z.infer<typeof recurringInvoiceSchema>>({
    resolver: zodResolver(recurringInvoiceSchema),
    defaultValues: {
      userId: undefined,
      billingPlanId: undefined,
      serviceId: null,
      startDate: new Date(),
      nextBillingDate: new Date(),
      description: "",
      amount: 0,
      tax: 0,
      notes: "",
      status: "active",
    },
  });

  // Create recurring invoice mutation
  const createRecurringInvoiceMutation = useMutation({
    mutationFn: (data: z.infer<typeof recurringInvoiceSchema>) => {
      const payload = {
        ...data,
        items,
      };
      return apiRequest("POST", "/api/billing/recurring-invoices", payload);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Recurring invoice created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/billing/recurring-invoices"] });
      setLocation("/admin/recurring-invoices");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create recurring invoice",
        variant: "destructive",
      });
    },
  });

  // Calculate total based on items
  useEffect(() => {
    if (items.length > 0) {
      const subtotal = items.reduce((sum, item) => {
        return sum + item.quantity * item.unitPrice;
      }, 0);
      
      const tax = form.getValues("tax") || 0;
      const total = subtotal + tax;
      
      form.setValue("amount", total);
    }
  }, [items, form]);

  // Get billing cycle days for a plan
  const getBillingCycleDays = (planId: number) => {
    if (!billingPlans) return 30; // Default to monthly
    
    const plan = billingPlans.find((p: any) => p.id === planId);
    if (!plan) return 30;
    
    switch (plan.billingCycle) {
      case "monthly":
        return 30;
      case "quarterly":
        return 90;
      case "annual":
        return 365;
      default:
        return 30;
    }
  };

  // Update next billing date when start date or billing plan changes
  useEffect(() => {
    const startDate = form.getValues("startDate");
    const billingPlanId = form.getValues("billingPlanId");
    
    if (startDate && billingPlanId) {
      const cycleDays = getBillingCycleDays(Number(billingPlanId));
      const nextDate = addDays(startDate, cycleDays);
      form.setValue("nextBillingDate", nextDate);
    }
  }, [form.watch("startDate"), form.watch("billingPlanId")]);

  // Add item to list
  const addItem = () => {
    if (!currentItem.description || currentItem.quantity < 1) {
      toast({
        title: "Invalid Item",
        description: "Please provide a description and valid quantity",
        variant: "destructive",
      });
      return;
    }

    if (editingItemIndex !== null) {
      // Update existing item
      const updatedItems = [...items];
      updatedItems[editingItemIndex] = {
        ...currentItem,
        amount: currentItem.quantity * currentItem.unitPrice,
      };
      setItems(updatedItems);
      setEditingItemIndex(null);
    } else {
      // Add new item
      setItems([
        ...items,
        {
          ...currentItem,
          amount: currentItem.quantity * currentItem.unitPrice,
        },
      ]);
    }

    // Reset current item
    setCurrentItem({
      description: "",
      quantity: 1,
      unitPrice: 0,
    });
  };

  // Edit existing item
  const editItem = (index: number) => {
    setCurrentItem(items[index]);
    setEditingItemIndex(index);
  };

  // Remove item from list
  const removeItem = (index: number) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    setItems(newItems);
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency: "KES",
    }).format(amount);
  };

  // Handle form submission
  const onSubmit = (data: z.infer<typeof recurringInvoiceSchema>) => {
    const payload = {
      ...data,
      items, // Include the items list
    };
    createRecurringInvoiceMutation.mutate(payload);
  };

  // Calculate total amount
  const calculateTotal = () => {
    if (items.length === 0) return 0;
    
    const subtotal = items.reduce((sum, item) => {
      return sum + item.quantity * item.unitPrice;
    }, 0);
    
    const tax = form.getValues("tax") || 0;
    return subtotal + tax;
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Create Recurring Invoice | Admin Dashboard</title>
      </Helmet>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <Button
              variant="outline"
              size="sm"
              className="mr-4"
              onClick={() => setLocation("/admin/recurring-invoices")}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Recurring Invoices
            </Button>
            <h1 className="text-2xl font-bold">Create Recurring Invoice</h1>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <CalendarClock className="h-5 w-5 text-primary" />
                  Recurring Invoice Details
                </CardTitle>
                <CardDescription>
                  Set up a new billing subscription for automatic invoicing
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Client Selection */}
                      <FormField
                        control={form.control}
                        name="userId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Client *</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value?.toString()}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select client" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {isLoadingUsers ? (
                                  <div className="flex items-center justify-center p-4">
                                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                                  </div>
                                ) : (
                                  users?.map((user: any) => (
                                    <SelectItem key={user.id} value={user.id.toString()}>
                                      <div className="flex items-center">
                                        <UserPlus className="h-4 w-4 mr-2 text-muted-foreground" />
                                        <span>
                                          {user.fullName || user.username || user.email}
                                        </span>
                                      </div>
                                    </SelectItem>
                                  ))
                                )}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Billing Plan Selection */}
                      <FormField
                        control={form.control}
                        name="billingPlanId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Billing Plan *</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value?.toString()}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select billing plan" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {isLoadingBillingPlans ? (
                                  <div className="flex items-center justify-center p-4">
                                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                                  </div>
                                ) : activeBillingPlans.length > 0 ? (
                                  activeBillingPlans.map((plan: any) => (
                                    <SelectItem key={plan.id} value={plan.id.toString()}>
                                      <div className="flex flex-col">
                                        <span>{plan.name}</span>
                                        <span className="text-xs text-muted-foreground">
                                          {plan.billingCycle.charAt(0).toUpperCase() +
                                            plan.billingCycle.slice(1)}{" "}
                                          billing
                                        </span>
                                      </div>
                                    </SelectItem>
                                  ))
                                ) : (
                                  <div className="p-2 text-center text-sm text-muted-foreground">
                                    No active billing plans. Please create one first.
                                  </div>
                                )}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Service Selection */}
                    <FormField
                      control={form.control}
                      name="serviceId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Related Service (Optional)</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value?.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select service (optional)" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="none">None</SelectItem>
                              {isLoadingServices ? (
                                <div className="flex items-center justify-center p-4">
                                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                                </div>
                              ) : (
                                services?.map((service: any) => (
                                  <SelectItem key={service.id} value={service.id.toString()}>
                                    <div className="flex items-center">
                                      <Link className="h-4 w-4 mr-2 text-muted-foreground" />
                                      <span>{service.name}</span>
                                    </div>
                                  </SelectItem>
                                ))
                              )}
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Link this subscription to a specific service
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Start Date */}
                      <FormField
                        control={form.control}
                        name="startDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Start Date *</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={cn(
                                      "pl-3 text-left font-normal",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormDescription>
                              When the subscription begins
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Next Billing Date */}
                      <FormField
                        control={form.control}
                        name="nextBillingDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Next Billing Date *</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={cn(
                                      "pl-3 text-left font-normal",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormDescription>
                              When the next invoice will be generated
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* End Date (Optional) */}
                    <FormField
                      control={form.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>End Date (Optional)</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                  )}
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>No end date</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value || undefined}
                                onSelect={field.onChange}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormDescription>
                            Leave empty for ongoing subscriptions
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Description */}
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description (Optional)</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="e.g., Monthly premium hosting services"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Invoice Items */}
                    <div className="space-y-4">
                      <h3 className="text-md font-medium">Invoice Items</h3>
                      
                      {/* Item Form */}
                      <div className="grid grid-cols-12 gap-3">
                        <div className="col-span-5">
                          <Input
                            placeholder="Description"
                            value={currentItem.description}
                            onChange={(e) =>
                              setCurrentItem({
                                ...currentItem,
                                description: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="col-span-2">
                          <Input
                            type="number"
                            min={1}
                            placeholder="Qty"
                            value={currentItem.quantity}
                            onChange={(e) =>
                              setCurrentItem({
                                ...currentItem,
                                quantity: parseInt(e.target.value) || 0,
                              })
                            }
                          />
                        </div>
                        <div className="col-span-3">
                          <Input
                            type="number"
                            min={0}
                            step={0.01}
                            placeholder="Unit Price"
                            value={currentItem.unitPrice}
                            onChange={(e) =>
                              setCurrentItem({
                                ...currentItem,
                                unitPrice: parseFloat(e.target.value) || 0,
                              })
                            }
                          />
                        </div>
                        <div className="col-span-2">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={addItem}
                            className="w-full"
                          >
                            {editingItemIndex !== null ? "Update" : "Add"}
                          </Button>
                        </div>
                      </div>

                      {/* Items List */}
                      {items.length > 0 ? (
                        <div className="border rounded-md overflow-hidden">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-muted/50">
                              <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                                  Description
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                                  Quantity
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                                  Unit Price
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                                  Amount
                                </th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">
                                  Actions
                                </th>
                              </tr>
                            </thead>
                            <tbody className="bg-card divide-y divide-gray-200">
                              {items.map((item, index) => (
                                <tr key={index}>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    {item.description}
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    {item.quantity}
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    {formatCurrency(item.unitPrice)}
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    {formatCurrency(item.quantity * item.unitPrice)}
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-right">
                                    <div className="flex justify-end gap-2">
                                      <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => editItem(index)}
                                      >
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                      <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => removeItem(index)}
                                        className="text-red-500"
                                      >
                                        <Trash className="h-4 w-4" />
                                      </Button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <div className="text-center p-4 border rounded-md text-muted-foreground">
                          <p>No items added yet</p>
                          <p className="text-xs mt-1">
                            Add at least one item to create the invoice
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Tax Amount */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="tax"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tax Amount (Optional)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                min={0}
                                step={0.01}
                                placeholder="0.00"
                                {...field}
                                onChange={(e) => {
                                  const value = parseFloat(e.target.value) || 0;
                                  field.onChange(value);
                                  // Update amount when tax changes
                                  const subtotal = items.reduce(
                                    (sum, item) => sum + item.quantity * item.unitPrice,
                                    0
                                  );
                                  form.setValue("amount", subtotal + value);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Status */}
                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Status</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="active">Active</SelectItem>
                                <SelectItem value="paused">Paused</SelectItem>
                                <SelectItem value="cancelled">Cancelled</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Notes */}
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes (Optional)</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Any additional notes about this subscription"
                              className="resize-none"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex justify-end space-x-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setLocation("/admin/recurring-invoices")}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={createRecurringInvoiceMutation.isPending || items.length === 0}
                      >
                        {createRecurringInvoiceMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Creating...
                          </>
                        ) : (
                          <>
                            <Save className="mr-2 h-4 w-4" />
                            Create Recurring Invoice
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  Invoice Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Subtotal:</span>
                    <span>
                      {formatCurrency(
                        items.reduce(
                          (sum, item) => sum + item.quantity * item.unitPrice,
                          0
                        )
                      )}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Tax:</span>
                    <span>{formatCurrency(form.getValues("tax") || 0)}</span>
                  </div>
                  <div className="border-t pt-4 flex justify-between items-center font-medium">
                    <span>Total Amount:</span>
                    <span className="text-xl">{formatCurrency(calculateTotal())}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col items-start">
                <p className="text-sm text-muted-foreground">
                  This invoice will automatically renew based on the billing plan
                  schedule.
                </p>
              </CardFooter>
            </Card>

            <Card className="mt-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-md">Billing Schedule</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex flex-col space-y-1">
                    <span className="text-sm font-medium">Start Date</span>
                    <span className="text-sm text-muted-foreground">
                      {form.getValues("startDate")
                        ? format(form.getValues("startDate"), "PPP")
                        : "Not set"}
                    </span>
                  </div>
                  <div className="flex flex-col space-y-1">
                    <span className="text-sm font-medium">First Billing Date</span>
                    <span className="text-sm text-muted-foreground">
                      {form.getValues("nextBillingDate")
                        ? format(form.getValues("nextBillingDate"), "PPP")
                        : "Not set"}
                    </span>
                  </div>
                  <div className="flex flex-col space-y-1">
                    <span className="text-sm font-medium">Billing Cycle</span>
                    <span className="text-sm text-muted-foreground">
                      {form.getValues("billingPlanId") && billingPlans
                        ? (() => {
                            const plan = billingPlans.find(
                              (p: any) => p.id === Number(form.getValues("billingPlanId"))
                            );
                            if (!plan) return "Unknown";
                            const cycle = plan.billingCycle;
                            return cycle.charAt(0).toUpperCase() + cycle.slice(1);
                          })()
                        : "Not selected"}
                    </span>
                  </div>
                  <div className="flex flex-col space-y-1">
                    <span className="text-sm font-medium">End Date</span>
                    <span className="text-sm text-muted-foreground">
                      {form.getValues("endDate")
                        ? format(form.getValues("endDate"), "PPP")
                        : "No end date (ongoing)"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}