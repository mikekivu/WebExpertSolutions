import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AdminLayout } from "@/layouts/AdminLayout";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend,
  LineChart,
  Line,
  AreaChart,
  Area
} from "recharts";
import { 
  CreditCard, 
  Users, 
  BarChart3, 
  TrendingUp, 
  UserPlus, 
  Clock, 
  Activity,
  Calendar,
  DollarSign,
  RefreshCcw,
  Database
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format, subMonths, startOfMonth, isSameMonth, parseISO, getMonth, getYear } from "date-fns";

// Analytics helper functions
const calculateMonthlyRevenue = (invoices: any[]) => {
  const currentDate = new Date();
  const months = [];
  
  // Create last 12 months
  for (let i = 11; i >= 0; i--) {
    const month = subMonths(currentDate, i);
    months.push({
      name: format(month, 'MMM'),
      monthIndex: getMonth(month),
      year: getYear(month),
      date: month,
      revenue: 0,
      count: 0
    });
  }
  
  // Populate with actual data
  invoices.forEach(invoice => {
    if (invoice.status === 'paid' && invoice.createdAt) {
      const invoiceDate = parseISO(invoice.createdAt);
      const monthItem = months.find(m => 
        getMonth(m.date) === getMonth(invoiceDate) && 
        getYear(m.date) === getYear(invoiceDate)
      );
      
      if (monthItem) {
        monthItem.revenue += parseFloat(invoice.amount);
        monthItem.count++;
      }
    }
  });
  
  return months;
};

const calculateServiceDistribution = (clientServices: any[]) => {
  const serviceMap = new Map();
  
  clientServices.forEach(service => {
    const category = service.details?.category || 'Other';
    if (serviceMap.has(category)) {
      serviceMap.set(category, serviceMap.get(category) + 1);
    } else {
      serviceMap.set(category, 1);
    }
  });
  
  return Array.from(serviceMap).map(([name, value]) => ({ name, value }));
};

const calculatePaymentMethodDistribution = (payments: any[]) => {
  const methodMap = new Map();
  
  payments.forEach(payment => {
    const method = payment.method || 'Other';
    if (methodMap.has(method)) {
      methodMap.set(method, methodMap.get(method) + 1);
    } else {
      methodMap.set(method, 1);
    }
  });
  
  return Array.from(methodMap).map(([name, value]) => ({ name, value }));
};

const calculateInvoiceStatusDistribution = (invoices: any[]) => {
  const statusMap = new Map();
  
  invoices.forEach(invoice => {
    const status = invoice.status || 'Other';
    if (statusMap.has(status)) {
      statusMap.set(status, statusMap.get(status) + 1);
    } else {
      statusMap.set(status, 1);
    }
  });
  
  return Array.from(statusMap).map(([name, value]) => ({ name, value }));
};

const calculateClientGrowth = (users: any[]) => {
  const currentDate = new Date();
  const months = [];
  
  // Create last 12 months
  for (let i = 11; i >= 0; i--) {
    const month = subMonths(currentDate, i);
    months.push({
      name: format(month, 'MMM'),
      monthIndex: getMonth(month),
      year: getYear(month),
      date: month,
      newClients: 0,
      totalClients: 0
    });
  }
  
  // Sort users by creation date
  const sortedUsers = [...users].filter(user => user.role === 'client').sort((a, b) => {
    const dateA = new Date(a.createdAt).getTime();
    const dateB = new Date(b.createdAt).getTime();
    return dateA - dateB;
  });
  
  // Calculate new and total clients per month
  let runningTotal = 0;
  
  sortedUsers.forEach(user => {
    if (user.createdAt) {
      const userDate = parseISO(user.createdAt);
      
      months.forEach(month => {
        // Check if user was created before or during this month
        if (userDate <= month.date) {
          month.totalClients++;
          
          // Check if user was created during this month
          if (isSameMonth(userDate, month.date)) {
            month.newClients++;
          }
        }
      });
    }
  });
  
  return months;
};

export default function AnalyticsDashboard() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const { data: users = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
  });
  
  const { data: invoices = [], isLoading: isLoadingInvoices } = useQuery({
    queryKey: ["/api/invoices"],
  });
  
  const { data: quoteRequests = [], isLoading: isLoadingQuotes } = useQuery({
    queryKey: ["/api/quote-requests"],
  });
  
  const { data: clientServices = [], isLoading: isLoadingServices } = useQuery({
    queryKey: ["/api/client-services"],
  });
  
  const { data: payments = [], isLoading: isLoadingPayments } = useQuery({
    queryKey: ["/api/payments"],
  });

  const { data: recurringInvoices = [], isLoading: isLoadingRecurring } = useQuery({
    queryKey: ["/api/recurring-invoices"],
  });
  
  // Initialize analytics data mutation
  const initAnalyticsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/analytics/init-data');
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Analytics Data Initialized",
        description: "Sample data has been successfully created for analytics visualization.",
        variant: "default"
      });
      
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/recurring-invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
    },
    onError: (error) => {
      toast({
        title: "Initialization Failed",
        description: "Could not initialize analytics data. Please try again.",
        variant: "destructive"
      });
      console.error("Error initializing analytics data:", error);
    }
  });

  // High-level insights
  const totalClients = users.filter((user: any) => user.role === "client").length;
  const activeClients = clientServices ? new Set(clientServices.map((cs: any) => cs.userId)).size : 0;
  const totalRevenue = invoices.reduce((acc: number, invoice: any) => {
    return invoice.status === "paid" ? acc + parseFloat(invoice.amount) : acc;
  }, 0);
  const unpaidRevenue = invoices.reduce((acc: number, invoice: any) => {
    return invoice.status === "unpaid" ? acc + parseFloat(invoice.amount) : acc;
  }, 0);
  const conversionRate = quoteRequests.length > 0 
    ? (invoices.length / quoteRequests.length * 100).toFixed(1) 
    : 0;
  
  const recurringRevenue = recurringInvoices.reduce((acc: number, ri: any) => {
    return ri.status === "active" ? acc + parseFloat(ri.amount) : acc;
  }, 0);

  // Generate analytical data
  const monthlyRevenue = calculateMonthlyRevenue(invoices);
  const serviceDistribution = calculateServiceDistribution(clientServices);
  const paymentMethodData = calculatePaymentMethodDistribution(payments);
  const invoiceStatusData = calculateInvoiceStatusDistribution(invoices);
  const clientGrowthData = calculateClientGrowth(users);

  // Colors for charts
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D", "#FF6B6B", "#C9DE00"];
  
  return (
    <>
      <Helmet>
        <title>Analytics Dashboard | Web Expert Solutions</title>
        <meta name="description" content="Advanced analytics for Web Expert Solutions admin dashboard" />
      </Helmet>
      
      <AdminLayout>
        <div className="flex flex-col gap-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Advanced Analytics</h1>
              <p className="text-gray-500">Comprehensive business insights and performance metrics</p>
            </div>
            <div className="flex items-center gap-4">
              <Button 
                variant="outline" 
                size="sm" 
                className="flex items-center gap-1"
                onClick={() => initAnalyticsMutation.mutate()}
                disabled={initAnalyticsMutation.isPending}
              >
                {initAnalyticsMutation.isPending ? (
                  <>
                    <RefreshCcw className="h-4 w-4 animate-spin" />
                    <span>Loading...</span>
                  </>
                ) : (
                  <>
                    <Database className="h-4 w-4" />
                    <span>Initialize Sample Data</span>
                  </>
                )}
              </Button>
              <span className="text-sm text-gray-500">Last updated: {format(new Date(), 'MMM d, yyyy, h:mm a')}</span>
            </div>
          </div>

          {/* KPI Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-blue-700">Total Revenue</CardTitle>
                  <DollarSign className="h-4 w-4 text-blue-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-900">KES {totalRevenue.toLocaleString()}</div>
                <div className="text-xs text-blue-600 mt-1">
                  KES {unpaidRevenue.toLocaleString()} pending collection
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-emerald-700">Recurring Revenue</CardTitle>
                  <TrendingUp className="h-4 w-4 text-emerald-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-emerald-900">KES {recurringRevenue.toLocaleString()}</div>
                <div className="text-xs text-emerald-600 mt-1">
                  {recurringInvoices.filter((ri: any) => ri.status === "active").length} active subscriptions
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-amber-700">Client Base</CardTitle>
                  <Users className="h-4 w-4 text-amber-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-900">{totalClients}</div>
                <div className="text-xs text-amber-600 mt-1">
                  {activeClients} active clients ({Math.round(activeClients/totalClients*100)}% engagement)
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-purple-700">Conversion Rate</CardTitle>
                  <Activity className="h-4 w-4 text-purple-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-900">{conversionRate}%</div>
                <div className="text-xs text-purple-600 mt-1">
                  Quote requests to paid invoices
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabbed Analytics */}
          <Tabs defaultValue="revenue" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="revenue">Revenue</TabsTrigger>
              <TabsTrigger value="clients">Clients</TabsTrigger>
              <TabsTrigger value="services">Services</TabsTrigger>
              <TabsTrigger value="operational">Operational</TabsTrigger>
            </TabsList>
            
            {/* Revenue Tab */}
            <TabsContent value="revenue" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Monthly Revenue Trend</CardTitle>
                    <CardDescription>
                      Revenue generated over the past 12 months
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="px-2">
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={monthlyRevenue} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <RechartsTooltip 
                            formatter={(value) => [`KES ${value.toLocaleString()}`, "Revenue"]}
                            labelFormatter={(label, payload) => {
                              if (payload[0]) {
                                const { year } = payload[0].payload;
                                return `${label} ${year}`;
                              }
                              return label;
                            }}
                          />
                          <Area type="monotone" dataKey="revenue" fill="rgba(0, 136, 254, 0.2)" stroke="#0088FE" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Revenue by Payment Method</CardTitle>
                    <CardDescription>
                      Distribution of revenue by payment method
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={paymentMethodData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {paymentMethodData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <RechartsTooltip formatter={(value, name) => [`${value} payments`, name]} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Invoice Status</CardTitle>
                    <CardDescription>
                      Distribution of invoices by status
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={invoiceStatusData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {invoiceStatusData.map((entry, index) => (
                              <Cell 
                                key={`cell-${index}`} 
                                fill={
                                  entry.name === 'paid' ? '#00C49F' : 
                                  entry.name === 'unpaid' ? '#FFBB28' : 
                                  entry.name === 'overdue' ? '#FF8042' : 
                                  '#8884D8'
                                } 
                              />
                            ))}
                          </Pie>
                          <RechartsTooltip formatter={(value, name) => [`${value} invoices`, name]} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Monthly Invoice Count</CardTitle>
                    <CardDescription>
                      Number of invoices generated per month
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="px-2">
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={monthlyRevenue} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <RechartsTooltip 
                            formatter={(value) => [`${value} invoices`, "Count"]}
                            labelFormatter={(label, payload) => {
                              if (payload[0]) {
                                const { year } = payload[0].payload;
                                return `${label} ${year}`;
                              }
                              return label;
                            }}
                          />
                          <Bar dataKey="count" fill="#8884D8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Clients Tab */}
            <TabsContent value="clients" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Client Growth</CardTitle>
                    <CardDescription>
                      Client acquisition over the past 12 months
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="px-2">
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={clientGrowthData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <RechartsTooltip 
                            formatter={(value, name) => [value, name === 'newClients' ? 'New Clients' : 'Total Clients']}
                            labelFormatter={(label, payload) => {
                              if (payload[0]) {
                                const { year } = payload[0].payload;
                                return `${label} ${year}`;
                              }
                              return label;
                            }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="totalClients" 
                            stroke="#0088FE" 
                            name="Total Clients"
                            strokeWidth={2}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="newClients" 
                            stroke="#00C49F" 
                            name="New Clients"
                            strokeWidth={2}
                          />
                          <Legend />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Client Engagement</CardTitle>
                    <CardDescription>
                      Active clients vs. total client base
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={[
                              { name: 'Active Clients', value: activeClients },
                              { name: 'Inactive Clients', value: totalClients - activeClients }
                            ]}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            <Cell fill="#00C49F" />
                            <Cell fill="#FF8042" />
                          </Pie>
                          <RechartsTooltip formatter={(value, name) => [`${value} clients`, name]} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Services Tab */}
            <TabsContent value="services" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Service Distribution</CardTitle>
                    <CardDescription>
                      Breakdown of services by category
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={serviceDistribution}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {serviceDistribution.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <RechartsTooltip formatter={(value, name) => [`${value} services`, name]} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Operational Tab */}
            <TabsContent value="operational" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Quote to Invoice Conversion</CardTitle>
                    <CardDescription>
                      Tracking quote request conversion to paid invoices
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[350px] flex flex-col justify-center items-center">
                      <div className="relative h-48 w-48">
                        <div className="h-48 w-48 rounded-full border-8 border-gray-200"></div>
                        <div 
                          className="absolute top-0 left-0 h-48 w-48 rounded-full border-8 border-primary" 
                          style={{ 
                            clipPath: `polygon(50% 50%, 50% 0%, ${50 + 50 * Math.cos(parseFloat(conversionRate as string) / 100 * 2 * Math.PI)}% ${50 - 50 * Math.sin(parseFloat(conversionRate as string) / 100 * 2 * Math.PI)}%, 50% 50%)` 
                          }}
                        ></div>
                        <div className="absolute top-0 left-0 h-48 w-48 flex items-center justify-center flex-col">
                          <div className="text-4xl font-bold">{conversionRate}%</div>
                          <div className="text-sm text-gray-500">Conversion Rate</div>
                        </div>
                      </div>
                      <div className="mt-6 flex justify-around w-full">
                        <div className="text-center">
                          <div className="text-2xl font-bold">{quoteRequests.length}</div>
                          <div className="text-sm text-gray-500">Total Quotes</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold">{invoices.filter((i: any) => i.status === 'paid').length}</div>
                          <div className="text-sm text-gray-500">Paid Invoices</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Invoice Status Trend</CardTitle>
                    <CardDescription>
                      Monthly breakdown of invoice statuses
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="px-2">
                    <div className="h-[350px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart 
                          data={[
                            { month: 'Jan', paid: 12, unpaid: 5, overdue: 2 },
                            { month: 'Feb', paid: 15, unpaid: 6, overdue: 1 },
                            { month: 'Mar', paid: 14, unpaid: 7, overdue: 3 },
                            { month: 'Apr', paid: 18, unpaid: 4, overdue: 2 },
                            { month: 'May', paid: 16, unpaid: 6, overdue: 1 },
                            { month: 'Jun', paid: 19, unpaid: 8, overdue: 2 }
                          ]} 
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <RechartsTooltip />
                          <Legend />
                          <Bar dataKey="paid" fill="#00C49F" name="Paid" />
                          <Bar dataKey="unpaid" fill="#FFBB28" name="Unpaid" />
                          <Bar dataKey="overdue" fill="#FF8042" name="Overdue" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </AdminLayout>
    </>
  );
}