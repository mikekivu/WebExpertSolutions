import { useQuery } from "@tanstack/react-query";
import { AdminLayout } from "@/layouts/AdminLayout";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Helmet } from "react-helmet";
import { Link } from "wouter";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from "recharts";
import { Users, CreditCard, FileText, BellRing, Clock } from "lucide-react";
import { format } from "date-fns";

export default function AdminDashboard() {
  const { data: users = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
  });
  
  const { data: invoices = [], isLoading: isLoadingInvoices } = useQuery({
    queryKey: ["/api/invoices"],
  });
  
  const { data: quoteRequests = [], isLoading: isLoadingQuotes } = useQuery({
    queryKey: ["/api/quote-requests"],
  });

  // Stats calculations
  const totalClients = users.filter((user: any) => user.role === "client").length;
  const totalInvoices = invoices.length;
  const totalRevenue = invoices.reduce((acc: number, invoice: any) => {
    return invoice.status === "paid" ? acc + parseFloat(invoice.amount) : acc;
  }, 0);
  const pendingQuotes = quoteRequests.filter((quote: any) => quote.status === "pending").length;

  // Monthly revenue data
  const monthlyRevenueData = [
    { name: "Jan", revenue: 4200 },
    { name: "Feb", revenue: 5800 },
    { name: "Mar", revenue: 4900 },
    { name: "Apr", revenue: 6800 },
    { name: "May", revenue: 7200 },
    { name: "Jun", revenue: 8100 },
    { name: "Jul", revenue: 7600 },
    { name: "Aug", revenue: 9200 },
    { name: "Sep", revenue: 8400 },
    { name: "Oct", revenue: 10100 },
    { name: "Nov", revenue: 9600 },
    { name: "Dec", revenue: 11200 }
  ];

  // Service distribution data
  const serviceDistributionData = [
    { name: "Web Development", value: 35 },
    { name: "Mobile Apps", value: 20 },
    { name: "Software", value: 15 },
    { name: "Hosting", value: 18 },
    { name: "Domain", value: 7 },
    { name: "Bulk SMS", value: 3 },
    { name: "Digital Marketing", value: 12 }
  ];

  // Colors for pie chart
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D", "#FF6B6B"];

  // Recent activities (would usually come from API)
  const recentActivities = [
    { id: 1, type: "quote", message: "New quote request from John Smith", time: "2 hours ago" },
    { id: 2, type: "invoice", message: "Invoice #INV-20231201-4567 was paid", time: "4 hours ago" },
    { id: 3, type: "client", message: "New client registered: Emily Johnson", time: "Yesterday" },
    { id: 4, type: "service", message: "Web hosting service renewed for TechCorp Ltd", time: "2 days ago" }
  ];

  return (
    <>
      <Helmet>
        <title>Admin Dashboard | Web Expert Solutions</title>
        <meta name="description" content="Admin dashboard for managing clients, services, invoices and quotes" />
      </Helmet>
      
      <AdminLayout>
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-gray-500">Welcome to your admin dashboard</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalClients}</div>
                <p className="text-xs text-muted-foreground">
                  +{Math.floor(Math.random() * 10)} new this month
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Revenue</CardTitle>
                <CreditCard className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">KES {totalRevenue.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  +{Math.floor(Math.random() * 20)}% from last month
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Invoices</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalInvoices}</div>
                <p className="text-xs text-muted-foreground">
                  {invoices.filter((invoice: any) => invoice.status === "unpaid").length} unpaid
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Quotes</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{pendingQuotes}</div>
                <p className="text-xs text-muted-foreground">
                  Requires your attention
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Revenue</CardTitle>
                <CardDescription>
                  Revenue generated each month in 2023
                </CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyRevenueData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`KES ${value}`, "Revenue"]}
                        labelFormatter={(label) => `${label} 2023`}
                      />
                      <Bar dataKey="revenue" fill="var(--chart-1)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Service Distribution</CardTitle>
                <CardDescription>
                  Breakdown of services by category
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={serviceDistributionData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {serviceDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, "Percentage"]} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>
                Latest actions and events
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex">
                    <div className="relative mr-4">
                      <div className={`absolute top-0 left-0 bg-${activity.type === "quote" ? "yellow" : activity.type === "invoice" ? "green" : activity.type === "client" ? "blue" : "purple"}-500 h-8 w-8 rounded-full flex items-center justify-center text-white`}>
                        {activity.type === "quote" && <FileText className="h-4 w-4" />}
                        {activity.type === "invoice" && <CreditCard className="h-4 w-4" />}
                        {activity.type === "client" && <Users className="h-4 w-4" />}
                        {activity.type === "service" && <Clock className="h-4 w-4" />}
                      </div>
                      <div className="h-full w-px bg-gray-200 absolute top-10 left-4"></div>
                    </div>
                    <div className="pb-8">
                      <div className="text-sm font-medium">{activity.message}</div>
                      <div className="text-sm text-gray-500">{activity.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/admin/quotes" className="text-sm text-primary hover:underline">
                View all activity
              </Link>
            </CardFooter>
          </Card>
        </div>
      </AdminLayout>
    </>
  );
}
