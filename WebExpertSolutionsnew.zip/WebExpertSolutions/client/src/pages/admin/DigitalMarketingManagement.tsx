import { useState } from "react";
import { AdminLayout } from "@/layouts/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Edit, Trash, Plus, BarChart, ArrowUpRight } from "lucide-react";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface MarketingService {
  id: number;
  name: string;
  category: string;
  description: string;
  monthlyPrice: number;
  oneTimeSetupFee?: number;
  includedFeatures: string[];
  featured: boolean;
  status: string;
}

interface MarketingCampaign {
  id: number;
  name: string;
  client?: string;
  clientId?: number;
  type: string;
  status: string;
  startDate: string;
  endDate?: string;
  budget: number;
  spent: number;
  results?: {
    clicks?: number;
    impressions?: number;
    conversions?: number;
    roi?: number;
  };
}

export default function AdminDigitalMarketingManagement() {
  const { toast } = useToast();
  const [isAddServiceDialogOpen, setIsAddServiceDialogOpen] = useState(false);
  const [isEditServiceDialogOpen, setIsEditServiceDialogOpen] = useState(false);
  const [isDeleteServiceDialogOpen, setIsDeleteServiceDialogOpen] = useState(false);
  const [isAddCampaignDialogOpen, setIsAddCampaignDialogOpen] = useState(false);
  const [isViewCampaignDialogOpen, setIsViewCampaignDialogOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<MarketingService | null>(null);
  const [selectedCampaign, setSelectedCampaign] = useState<MarketingCampaign | null>(null);

  // Mock data for marketing services
  const [marketingServices, setMarketingServices] = useState<MarketingService[]>([
    {
      id: 1,
      name: "SEO Essential",
      category: "seo",
      description: "Basic SEO services including keyword research, on-page optimization, and monthly reporting.",
      monthlyPrice: 15000,
      oneTimeSetupFee: 5000,
      includedFeatures: [
        "Keyword research",
        "On-page optimization",
        "Meta tag optimization",
        "Monthly reporting",
        "Basic competitor analysis"
      ],
      featured: true,
      status: "active"
    },
    {
      id: 2,
      name: "Social Media Standard",
      category: "social",
      description: "Social media management for 2 platforms with content creation and engagement monitoring.",
      monthlyPrice: 20000,
      includedFeatures: [
        "Management of 2 platforms",
        "8 posts per month",
        "Content creation",
        "Engagement monitoring",
        "Monthly performance reports"
      ],
      featured: false,
      status: "active"
    },
    {
      id: 3,
      name: "PPC Campaign Management",
      category: "ppc",
      description: "Google Ads and Meta Ads campaign setup, management, and optimization.",
      monthlyPrice: 25000,
      oneTimeSetupFee: 10000,
      includedFeatures: [
        "Campaign strategy development",
        "Ad creation and copywriting",
        "Budget management",
        "Bid optimization",
        "Weekly performance reports",
        "Conversion tracking setup"
      ],
      featured: true,
      status: "active"
    },
    {
      id: 4,
      name: "Content Marketing Package",
      category: "content",
      description: "Blog writing, newsletter creation, and content distribution services.",
      monthlyPrice: 30000,
      includedFeatures: [
        "4 blog posts per month",
        "Monthly newsletter",
        "Content distribution",
        "SEO optimization",
        "Content performance analysis"
      ],
      featured: false,
      status: "active"
    }
  ]);

  // Mock data for marketing campaigns
  const [marketingCampaigns, setMarketingCampaigns] = useState<MarketingCampaign[]>([
    {
      id: 1,
      name: "Summer Promotion - Google Ads",
      client: "TechSolutions Ltd",
      clientId: 3,
      type: "ppc",
      status: "active",
      startDate: "2023-05-01",
      endDate: "2023-08-31",
      budget: 50000,
      spent: 27500,
      results: {
        clicks: 2450,
        impressions: 87000,
        conversions: 105,
        roi: 3.2
      }
    },
    {
      id: 2,
      name: "Website SEO Optimization",
      client: "Health Clinic",
      clientId: 5,
      type: "seo",
      status: "active",
      startDate: "2023-03-15",
      budget: 15000,
      spent: 10000,
      results: {
        clicks: 1800,
        impressions: 45000,
        conversions: 68,
        roi: 2.8
      }
    },
    {
      id: 3,
      name: "Instagram Brand Awareness",
      client: "Fashion Store",
      clientId: 8,
      type: "social",
      status: "completed",
      startDate: "2023-02-01",
      endDate: "2023-04-30",
      budget: 30000,
      spent: 30000,
      results: {
        clicks: 3500,
        impressions: 120000,
        conversions: 180,
        roi: 4.1
      }
    },
    {
      id: 4,
      name: "Content Marketing Strategy",
      client: "Educational Institute",
      clientId: 12,
      type: "content",
      status: "planning",
      startDate: "2023-07-01",
      budget: 45000,
      spent: 0
    }
  ]);

  const handleAddService = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const featuresText = formData.get("features") as string;
    const includedFeatures = featuresText.split('\n').filter(feature => feature.trim() !== '');
    
    const newService: MarketingService = {
      id: marketingServices.length + 1,
      name: formData.get("name") as string,
      category: formData.get("category") as string,
      description: formData.get("description") as string,
      monthlyPrice: Number(formData.get("monthlyPrice")),
      oneTimeSetupFee: formData.get("oneTimeSetupFee") ? Number(formData.get("oneTimeSetupFee")) : undefined,
      includedFeatures,
      featured: formData.get("featured") === "on",
      status: "active"
    };

    setMarketingServices([...marketingServices, newService]);
    setIsAddServiceDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Marketing service has been added successfully.",
    });
  };

  const handleEditService = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedService) return;

    const formData = new FormData(e.currentTarget);
    
    const featuresText = formData.get("features") as string;
    const includedFeatures = featuresText.split('\n').filter(feature => feature.trim() !== '');
    
    const updatedServices = marketingServices.map(service => {
      if (service.id === selectedService.id) {
        return {
          ...service,
          name: formData.get("name") as string,
          category: formData.get("category") as string,
          description: formData.get("description") as string,
          monthlyPrice: Number(formData.get("monthlyPrice")),
          oneTimeSetupFee: formData.get("oneTimeSetupFee") ? Number(formData.get("oneTimeSetupFee")) : undefined,
          includedFeatures,
          featured: formData.get("featured") === "on"
        };
      }
      return service;
    });

    setMarketingServices(updatedServices);
    setIsEditServiceDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Marketing service has been updated successfully.",
    });
  };

  const handleDeleteService = () => {
    if (!selectedService) return;

    const updatedServices = marketingServices.filter(service => service.id !== selectedService.id);
    setMarketingServices(updatedServices);
    setIsDeleteServiceDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Marketing service has been deleted successfully.",
    });
  };

  const handleAddCampaign = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newCampaign: MarketingCampaign = {
      id: marketingCampaigns.length + 1,
      name: formData.get("name") as string,
      client: formData.get("client") as string,
      clientId: formData.get("clientId") ? Number(formData.get("clientId")) : undefined,
      type: formData.get("type") as string,
      status: formData.get("status") as string,
      startDate: formData.get("startDate") as string,
      endDate: formData.get("endDate") ? formData.get("endDate") as string : undefined,
      budget: Number(formData.get("budget")),
      spent: Number(formData.get("spent") || 0)
    };

    setMarketingCampaigns([...marketingCampaigns, newCampaign]);
    setIsAddCampaignDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Marketing campaign has been created successfully.",
    });
  };

  const openEditServiceDialog = (service: MarketingService) => {
    setSelectedService(service);
    setIsEditServiceDialogOpen(true);
  };

  const openDeleteServiceDialog = (service: MarketingService) => {
    setSelectedService(service);
    setIsDeleteServiceDialogOpen(true);
  };

  const openViewCampaignDialog = (campaign: MarketingCampaign) => {
    setSelectedCampaign(campaign);
    setIsViewCampaignDialogOpen(true);
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return "Ongoing";
    
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const getCampaignStatusBadge = (status: string) => {
    switch(status) {
      case 'active':
        return <Badge className="bg-green-500">Active</Badge>;
      case 'planning':
        return <Badge variant="outline">Planning</Badge>;
      case 'completed':
        return <Badge variant="secondary">Completed</Badge>;
      case 'paused':
        return <Badge variant="destructive">Paused</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getCategoryLabel = (category: string) => {
    switch(category) {
      case 'seo': return 'SEO';
      case 'social': return 'Social Media';
      case 'ppc': return 'PPC/Advertising';
      case 'content': return 'Content Marketing';
      case 'email': return 'Email Marketing';
      default: return category;
    }
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Digital Marketing Management | Admin Dashboard</title>
      </Helmet>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Digital Marketing Management</h1>
        </div>

        <Tabs defaultValue="campaigns">
          <TabsList className="mb-4">
            <TabsTrigger value="campaigns">Marketing Campaigns</TabsTrigger>
            <TabsTrigger value="services">Marketing Services</TabsTrigger>
          </TabsList>
          
          {/* Marketing Campaigns Tab */}
          <TabsContent value="campaigns">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Marketing Campaigns</h2>
              <Button onClick={() => setIsAddCampaignDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" /> New Campaign
              </Button>
            </div>
            <Card>
              <CardContent className="p-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Campaign Name</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Timeline</TableHead>
                      <TableHead>Budget</TableHead>
                      <TableHead>Progress</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {marketingCampaigns.map(campaign => (
                      <TableRow key={campaign.id}>
                        <TableCell className="font-medium">{campaign.name}</TableCell>
                        <TableCell>{campaign.client || "N/A"}</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {getCategoryLabel(campaign.type)}
                          </Badge>
                        </TableCell>
                        <TableCell>{getCampaignStatusBadge(campaign.status)}</TableCell>
                        <TableCell>{formatDate(campaign.startDate)} - {formatDate(campaign.endDate)}</TableCell>
                        <TableCell>KSh {campaign.budget.toLocaleString()}</TableCell>
                        <TableCell>
                          <div className="flex flex-col space-y-1">
                            <div className="flex justify-between items-center text-xs">
                              <span>KSh {campaign.spent.toLocaleString()}</span>
                              <span>{campaign.budget > 0 ? Math.round((campaign.spent / campaign.budget) * 100) : 0}%</span>
                            </div>
                            <Progress value={campaign.budget > 0 ? (campaign.spent / campaign.budget) * 100 : 0} className="h-2" />
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" onClick={() => openViewCampaignDialog(campaign)}>
                              <BarChart className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Marketing Services Tab */}
          <TabsContent value="services">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Marketing Services</h2>
              <Button onClick={() => setIsAddServiceDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" /> Add Service
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {marketingServices.map(service => (
                <Card key={service.id} className={service.featured ? "border-primary" : ""}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{service.name}</CardTitle>
                        <Badge variant="outline" className="mt-2">
                          {getCategoryLabel(service.category)}
                        </Badge>
                        {service.featured && <Badge className="ml-2 mt-2">Featured</Badge>}
                      </div>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" onClick={() => openEditServiceDialog(service)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => openDeleteServiceDialog(service)}>
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <div className="text-3xl font-bold mb-1">KSh {service.monthlyPrice.toLocaleString()}</div>
                      <div className="text-sm text-muted-foreground">per month</div>
                      {service.oneTimeSetupFee && (
                        <div className="text-sm text-muted-foreground mt-1">
                          + KSh {service.oneTimeSetupFee.toLocaleString()} setup fee
                        </div>
                      )}
                    </div>
                    <div className="text-sm mb-4">{service.description}</div>
                    <div className="border-t pt-4">
                      <h4 className="font-medium mb-2">Included features:</h4>
                      <ul className="space-y-2 text-sm">
                        {service.includedFeatures.map((feature, index) => (
                          <li key={index} className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Add Service Dialog */}
        <Dialog open={isAddServiceDialogOpen} onOpenChange={setIsAddServiceDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Marketing Service</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddService}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Service Name</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select name="category" defaultValue="seo">
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Select Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="seo">SEO</SelectItem>
                        <SelectItem value="social">Social Media</SelectItem>
                        <SelectItem value="ppc">PPC/Advertising</SelectItem>
                        <SelectItem value="content">Content Marketing</SelectItem>
                        <SelectItem value="email">Email Marketing</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" name="description" rows={2} required />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="monthlyPrice">Monthly Price (KSh)</Label>
                    <Input id="monthlyPrice" name="monthlyPrice" type="number" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="oneTimeSetupFee">One-Time Setup Fee (KSh, optional)</Label>
                    <Input id="oneTimeSetupFee" name="oneTimeSetupFee" type="number" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="features">Included Features (one per line)</Label>
                  <Textarea 
                    id="features" 
                    name="features" 
                    rows={4}
                    placeholder="Keyword research
On-page optimization
Monthly reporting"
                    required 
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="featured" name="featured" />
                  <Label htmlFor="featured">Featured Service</Label>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddServiceDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Edit Service Dialog */}
        <Dialog open={isEditServiceDialogOpen} onOpenChange={setIsEditServiceDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Marketing Service</DialogTitle>
            </DialogHeader>
            {selectedService && (
              <form onSubmit={handleEditService}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-name">Service Name</Label>
                      <Input id="edit-name" name="name" defaultValue={selectedService.name} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-category">Category</Label>
                      <Select name="category" defaultValue={selectedService.category}>
                        <SelectTrigger id="edit-category">
                          <SelectValue placeholder="Select Category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="seo">SEO</SelectItem>
                          <SelectItem value="social">Social Media</SelectItem>
                          <SelectItem value="ppc">PPC/Advertising</SelectItem>
                          <SelectItem value="content">Content Marketing</SelectItem>
                          <SelectItem value="email">Email Marketing</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-description">Description</Label>
                    <Textarea 
                      id="edit-description" 
                      name="description" 
                      rows={2} 
                      defaultValue={selectedService.description}
                      required 
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-monthlyPrice">Monthly Price (KSh)</Label>
                      <Input 
                        id="edit-monthlyPrice" 
                        name="monthlyPrice" 
                        type="number" 
                        defaultValue={selectedService.monthlyPrice}
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-oneTimeSetupFee">One-Time Setup Fee (KSh, optional)</Label>
                      <Input 
                        id="edit-oneTimeSetupFee" 
                        name="oneTimeSetupFee" 
                        type="number" 
                        defaultValue={selectedService.oneTimeSetupFee || ""}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-features">Included Features (one per line)</Label>
                    <Textarea 
                      id="edit-features" 
                      name="features" 
                      rows={4} 
                      defaultValue={selectedService.includedFeatures.join('\n')}
                      required 
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="edit-featured" 
                      name="featured" 
                      checked={selectedService.featured}
                    />
                    <Label htmlFor="edit-featured">Featured Service</Label>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsEditServiceDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Update</Button>
                </DialogFooter>
              </form>
            )}
          </DialogContent>
        </Dialog>

        {/* Delete Service Dialog */}
        <Dialog open={isDeleteServiceDialogOpen} onOpenChange={setIsDeleteServiceDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Deletion</DialogTitle>
            </DialogHeader>
            <p>Are you sure you want to delete the <strong>{selectedService?.name}</strong> service? This action cannot be undone.</p>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDeleteServiceDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="button" variant="destructive" onClick={handleDeleteService}>
                Delete
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        {/* Add Campaign Dialog */}
        <Dialog open={isAddCampaignDialogOpen} onOpenChange={setIsAddCampaignDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Marketing Campaign</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddCampaign}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Campaign Name</Label>
                  <Input id="name" name="name" required />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="client">Client Name</Label>
                    <Input id="client" name="client" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="clientId">Client ID (optional)</Label>
                    <Input id="clientId" name="clientId" type="number" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Campaign Type</Label>
                    <Select name="type" defaultValue="seo">
                      <SelectTrigger id="type">
                        <SelectValue placeholder="Select Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="seo">SEO</SelectItem>
                        <SelectItem value="social">Social Media</SelectItem>
                        <SelectItem value="ppc">PPC/Advertising</SelectItem>
                        <SelectItem value="content">Content Marketing</SelectItem>
                        <SelectItem value="email">Email Marketing</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select name="status" defaultValue="planning">
                      <SelectTrigger id="status">
                        <SelectValue placeholder="Select Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="planning">Planning</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="paused">Paused</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input id="startDate" name="startDate" type="date" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate">End Date (leave blank for ongoing)</Label>
                    <Input id="endDate" name="endDate" type="date" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="budget">Total Budget (KSh)</Label>
                    <Input id="budget" name="budget" type="number" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="spent">Amount Spent (KSh)</Label>
                    <Input id="spent" name="spent" type="number" defaultValue="0" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddCampaignDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Create Campaign</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* View Campaign Dialog */}
        <Dialog open={isViewCampaignDialogOpen} onOpenChange={setIsViewCampaignDialogOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Campaign Details & Analytics</DialogTitle>
            </DialogHeader>
            {selectedCampaign && (
              <div className="grid gap-6 py-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-2xl font-bold">{selectedCampaign.name}</h2>
                    <div className="flex gap-2 mt-1">
                      <Badge variant="outline">{getCategoryLabel(selectedCampaign.type)}</Badge>
                      {getCampaignStatusBadge(selectedCampaign.status)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">Client</div>
                    <div>{selectedCampaign.client || "N/A"}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Campaign Timeline</h3>
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-sm text-muted-foreground">Start Date</div>
                          <div className="font-medium">{formatDate(selectedCampaign.startDate)}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">End Date</div>
                          <div className="font-medium">{formatDate(selectedCampaign.endDate)}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Budget</h3>
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-sm text-muted-foreground">Total Budget</div>
                          <div className="font-medium">KSh {selectedCampaign.budget.toLocaleString()}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Spent</div>
                          <div className="font-medium">KSh {selectedCampaign.spent.toLocaleString()}</div>
                        </div>
                      </div>
                      <div className="mt-2">
                        <div className="flex justify-between items-center text-xs mb-1">
                          <span>Budget Utilization</span>
                          <span>{selectedCampaign.budget > 0 ? Math.round((selectedCampaign.spent / selectedCampaign.budget) * 100) : 0}%</span>
                        </div>
                        <Progress value={selectedCampaign.budget > 0 ? (selectedCampaign.spent / selectedCampaign.budget) * 100 : 0} className="h-2" />
                      </div>
                    </div>
                  </div>
                </div>

                {selectedCampaign.results && (
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Performance Metrics</h3>
                    <div className="grid grid-cols-4 gap-4">
                      {selectedCampaign.results.impressions !== undefined && (
                        <div className="bg-slate-50 p-4 rounded-lg">
                          <div className="text-sm text-muted-foreground">Impressions</div>
                          <div className="text-2xl font-bold">{selectedCampaign.results.impressions.toLocaleString()}</div>
                        </div>
                      )}
                      {selectedCampaign.results.clicks !== undefined && (
                        <div className="bg-slate-50 p-4 rounded-lg">
                          <div className="text-sm text-muted-foreground">Clicks</div>
                          <div className="text-2xl font-bold">{selectedCampaign.results.clicks.toLocaleString()}</div>
                          {selectedCampaign.results.impressions && (
                            <div className="text-xs text-muted-foreground mt-1">
                              CTR: {((selectedCampaign.results.clicks / selectedCampaign.results.impressions) * 100).toFixed(2)}%
                            </div>
                          )}
                        </div>
                      )}
                      {selectedCampaign.results.conversions !== undefined && (
                        <div className="bg-slate-50 p-4 rounded-lg">
                          <div className="text-sm text-muted-foreground">Conversions</div>
                          <div className="text-2xl font-bold">{selectedCampaign.results.conversions.toLocaleString()}</div>
                          {selectedCampaign.results.clicks && (
                            <div className="text-xs text-muted-foreground mt-1">
                              Conv. Rate: {((selectedCampaign.results.conversions / selectedCampaign.results.clicks) * 100).toFixed(2)}%
                            </div>
                          )}
                        </div>
                      )}
                      {selectedCampaign.results.roi !== undefined && (
                        <div className="bg-slate-50 p-4 rounded-lg">
                          <div className="text-sm text-muted-foreground">ROI</div>
                          <div className="text-2xl font-bold">{selectedCampaign.results.roi.toFixed(1)}x</div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div className="flex justify-end mt-2">
                  <Button variant="outline" className="mr-2">
                    <ArrowUpRight className="mr-2 h-4 w-4" /> View Full Report
                  </Button>
                  <Button onClick={() => setIsViewCampaignDialogOpen(false)}>
                    Close
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}