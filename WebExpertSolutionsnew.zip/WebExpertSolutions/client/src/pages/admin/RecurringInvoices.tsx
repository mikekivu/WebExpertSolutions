import { useState } from "react";
import { Helmet } from "react-helmet";
import { AdminLayout } from "@/layouts/AdminLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format, parseISO } from "date-fns";
import {
  Trash2,
  Edit,
  Plus,
  Clock,
  AlertTriangle,
  Pause,
  Play,
  User,
  Calendar,
  DollarSign,
  FileText,
  RefreshCw,
  Loader2,
  Award,
  ArrowUpRight,
  Ban,
} from "lucide-react";

export default function RecurringInvoices() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isStatusDialogOpen, setIsStatusDialogOpen] = useState(false);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [currentInvoice, setCurrentInvoice] = useState<any>(null);
  const [newStatus, setNewStatus] = useState<string>("");

  // Fetch recurring invoices
  const { data: recurringInvoices, isLoading: isLoadingInvoices } = useQuery({
    queryKey: ["/api/billing/recurring-invoices"],
  });

  // Fetch billing plans for reference
  const { data: billingPlans, isLoading: isLoadingBillingPlans } = useQuery({
    queryKey: ["/api/billing/billing-plans"],
  });

  // Fetch services for reference
  const { data: services } = useQuery({
    queryKey: ["/api/services"],
  });

  // Fetch users for reference
  const { data: users } = useQuery({
    queryKey: ["/api/users"],
  });

  // Update recurring invoice status mutation
  const updateInvoiceStatusMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => {
      return apiRequest("PUT", `/api/billing/recurring-invoices/${id}/status`, {
        status,
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Recurring invoice status updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/billing/recurring-invoices"] });
      setIsStatusDialogOpen(false);
      setCurrentInvoice(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update recurring invoice status",
        variant: "destructive",
      });
    },
  });

  // Generate invoices mutation
  const generateInvoicesMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", "/api/billing/process/generate-invoices", {});
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: `Generated ${data.invoices?.length || 0} invoices from recurring billing plans`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to generate invoices from recurring billing plans",
        variant: "destructive",
      });
    },
  });

  // Handle status update
  const handleStatusUpdate = (invoice: any, status: string) => {
    setCurrentInvoice(invoice);
    setNewStatus(status);
    setIsStatusDialogOpen(true);
  };

  // Confirm status update
  const confirmStatusUpdate = () => {
    if (currentInvoice && newStatus) {
      updateInvoiceStatusMutation.mutate({
        id: currentInvoice.id,
        status: newStatus,
      });
    }
  };

  // Show invoice details
  const showInvoiceDetails = (invoice: any) => {
    setCurrentInvoice(invoice);
    setIsDetailsDialogOpen(true);
  };

  // Get user name by ID
  const getUserName = (userId: number) => {
    if (!users) return "Loading...";
    const user = users.find((u: any) => u.id === userId);
    return user ? user.fullName : `User #${userId}`;
  };

  // Get service name by ID
  const getServiceName = (serviceId: number) => {
    if (!services) return "Custom Service";
    const service = services.find((s: any) => s.id === serviceId);
    return service ? service.name : `Service #${serviceId}`;
  };

  // Get billing plan name by ID
  const getBillingPlanName = (planId: number) => {
    if (!billingPlans) return "Loading...";
    const plan = billingPlans.find((p: any) => p.id === planId);
    return plan ? plan.name : `Plan #${planId}`;
  };

  // Format billing cycle
  const formatBillingCycle = (plan: any) => {
    if (!plan) return "Monthly";
    switch (plan.billingCycle) {
      case "monthly":
        return "Monthly";
      case "quarterly":
        return "Quarterly";
      case "annual":
        return "Annual";
      default:
        return plan.billingCycle;
    }
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency: "KES",
    }).format(amount);
  };

  // Format date
  const formatDate = (dateString: string) => {
    try {
      return format(parseISO(dateString), "MMM d, yyyy");
    } catch (error) {
      return dateString;
    }
  };

  // Get status badge properties
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return {
          label: "Active",
          color: "bg-green-100 text-green-800 border-green-200",
          icon: <Play className="h-3 w-3 mr-1" />,
        };
      case "paused":
        return {
          label: "Paused",
          color: "bg-amber-100 text-amber-800 border-amber-200",
          icon: <Pause className="h-3 w-3 mr-1" />,
        };
      case "cancelled":
        return {
          label: "Cancelled",
          color: "bg-red-100 text-red-800 border-red-200",
          icon: <Ban className="h-3 w-3 mr-1" />,
        };
      default:
        return {
          label: status,
          color: "bg-slate-100 text-slate-800 border-slate-200",
          icon: null,
        };
    }
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Recurring Invoices | Admin Dashboard</title>
      </Helmet>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Recurring Invoices</h1>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => generateInvoicesMutation.mutate()}
              disabled={generateInvoicesMutation.isPending}
              className="gap-2"
            >
              {generateInvoicesMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              Process Due Invoices
            </Button>
            <Button asChild>
              <a href="/admin/invoices/create?recurring=true">
                <Plus className="h-4 w-4 mr-2" />
                New Recurring Invoice
              </a>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="py-4">
              <CardTitle className="text-lg flex items-center gap-2">
                <Calendar className="h-5 w-5 text-blue-500" />
                Active Subscriptions
              </CardTitle>
            </CardHeader>
            <CardContent className="pb-4">
              <div className="text-3xl font-bold">
                {recurringInvoices?.filter((inv: any) => inv.status === "active").length || 0}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="py-4">
              <CardTitle className="text-lg flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-green-500" />
                Monthly Recurring Revenue
              </CardTitle>
            </CardHeader>
            <CardContent className="pb-4">
              <div className="text-3xl font-bold">
                {formatCurrency(
                  recurringInvoices
                    ? recurringInvoices
                        .filter((inv: any) => inv.status === "active")
                        .reduce((sum: number, inv: any) => sum + parseFloat(inv.amount), 0)
                    : 0
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="py-4">
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-5 w-5 text-amber-500" />
                Upcoming Renewals (7 days)
              </CardTitle>
            </CardHeader>
            <CardContent className="pb-4">
              <div className="text-3xl font-bold">
                {recurringInvoices
                  ? recurringInvoices.filter((inv: any) => {
                      try {
                        const nextBillingDate = new Date(inv.nextBillingDate);
                        const sevenDaysFromNow = new Date();
                        sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);
                        return (
                          inv.status === "active" &&
                          nextBillingDate <= sevenDaysFromNow &&
                          nextBillingDate >= new Date()
                        );
                      } catch (e) {
                        return false;
                      }
                    }).length
                  : 0}
              </div>
            </CardContent>
          </Card>
        </div>

        {isLoadingInvoices || isLoadingBillingPlans ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <Table>
            <TableCaption>
              List of all recurring billing subscriptions. Click on any row to view details.
            </TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Client</TableHead>
                <TableHead>Service</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Next Billing</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recurringInvoices && recurringInvoices.length > 0 ? (
                recurringInvoices.map((invoice: any) => (
                  <TableRow 
                    key={invoice.id} 
                    className="cursor-pointer hover:bg-slate-50"
                    onClick={() => showInvoiceDetails(invoice)}
                  >
                    <TableCell>
                      <div className="font-medium flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        {getUserName(invoice.userId)}
                      </div>
                    </TableCell>
                    <TableCell>
                      {invoice.serviceId ? (
                        getServiceName(invoice.serviceId)
                      ) : (
                        <div className="flex items-center gap-1">
                          <FileText className="h-3.5 w-3.5 text-slate-500" />
                          <span className="text-muted-foreground">Custom Items</span>
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{formatCurrency(invoice.amount)}</div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <RefreshCw className="h-3 w-3" />
                        {billingPlans && 
                          formatBillingCycle(
                            billingPlans.find((p: any) => p.id === invoice.billingPlanId)
                          )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span>{formatDate(invoice.nextBillingDate)}</span>
                        {new Date(invoice.nextBillingDate) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) &&
                          new Date(invoice.nextBillingDate) >= new Date() && (
                            <Badge variant="outline" className="mt-1 bg-amber-50 text-amber-700 border-amber-200 w-fit flex items-center gap-1">
                              <AlertTriangle className="h-3 w-3" />
                              <span>Soon</span>
                            </Badge>
                          )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={`${getStatusBadge(invoice.status).color} flex items-center w-fit`}
                      >
                        {getStatusBadge(invoice.status).icon}
                        {getStatusBadge(invoice.status).label}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2" onClick={(e) => e.stopPropagation()}>
                        {invoice.status === "active" ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            title="Pause Subscription"
                            onClick={() => handleStatusUpdate(invoice, "paused")}
                          >
                            <Pause className="h-4 w-4 text-amber-500" />
                          </Button>
                        ) : invoice.status === "paused" ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            title="Resume Subscription"
                            onClick={() => handleStatusUpdate(invoice, "active")}
                          >
                            <Play className="h-4 w-4 text-green-500" />
                          </Button>
                        ) : null}
                        <Button
                          variant="ghost"
                          size="icon"
                          title="Cancel Subscription"
                          onClick={() => handleStatusUpdate(invoice, "cancelled")}
                          disabled={invoice.status === "cancelled"}
                        >
                          <Ban className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    <p className="text-muted-foreground mb-2">No recurring invoices found</p>
                    <Button asChild variant="outline">
                      <a href="/admin/invoices/create?recurring=true">
                        <Plus className="h-4 w-4 mr-2" />
                        Create your first recurring invoice
                      </a>
                    </Button>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </div>

      {/* Status Update Dialog */}
      <Dialog open={isStatusDialogOpen} onOpenChange={setIsStatusDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {newStatus === "active"
                ? "Resume Subscription"
                : newStatus === "paused"
                ? "Pause Subscription"
                : "Cancel Subscription"}
            </DialogTitle>
            <DialogDescription>
              {newStatus === "active"
                ? "This will resume automatic billing for this subscription."
                : newStatus === "paused"
                ? "This will temporarily stop automatic billing for this subscription. You can resume it later."
                : "This will permanently cancel this subscription. This action cannot be undone."}
            </DialogDescription>
          </DialogHeader>

          {currentInvoice && (
            <div className="py-4">
              <Card>
                <CardHeader className="py-4">
                  <CardTitle className="text-base">
                    {currentInvoice.serviceId
                      ? getServiceName(currentInvoice.serviceId)
                      : "Custom Service"}
                  </CardTitle>
                  <CardDescription>
                    Client: {getUserName(currentInvoice.userId)}
                  </CardDescription>
                </CardHeader>
                <CardContent className="py-0">
                  <div className="flex justify-between py-2 border-t">
                    <span className="text-muted-foreground">Billing Plan:</span>
                    <span>{getBillingPlanName(currentInvoice.billingPlanId)}</span>
                  </div>
                  <div className="flex justify-between py-2 border-t">
                    <span className="text-muted-foreground">Amount:</span>
                    <span className="font-medium">{formatCurrency(currentInvoice.amount)}</span>
                  </div>
                  <div className="flex justify-between py-2 border-t">
                    <span className="text-muted-foreground">Next Billing:</span>
                    <span>{formatDate(currentInvoice.nextBillingDate)}</span>
                  </div>
                  <div className="flex justify-between py-2 border-t">
                    <span className="text-muted-foreground">Current Status:</span>
                    <Badge
                      variant="outline"
                      className={`${getStatusBadge(currentInvoice.status).color} flex items-center`}
                    >
                      {getStatusBadge(currentInvoice.status).icon}
                      {getStatusBadge(currentInvoice.status).label}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsStatusDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant={newStatus === "cancelled" ? "destructive" : "default"}
              onClick={confirmStatusUpdate}
              disabled={updateInvoiceStatusMutation.isPending}
            >
              {updateInvoiceStatusMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating...
                </>
              ) : newStatus === "active" ? (
                "Resume Subscription"
              ) : newStatus === "paused" ? (
                "Pause Subscription"
              ) : (
                "Cancel Subscription"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Details Dialog */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Recurring Invoice Details</DialogTitle>
            <DialogDescription>
              View detailed information about this recurring invoice.
            </DialogDescription>
          </DialogHeader>

          {currentInvoice && (
            <div className="py-2">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-xl font-semibold mb-1">
                    {currentInvoice.serviceId
                      ? getServiceName(currentInvoice.serviceId)
                      : "Custom Service"}
                  </h2>
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <User className="h-4 w-4" />
                    <span>{getUserName(currentInvoice.userId)}</span>
                  </div>
                </div>
                <Badge
                  variant="outline"
                  className={`${getStatusBadge(currentInvoice.status).color} flex items-center`}
                >
                  {getStatusBadge(currentInvoice.status).icon}
                  {getStatusBadge(currentInvoice.status).label}
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-primary" />
                      Billing Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <dl className="space-y-2">
                      <div className="flex justify-between py-2 border-t">
                        <dt className="text-muted-foreground">Billing Plan</dt>
                        <dd className="font-medium">
                          {getBillingPlanName(currentInvoice.billingPlanId)}
                        </dd>
                      </div>
                      <div className="flex justify-between py-2 border-t">
                        <dt className="text-muted-foreground">Billing Cycle</dt>
                        <dd>
                          {billingPlans &&
                            formatBillingCycle(
                              billingPlans.find(
                                (p: any) => p.id === currentInvoice.billingPlanId
                              )
                            )}
                        </dd>
                      </div>
                      <div className="flex justify-between py-2 border-t">
                        <dt className="text-muted-foreground">Start Date</dt>
                        <dd>{formatDate(currentInvoice.startDate)}</dd>
                      </div>
                      <div className="flex justify-between py-2 border-t">
                        <dt className="text-muted-foreground">Next Billing Date</dt>
                        <dd className="font-medium">{formatDate(currentInvoice.nextBillingDate)}</dd>
                      </div>
                      {currentInvoice.endDate && (
                        <div className="flex justify-between py-2 border-t">
                          <dt className="text-muted-foreground">End Date</dt>
                          <dd>{formatDate(currentInvoice.endDate)}</dd>
                        </div>
                      )}
                    </dl>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-primary" />
                      Amount Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <dl className="space-y-2">
                      <div className="flex justify-between py-2 border-t">
                        <dt className="text-muted-foreground">Subtotal</dt>
                        <dd className="font-medium">
                          {formatCurrency(
                            parseFloat(currentInvoice.amount) -
                              (currentInvoice.tax ? parseFloat(currentInvoice.tax) : 0)
                          )}
                        </dd>
                      </div>
                      {currentInvoice.tax && (
                        <div className="flex justify-between py-2 border-t">
                          <dt className="text-muted-foreground">Tax</dt>
                          <dd>{formatCurrency(currentInvoice.tax)}</dd>
                        </div>
                      )}
                      <div className="flex justify-between py-2 border-t">
                        <dt className="text-muted-foreground font-medium">Total Amount</dt>
                        <dd className="font-bold text-lg">
                          {formatCurrency(currentInvoice.amount)}
                        </dd>
                      </div>
                    </dl>
                  </CardContent>
                </Card>
              </div>

              {currentInvoice.items && currentInvoice.items.length > 0 && (
                <Card className="mt-6">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <FileText className="h-4 w-4 text-primary" />
                      Invoice Items
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Description</TableHead>
                          <TableHead className="text-right">Quantity</TableHead>
                          <TableHead className="text-right">Unit Price</TableHead>
                          <TableHead className="text-right">Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {currentInvoice.items.map((item: any, index: number) => (
                          <TableRow key={index}>
                            <TableCell>{item.description}</TableCell>
                            <TableCell className="text-right">{item.quantity}</TableCell>
                            <TableCell className="text-right">
                              {formatCurrency(item.unitPrice)}
                            </TableCell>
                            <TableCell className="text-right">
                              {formatCurrency(item.amount)}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}

              <div className="mt-6 flex justify-between">
                <div className="flex gap-2">
                  {currentInvoice.status === "active" ? (
                    <Button
                      variant="outline"
                      className="gap-2"
                      onClick={() => {
                        setIsDetailsDialogOpen(false);
                        handleStatusUpdate(currentInvoice, "paused");
                      }}
                    >
                      <Pause className="h-4 w-4" />
                      Pause Subscription
                    </Button>
                  ) : currentInvoice.status === "paused" ? (
                    <Button
                      variant="outline"
                      className="gap-2"
                      onClick={() => {
                        setIsDetailsDialogOpen(false);
                        handleStatusUpdate(currentInvoice, "active");
                      }}
                    >
                      <Play className="h-4 w-4" />
                      Resume Subscription
                    </Button>
                  ) : null}
                  
                  {currentInvoice.status !== "cancelled" && (
                    <Button
                      variant="outline"
                      className="gap-2 text-red-500 hover:text-red-500 hover:bg-red-50 border-red-200"
                      onClick={() => {
                        setIsDetailsDialogOpen(false);
                        handleStatusUpdate(currentInvoice, "cancelled");
                      }}
                    >
                      <Ban className="h-4 w-4" />
                      Cancel Subscription
                    </Button>
                  )}
                </div>
                
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsDetailsDialogOpen(false)}
                  >
                    Close
                  </Button>
                  <Button asChild>
                    <a href={`/admin/invoices?user=${currentInvoice.userId}`}>
                      <ArrowUpRight className="h-4 w-4 mr-2" />
                      View All Invoices
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}