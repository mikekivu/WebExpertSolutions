import { useState } from "react";
import { AdminLayout } from "@/layouts/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Edit, Trash, Plus } from "lucide-react";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export default function AdminMobileApps() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedApp, setSelectedApp] = useState<any>(null);

  // Mock data for mobile apps
  const [mobileApps, setMobileApps] = useState([
    {
      id: 1,
      name: "E-commerce Mobile App",
      description: "A full-featured e-commerce application with shopping cart, payment integration, and user profiles.",
      platform: "cross-platform",
      category: "e-commerce",
      price: 250000,
      duration: "12-16 weeks",
      featured: true,
      status: "active",
    },
    {
      id: 2,
      name: "Food Delivery App",
      description: "A food delivery application with restaurant listings, order tracking, and payment processing.",
      platform: "ios",
      category: "food",
      price: 180000,
      duration: "8-12 weeks",
      featured: false,
      status: "active",
    },
    {
      id: 3,
      name: "Health & Fitness Tracker",
      description: "A health tracking app with workout plans, nutrition tracking, and progress monitoring.",
      platform: "android",
      category: "health",
      price: 150000,
      duration: "10-14 weeks",
      featured: true,
      status: "active",
    },
  ]);

  const handleAddApp = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newApp = {
      id: mobileApps.length + 1,
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      platform: formData.get("platform") as string,
      category: formData.get("category") as string,
      price: Number(formData.get("price")),
      duration: formData.get("duration") as string,
      featured: formData.get("featured") === "on",
      status: "active",
    };

    setMobileApps([...mobileApps, newApp]);
    setIsAddDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Mobile app package has been added successfully.",
    });
  };

  const handleEditApp = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedApp) return;

    const formData = new FormData(e.currentTarget);
    const updatedApps = mobileApps.map(app => {
      if (app.id === selectedApp.id) {
        return {
          ...app,
          name: formData.get("name") as string,
          description: formData.get("description") as string,
          platform: formData.get("platform") as string,
          category: formData.get("category") as string,
          price: Number(formData.get("price")),
          duration: formData.get("duration") as string,
          featured: formData.get("featured") === "on",
        };
      }
      return app;
    });

    setMobileApps(updatedApps);
    setIsEditDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Mobile app package has been updated successfully.",
    });
  };

  const handleDeleteApp = () => {
    if (!selectedApp) return;

    const updatedApps = mobileApps.filter(app => app.id !== selectedApp.id);
    setMobileApps(updatedApps);
    setIsDeleteDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Mobile app package has been deleted successfully.",
    });
  };

  const openEditDialog = (app: any) => {
    setSelectedApp(app);
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (app: any) => {
    setSelectedApp(app);
    setIsDeleteDialogOpen(true);
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Manage Mobile Apps | Admin Dashboard</title>
      </Helmet>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Mobile App Packages</h1>
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" /> Add New App Package
          </Button>
        </div>

        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Packages</TabsTrigger>
            <TabsTrigger value="featured">Featured</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>All Mobile App Packages</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Platform</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Price (KSh)</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Featured</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mobileApps.map(app => (
                      <TableRow key={app.id}>
                        <TableCell className="font-medium">{app.name}</TableCell>
                        <TableCell>
                          <Badge variant={app.platform === "cross-platform" ? "default" : app.platform === "ios" ? "outline" : "secondary"}>
                            {app.platform === "cross-platform" ? "Cross-Platform" : app.platform === "ios" ? "iOS" : "Android"}
                          </Badge>
                        </TableCell>
                        <TableCell>{app.category}</TableCell>
                        <TableCell>{app.price.toLocaleString()}</TableCell>
                        <TableCell>{app.duration}</TableCell>
                        <TableCell>{app.featured ? "Yes" : "No"}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" onClick={() => openEditDialog(app)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => openDeleteDialog(app)}>
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="featured">
            <Card>
              <CardHeader>
                <CardTitle>Featured Mobile App Packages</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Platform</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Price (KSh)</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mobileApps.filter(app => app.featured).map(app => (
                      <TableRow key={app.id}>
                        <TableCell className="font-medium">{app.name}</TableCell>
                        <TableCell>
                          <Badge variant={app.platform === "cross-platform" ? "default" : app.platform === "ios" ? "outline" : "secondary"}>
                            {app.platform === "cross-platform" ? "Cross-Platform" : app.platform === "ios" ? "iOS" : "Android"}
                          </Badge>
                        </TableCell>
                        <TableCell>{app.category}</TableCell>
                        <TableCell>{app.price.toLocaleString()}</TableCell>
                        <TableCell>{app.duration}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" onClick={() => openEditDialog(app)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => openDeleteDialog(app)}>
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Add Dialog */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Mobile App Package</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddApp}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">App Name</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="platform">Platform</Label>
                    <Select name="platform" defaultValue="cross-platform">
                      <SelectTrigger id="platform">
                        <SelectValue placeholder="Select Platform" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cross-platform">Cross-Platform</SelectItem>
                        <SelectItem value="ios">iOS</SelectItem>
                        <SelectItem value="android">Android</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" name="description" rows={4} required />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select name="category" defaultValue="e-commerce">
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Select Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="e-commerce">E-commerce</SelectItem>
                        <SelectItem value="food">Food & Delivery</SelectItem>
                        <SelectItem value="health">Health & Fitness</SelectItem>
                        <SelectItem value="education">Education</SelectItem>
                        <SelectItem value="social">Social Networking</SelectItem>
                        <SelectItem value="utility">Utility</SelectItem>
                        <SelectItem value="business">Business</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="price">Price (KSh)</Label>
                    <Input id="price" name="price" type="number" required />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="duration">Duration</Label>
                    <Input id="duration" name="duration" placeholder="e.g., 8-12 weeks" required />
                  </div>
                  <div className="flex items-center space-x-2 pt-6">
                    <Switch id="featured" name="featured" />
                    <Label htmlFor="featured">Featured Package</Label>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Mobile App Package</DialogTitle>
            </DialogHeader>
            {selectedApp && (
              <form onSubmit={handleEditApp}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-name">App Name</Label>
                      <Input id="edit-name" name="name" defaultValue={selectedApp.name} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-platform">Platform</Label>
                      <Select name="platform" defaultValue={selectedApp.platform}>
                        <SelectTrigger id="edit-platform">
                          <SelectValue placeholder="Select Platform" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cross-platform">Cross-Platform</SelectItem>
                          <SelectItem value="ios">iOS</SelectItem>
                          <SelectItem value="android">Android</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-description">Description</Label>
                    <Textarea id="edit-description" name="description" rows={4} defaultValue={selectedApp.description} required />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-category">Category</Label>
                      <Select name="category" defaultValue={selectedApp.category}>
                        <SelectTrigger id="edit-category">
                          <SelectValue placeholder="Select Category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="e-commerce">E-commerce</SelectItem>
                          <SelectItem value="food">Food & Delivery</SelectItem>
                          <SelectItem value="health">Health & Fitness</SelectItem>
                          <SelectItem value="education">Education</SelectItem>
                          <SelectItem value="social">Social Networking</SelectItem>
                          <SelectItem value="utility">Utility</SelectItem>
                          <SelectItem value="business">Business</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-price">Price (KSh)</Label>
                      <Input id="edit-price" name="price" type="number" defaultValue={selectedApp.price} required />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-duration">Duration</Label>
                      <Input id="edit-duration" name="duration" defaultValue={selectedApp.duration} required />
                    </div>
                    <div className="flex items-center space-x-2 pt-6">
                      <Switch id="edit-featured" name="featured" checked={selectedApp.featured} />
                      <Label htmlFor="edit-featured">Featured Package</Label>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Update</Button>
                </DialogFooter>
              </form>
            )}
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Deletion</DialogTitle>
            </DialogHeader>
            <p>Are you sure you want to delete this mobile app package? This action cannot be undone.</p>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="button" variant="destructive" onClick={handleDeleteApp}>
                Delete
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}