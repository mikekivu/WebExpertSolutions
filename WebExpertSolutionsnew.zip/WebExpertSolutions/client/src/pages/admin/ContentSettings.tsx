import { useState } from "react";
import { AdminLayout } from "@/layouts/AdminLayout";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Save, Plus, Trash, Edit } from "lucide-react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Helmet } from "react-helmet";

// Define schemas for our forms
const topBarSchema = z.object({
  phone: z.string().min(1, "Phone number is required"),
  email: z.string().email("Must be a valid email"),
  facebook: z.string().url("Must be a valid URL"),
  twitter: z.string().url("Must be a valid URL"),
  linkedin: z.string().url("Must be a valid URL"),
  instagram: z.string().url("Must be a valid URL"),
  tiktok: z.string().url("Must be a valid URL"),
});

const footerSchema = z.object({
  companyDescription: z.string().min(10, "Description must be at least 10 characters"),
  address: z.string().min(1, "Address is required"),
  phone1: z.string().min(1, "Primary phone is required"),
  phone2: z.string().optional(),
  email: z.string().email("Must be a valid email"),
  facebook: z.string().url("Must be a valid URL"),
  twitter: z.string().url("Must be a valid URL"),
  linkedin: z.string().url("Must be a valid URL"),
  instagram: z.string().url("Must be a valid URL"),
  tiktok: z.string().url("Must be a valid URL"),
  copyright: z.string().min(1, "Copyright text is required"),
});

const homePageSchema = z.object({
  heroTitle: z.string().min(1, "Hero title is required"),
  heroSubtitle: z.string().min(1, "Hero subtitle is required"),
  aboutTitle: z.string().min(1, "About title is required"),
  aboutContent: z.string().min(10, "About content must be at least 10 characters"),
  servicesTitle: z.string().min(1, "Services title is required"),
  servicesSubtitle: z.string().min(1, "Services subtitle is required"),
  portfolioTitle: z.string().min(1, "Portfolio title is required"),
  portfolioSubtitle: z.string().min(1, "Portfolio subtitle is required"),
  testimonialsTitle: z.string().min(1, "Testimonials title is required"),
  testimonialsSubtitle: z.string().min(1, "Testimonials subtitle is required"),
  ctaTitle: z.string().min(1, "CTA title is required"),
  ctaContent: z.string().min(10, "CTA content must be at least 10 characters"),
});

export default function ContentSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("top-bar");
  
  // Dialogs state
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  
  // Fetch data
  const { data: topBarData, isLoading: isTopBarLoading } = useQuery({
    queryKey: ["/api/settings/top-bar"],
  });
  
  const { data: footerData, isLoading: isFooterLoading } = useQuery({
    queryKey: ["/api/settings/footer"],
  });
  
  const { data: homePageData, isLoading: isHomePageLoading } = useQuery({
    queryKey: ["/api/settings/home-page"],
  });
  
  // Set up forms
  const topBarForm = useForm<z.infer<typeof topBarSchema>>({
    resolver: zodResolver(topBarSchema),
    defaultValues: {
      phone: topBarData?.phone || "+254112345366",
      email: topBarData?.email || "info@webexpertsolutions.co.ke",
      facebook: topBarData?.facebook || "https://www.facebook.com/webexpertsolutionskenya",
      twitter: topBarData?.twitter || "https://x.com/WebExpertke",
      linkedin: topBarData?.linkedin || "https://www.linkedin.com/in/mike-kivu-paul-769547ba",
      instagram: topBarData?.instagram || "https://www.instagram.com/webexpertsolutions",
      tiktok: topBarData?.tiktok || "https://www.tiktok.com/@web.expert.soluti?lang=en",
    },
  });
  
  const footerForm = useForm<z.infer<typeof footerSchema>>({
    resolver: zodResolver(footerSchema),
    defaultValues: {
      companyDescription: footerData?.companyDescription || "",
      address: footerData?.address || "CBD, Nairobi, Kenya",
      phone1: footerData?.phone1 || "+254112345366",
      phone2: footerData?.phone2 || "+254715026405",
      email: footerData?.email || "info@webexpertsolutions.co.ke",
      facebook: footerData?.facebook || "https://www.facebook.com/webexpertsolutionskenya",
      twitter: footerData?.twitter || "https://x.com/WebExpertke",
      linkedin: footerData?.linkedin || "https://www.linkedin.com/in/mike-kivu-paul-769547ba",
      instagram: footerData?.instagram || "https://www.instagram.com/webexpertsolutions",
      tiktok: footerData?.tiktok || "https://www.tiktok.com/@web.expert.soluti?lang=en",
      copyright: footerData?.copyright || "© 2024 Web Expert Solutions. All rights reserved.",
    },
  });
  
  const homePageForm = useForm<z.infer<typeof homePageSchema>>({
    resolver: zodResolver(homePageSchema),
    defaultValues: {
      heroTitle: homePageData?.heroTitle || "Digital Solutions for Business Growth",
      heroSubtitle: homePageData?.heroSubtitle || "Expert web development, mobile apps, custom software, domain registration, and hosting services",
      aboutTitle: homePageData?.aboutTitle || "About Us",
      aboutContent: homePageData?.aboutContent || "Web Expert Solutions is a leading digital agency in Kenya...",
      servicesTitle: homePageData?.servicesTitle || "Our Services",
      servicesSubtitle: homePageData?.servicesSubtitle || "Comprehensive digital solutions for your business",
      portfolioTitle: homePageData?.portfolioTitle || "Our Portfolio",
      portfolioSubtitle: homePageData?.portfolioSubtitle || "Check out some of our recent work",
      testimonialsTitle: homePageData?.testimonialsTitle || "Client Testimonials",
      testimonialsSubtitle: homePageData?.testimonialsSubtitle || "What our clients say about us",
      ctaTitle: homePageData?.ctaTitle || "Ready to Get Started?",
      ctaContent: homePageData?.ctaContent || "Contact us today to discuss your project or request a quote.",
    },
  });
  
  // Set up mutations
  const updateTopBarMutation = useMutation({
    mutationFn: async (data: z.infer<typeof topBarSchema>) => {
      return apiRequest("PUT", "/api/settings/top-bar", data);
    },
    onSuccess: () => {
      toast({
        title: "Top bar updated",
        description: "The top bar settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/settings/top-bar"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const updateFooterMutation = useMutation({
    mutationFn: async (data: z.infer<typeof footerSchema>) => {
      return apiRequest("PUT", "/api/settings/footer", data);
    },
    onSuccess: () => {
      toast({
        title: "Footer updated",
        description: "The footer settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/settings/footer"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const updateHomePageMutation = useMutation({
    mutationFn: async (data: z.infer<typeof homePageSchema>) => {
      return apiRequest("PUT", "/api/settings/home-page", data);
    },
    onSuccess: () => {
      toast({
        title: "Home page updated",
        description: "The home page settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/settings/home-page"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  // Form submission handlers
  const onSubmitTopBar = (data: z.infer<typeof topBarSchema>) => {
    updateTopBarMutation.mutate(data);
  };
  
  const onSubmitFooter = (data: z.infer<typeof footerSchema>) => {
    updateFooterMutation.mutate(data);
  };
  
  const onSubmitHomePage = (data: z.infer<typeof homePageSchema>) => {
    updateHomePageMutation.mutate(data);
  };
  
  return (
    <AdminLayout>
      <Helmet>
        <title>Content Settings | Admin Dashboard</title>
      </Helmet>
      
      <div className="container mx-auto">
        <h1 className="text-3xl font-bold mb-8">Content Settings</h1>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="top-bar">Top Bar</TabsTrigger>
            <TabsTrigger value="footer">Footer</TabsTrigger>
            <TabsTrigger value="home-page">Home Page</TabsTrigger>
          </TabsList>
          
          {/* Top Bar Settings */}
          <TabsContent value="top-bar">
            <Card>
              <CardHeader>
                <CardTitle>Top Bar Settings</CardTitle>
                <CardDescription>
                  Configure the contact information and social media links displayed in the top bar
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...topBarForm}>
                  <form onSubmit={topBarForm.handleSubmit(onSubmitTopBar)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={topBarForm.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="+254112345366" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={topBarForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input placeholder="info@webexpertsolutions.co.ke" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <h3 className="text-lg font-semibold mt-6">Social Media Links</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={topBarForm.control}
                        name="facebook"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Facebook URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://www.facebook.com/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={topBarForm.control}
                        name="twitter"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>X (Twitter) URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://x.com/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={topBarForm.control}
                        name="linkedin"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>LinkedIn URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://www.linkedin.com/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={topBarForm.control}
                        name="instagram"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Instagram URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://www.instagram.com/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={topBarForm.control}
                        name="tiktok"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>TikTok URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://www.tiktok.com/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="mt-6" 
                      disabled={updateTopBarMutation.isPending}
                    >
                      {updateTopBarMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Footer Settings */}
          <TabsContent value="footer">
            <Card>
              <CardHeader>
                <CardTitle>Footer Settings</CardTitle>
                <CardDescription>
                  Configure the company information, contact details and social media links shown in the footer
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...footerForm}>
                  <form onSubmit={footerForm.handleSubmit(onSubmitFooter)} className="space-y-6">
                    <FormField
                      control={footerForm.control}
                      name="companyDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Web Expert Solutions is a leading digital agency..." 
                              rows={3}
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={footerForm.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Address</FormLabel>
                          <FormControl>
                            <Input placeholder="CBD, Nairobi, Kenya" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={footerForm.control}
                        name="phone1"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Primary Phone</FormLabel>
                            <FormControl>
                              <Input placeholder="+254112345366" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={footerForm.control}
                        name="phone2"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Secondary Phone (Optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="+254715026405" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={footerForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input placeholder="info@webexpertsolutions.co.ke" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <h3 className="text-lg font-semibold mt-6">Social Media Links</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={footerForm.control}
                        name="facebook"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Facebook URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://www.facebook.com/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={footerForm.control}
                        name="twitter"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>X (Twitter) URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://x.com/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={footerForm.control}
                        name="linkedin"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>LinkedIn URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://www.linkedin.com/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={footerForm.control}
                        name="instagram"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Instagram URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://www.instagram.com/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={footerForm.control}
                        name="tiktok"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>TikTok URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://www.tiktok.com/..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={footerForm.control}
                      name="copyright"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Copyright Text</FormLabel>
                          <FormControl>
                            <Input placeholder="© 2024 Web Expert Solutions. All rights reserved." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="mt-6" 
                      disabled={updateFooterMutation.isPending}
                    >
                      {updateFooterMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Home Page Settings */}
          <TabsContent value="home-page">
            <Card>
              <CardHeader>
                <CardTitle>Home Page Settings</CardTitle>
                <CardDescription>
                  Configure the content displayed on the home page sections
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...homePageForm}>
                  <form onSubmit={homePageForm.handleSubmit(onSubmitHomePage)} className="space-y-6">
                    <h3 className="text-lg font-semibold">Hero Section</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={homePageForm.control}
                        name="heroTitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Hero Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Digital Solutions for Business Growth" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={homePageForm.control}
                        name="heroSubtitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Hero Subtitle</FormLabel>
                            <FormControl>
                              <Input placeholder="Expert web development, mobile apps..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <h3 className="text-lg font-semibold mt-6">About Section</h3>
                    
                    <div className="grid grid-cols-1 gap-6">
                      <FormField
                        control={homePageForm.control}
                        name="aboutTitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>About Title</FormLabel>
                            <FormControl>
                              <Input placeholder="About Us" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={homePageForm.control}
                        name="aboutContent"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>About Content</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Web Expert Solutions is a leading digital agency..." 
                                rows={3}
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <h3 className="text-lg font-semibold mt-6">Services Section</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={homePageForm.control}
                        name="servicesTitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Services Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Our Services" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={homePageForm.control}
                        name="servicesSubtitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Services Subtitle</FormLabel>
                            <FormControl>
                              <Input placeholder="Comprehensive digital solutions for your business" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <h3 className="text-lg font-semibold mt-6">Portfolio Section</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={homePageForm.control}
                        name="portfolioTitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Portfolio Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Our Portfolio" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={homePageForm.control}
                        name="portfolioSubtitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Portfolio Subtitle</FormLabel>
                            <FormControl>
                              <Input placeholder="Check out some of our recent work" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <h3 className="text-lg font-semibold mt-6">Testimonials Section</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={homePageForm.control}
                        name="testimonialsTitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Testimonials Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Client Testimonials" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={homePageForm.control}
                        name="testimonialsSubtitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Testimonials Subtitle</FormLabel>
                            <FormControl>
                              <Input placeholder="What our clients say about us" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <h3 className="text-lg font-semibold mt-6">Call to Action Section</h3>
                    
                    <div className="grid grid-cols-1 gap-6">
                      <FormField
                        control={homePageForm.control}
                        name="ctaTitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CTA Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Ready to Get Started?" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={homePageForm.control}
                        name="ctaContent"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CTA Content</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Contact us today to discuss your project..." 
                                rows={3}
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="mt-6" 
                      disabled={updateHomePageMutation.isPending}
                    >
                      {updateHomePageMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
}