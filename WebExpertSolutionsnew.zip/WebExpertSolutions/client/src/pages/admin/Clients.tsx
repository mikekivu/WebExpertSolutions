import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AdminLayout } from "@/layouts/AdminLayout";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Helmet } from "react-helmet";
import { format } from "date-fns";
import { Link } from "wouter";
import { Mail, Download, Eye, Search } from "lucide-react";

interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  phone?: string;
  company?: string;
  role: string;
  createdAt: string;
}

export default function AdminClients() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedClient, setSelectedClient] = useState<User | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  
  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });
  
  // Filter only clients and apply search
  const clients = users
    .filter(user => user.role === "client")
    .filter(client => 
      searchQuery === "" || 
      client.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.company?.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const viewClient = (client: User) => {
    setSelectedClient(client);
    setIsViewDialogOpen(true);
  };

  return (
    <>
      <Helmet>
        <title>Manage Clients | Admin Dashboard | Web Expert Solutions</title>
        <meta name="description" content="Manage clients for Web Expert Solutions" />
      </Helmet>
      
      <AdminLayout>
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Clients</h1>
            <p className="text-gray-500">
              Manage all your clients
            </p>
          </div>

          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Client List</CardTitle>
                  <CardDescription>
                    You have {clients.length} total clients
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      type="search"
                      placeholder="Search clients..."
                      className="pl-8 md:w-64"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Button>
                    <Download className="mr-2 h-4 w-4" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="animate-pulse flex items-center gap-4 py-4">
                      <div className="h-10 w-10 rounded-full bg-gray-200"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                      </div>
                      <div className="h-8 w-24 bg-gray-200 rounded"></div>
                    </div>
                  ))}
                </div>
              ) : clients.length === 0 ? (
                <div className="text-center py-8">
                  <h3 className="text-lg font-medium mb-2">No clients found</h3>
                  <p className="text-sm text-gray-500 mb-4">
                    {searchQuery ? "No clients match your search criteria." : "You don't have any clients yet."}
                  </p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Company</TableHead>
                        <TableHead>Phone</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {clients.map((client) => (
                        <TableRow key={client.id}>
                          <TableCell>
                            <div className="font-medium">{client.fullName}</div>
                            <div className="text-sm text-muted-foreground">@{client.username}</div>
                          </TableCell>
                          <TableCell>{client.email}</TableCell>
                          <TableCell>{client.company || "—"}</TableCell>
                          <TableCell>{client.phone || "—"}</TableCell>
                          <TableCell>{format(new Date(client.createdAt), 'MMM d, yyyy')}</TableCell>
                          <TableCell className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => viewClient(client)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Link href={`/admin/email-clients?client=${client.id}`}>
                              <Button variant="ghost" size="icon">
                                <Mail className="h-4 w-4" />
                              </Button>
                            </Link>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </AdminLayout>

      {/* Client View Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Client Details</DialogTitle>
            <DialogDescription>
              Detailed information about the client
            </DialogDescription>
          </DialogHeader>
          
          {selectedClient && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Name:</div>
                <div className="col-span-3">{selectedClient.fullName}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Username:</div>
                <div className="col-span-3">@{selectedClient.username}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Email:</div>
                <div className="col-span-3">{selectedClient.email}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Phone:</div>
                <div className="col-span-3">{selectedClient.phone || "—"}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Company:</div>
                <div className="col-span-3">{selectedClient.company || "—"}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Join Date:</div>
                <div className="col-span-3">{format(new Date(selectedClient.createdAt), 'MMMM d, yyyy')}</div>
              </div>
              
              <div className="flex justify-between pt-4">
                <Link href={`/admin/quotes?client=${selectedClient.id}`}>
                  <Button variant="outline">View Quotes</Button>
                </Link>
                <Link href={`/admin/invoices?client=${selectedClient.id}`}>
                  <Button variant="outline">View Invoices</Button>
                </Link>
                <Link href={`/admin/email-clients?client=${selectedClient.id}`}>
                  <Button>
                    <Mail className="mr-2 h-4 w-4" />
                    Email Client
                  </Button>
                </Link>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
