import { useState } from "react";
import { AdminLayout } from "@/layouts/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Edit, Trash, Plus, Search, AlertCircle } from "lucide-react";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

interface Domain {
  id: number;
  name: string;
  extension: string;
  registrationDate: string;
  expiryDate: string;
  status: string;
  clientId?: number;
  clientName?: string;
  autoRenew: boolean;
  privacyProtection: boolean;
  notes?: string;
}

export default function AdminDomainManagement() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDomainLookupDialogOpen, setIsDomainLookupDialogOpen] = useState(false);
  const [selectedDomain, setSelectedDomain] = useState<Domain | null>(null);
  const [domainLookupQuery, setDomainLookupQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);

  // Mock data for domains
  const [domains, setDomains] = useState<Domain[]>([
    {
      id: 1,
      name: "example",
      extension: ".com",
      registrationDate: "2023-05-15",
      expiryDate: "2024-05-15",
      status: "active",
      clientId: 1,
      clientName: "John Doe",
      autoRenew: true,
      privacyProtection: true,
      notes: "Client's main business domain"
    },
    {
      id: 2,
      name: "mybusiness",
      extension: ".co.ke",
      registrationDate: "2023-02-20",
      expiryDate: "2024-02-20",
      status: "active",
      clientId: 2,
      clientName: "Jane Smith",
      autoRenew: true,
      privacyProtection: false,
      notes: "Local business website"
    },
    {
      id: 3,
      name: "tech-company",
      extension: ".org",
      registrationDate: "2022-11-10",
      expiryDate: "2023-11-10",
      status: "expiring-soon",
      clientId: 3,
      clientName: "Tech Solutions Ltd",
      autoRenew: false,
      privacyProtection: true,
      notes: "Non-profit tech initiative"
    },
    {
      id: 4,
      name: "webexperts",
      extension: ".net",
      registrationDate: "2023-08-05",
      expiryDate: "2024-08-05",
      status: "active",
      clientId: 1,
      clientName: "John Doe",
      autoRenew: true,
      privacyProtection: true,
    },
  ]);

  const handleAddDomain = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const name = formData.get("name") as string;
    const extension = formData.get("extension") as string;
    const registrationDate = formData.get("registrationDate") as string;
    const expiryDate = formData.get("expiryDate") as string;
    const clientNameInput = formData.get("clientName") as string;
    const clientIdInput = formData.get("clientId") as string;
    const notes = formData.get("notes") as string;
    
    const newDomain: Domain = {
      id: domains.length + 1,
      name,
      extension,
      registrationDate,
      expiryDate,
      status: "active",
      clientId: clientIdInput ? parseInt(clientIdInput) : undefined,
      clientName: clientNameInput || undefined,
      autoRenew: formData.get("autoRenew") === "on",
      privacyProtection: formData.get("privacyProtection") === "on",
      notes: notes || undefined
    };

    setDomains([...domains, newDomain]);
    setIsAddDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Domain has been added successfully.",
    });
  };

  const handleEditDomain = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedDomain) return;

    const formData = new FormData(e.currentTarget);
    
    const name = formData.get("name") as string;
    const extension = formData.get("extension") as string;
    const registrationDate = formData.get("registrationDate") as string;
    const expiryDate = formData.get("expiryDate") as string;
    const status = formData.get("status") as string;
    const clientNameInput = formData.get("clientName") as string;
    const clientIdInput = formData.get("clientId") as string;
    const notes = formData.get("notes") as string;
    
    const updatedDomains = domains.map(domain => {
      if (domain.id === selectedDomain.id) {
        return {
          ...domain,
          name,
          extension,
          registrationDate,
          expiryDate,
          status,
          clientId: clientIdInput ? parseInt(clientIdInput) : undefined,
          clientName: clientNameInput || undefined,
          autoRenew: formData.get("autoRenew") === "on",
          privacyProtection: formData.get("privacyProtection") === "on",
          notes: notes || undefined
        };
      }
      return domain;
    });

    setDomains(updatedDomains);
    setIsEditDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Domain has been updated successfully.",
    });
  };

  const handleDeleteDomain = () => {
    if (!selectedDomain) return;

    const updatedDomains = domains.filter(domain => domain.id !== selectedDomain.id);
    setDomains(updatedDomains);
    setIsDeleteDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Domain has been deleted successfully.",
    });
  };

  const handleDomainLookup = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Mock domain lookup results
    if (domainLookupQuery) {
      const extensions = ['.com', '.org', '.net', '.co.ke', '.ke', '.info'];
      const results = extensions.map(ext => ({
        domain: `${domainLookupQuery}${ext}`,
        available: Math.random() > 0.5, // Random availability for demo
        price: ext === '.com' ? 1200 : ext === '.org' ? 1500 : ext === '.net' ? 1400 : ext === '.co.ke' ? 900 : ext === '.ke' ? 1200 : 1000
      }));
      
      setSearchResults(results);
      
      toast({
        title: "Domain Lookup Complete",
        description: "Results have been loaded successfully.",
      });
    }
  };

  const openEditDialog = (domain: Domain) => {
    setSelectedDomain(domain);
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (domain: Domain) => {
    setSelectedDomain(domain);
    setIsDeleteDialogOpen(true);
  };

  const getDomainStatusBadge = (status: string) => {
    switch(status) {
      case 'active':
        return <Badge variant="default">Active</Badge>;
      case 'expiring-soon':
        return <Badge variant="warning" className="bg-yellow-500">Expiring Soon</Badge>;
      case 'expired':
        return <Badge variant="destructive">Expired</Badge>;
      case 'transferred-out':
        return <Badge variant="outline">Transferred Out</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const isExpiringSoon = (expiryDate: string) => {
    const expiry = new Date(expiryDate);
    const today = new Date();
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 30 && diffDays > 0;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Domain Management | Admin Dashboard</title>
      </Helmet>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Domain Management</h1>
          <div className="flex space-x-2">
            <Button onClick={() => setIsDomainLookupDialogOpen(true)} variant="outline">
              <Search className="mr-2 h-4 w-4" /> Domain Lookup
            </Button>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" /> Add New Domain
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Domains</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="expiring-soon">Expiring Soon</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>All Domains</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Domain</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Registration Date</TableHead>
                      <TableHead>Expiry Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Auto Renew</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {domains.map(domain => (
                      <TableRow key={domain.id}>
                        <TableCell className="font-medium">{domain.name}{domain.extension}</TableCell>
                        <TableCell>{domain.clientName || "N/A"}</TableCell>
                        <TableCell>{formatDate(domain.registrationDate)}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            {formatDate(domain.expiryDate)}
                            {isExpiringSoon(domain.expiryDate) && (
                              <AlertCircle className="ml-2 h-4 w-4 text-yellow-500" />
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{getDomainStatusBadge(domain.status)}</TableCell>
                        <TableCell>{domain.autoRenew ? "Yes" : "No"}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" onClick={() => openEditDialog(domain)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => openDeleteDialog(domain)}>
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="active">
            <Card>
              <CardHeader>
                <CardTitle>Active Domains</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Domain</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Registration Date</TableHead>
                      <TableHead>Expiry Date</TableHead>
                      <TableHead>Auto Renew</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {domains.filter(domain => domain.status === 'active').map(domain => (
                      <TableRow key={domain.id}>
                        <TableCell className="font-medium">{domain.name}{domain.extension}</TableCell>
                        <TableCell>{domain.clientName || "N/A"}</TableCell>
                        <TableCell>{formatDate(domain.registrationDate)}</TableCell>
                        <TableCell>{formatDate(domain.expiryDate)}</TableCell>
                        <TableCell>{domain.autoRenew ? "Yes" : "No"}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" onClick={() => openEditDialog(domain)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => openDeleteDialog(domain)}>
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="expiring-soon">
            <Card>
              <CardHeader>
                <CardTitle>Domains Expiring Soon</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Domain</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Expiry Date</TableHead>
                      <TableHead>Auto Renew</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {domains.filter(domain => domain.status === 'expiring-soon' || isExpiringSoon(domain.expiryDate)).map(domain => (
                      <TableRow key={domain.id}>
                        <TableCell className="font-medium">{domain.name}{domain.extension}</TableCell>
                        <TableCell>{domain.clientName || "N/A"}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            {formatDate(domain.expiryDate)}
                            <AlertCircle className="ml-2 h-4 w-4 text-yellow-500" />
                          </div>
                        </TableCell>
                        <TableCell>{domain.autoRenew ? "Yes" : "No"}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" onClick={() => openEditDialog(domain)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => openDeleteDialog(domain)}>
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Domain Lookup Dialog */}
        <Dialog open={isDomainLookupDialogOpen} onOpenChange={setIsDomainLookupDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Domain Lookup</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleDomainLookup}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="domainLookup">Check Domain Availability</Label>
                  <div className="flex">
                    <Input 
                      id="domainLookup" 
                      value={domainLookupQuery}
                      onChange={(e) => setDomainLookupQuery(e.target.value)}
                      placeholder="Enter domain name without extension..." 
                      className="flex-grow"
                    />
                    <Button type="submit" className="ml-2">Check</Button>
                  </div>
                </div>

                {searchResults.length > 0 && (
                  <div className="mt-4">
                    <h3 className="font-semibold mb-2">Search Results:</h3>
                    <div className="bg-slate-50 rounded-lg p-4">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Domain</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Price (KSh/year)</TableHead>
                            <TableHead>Action</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {searchResults.map((result, index) => (
                            <TableRow key={index}>
                              <TableCell className="font-medium">{result.domain}</TableCell>
                              <TableCell>
                                {result.available ? (
                                  <Badge variant="default" className="bg-green-500">Available</Badge>
                                ) : (
                                  <Badge variant="secondary">Taken</Badge>
                                )}
                              </TableCell>
                              <TableCell>{result.price}</TableCell>
                              <TableCell>
                                {result.available && (
                                  <Button size="sm" variant="outline">Register</Button>
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDomainLookupDialogOpen(false)}>
                  Close
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Add Dialog */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Domain</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddDomain}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Domain Name (without extension)</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="extension">Extension</Label>
                    <Select name="extension" defaultValue=".com">
                      <SelectTrigger id="extension">
                        <SelectValue placeholder="Select Extension" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value=".com">.com</SelectItem>
                        <SelectItem value=".org">.org</SelectItem>
                        <SelectItem value=".net">.net</SelectItem>
                        <SelectItem value=".co.ke">.co.ke</SelectItem>
                        <SelectItem value=".ke">.ke</SelectItem>
                        <SelectItem value=".info">.info</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="registrationDate">Registration Date</Label>
                    <Input id="registrationDate" name="registrationDate" type="date" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="expiryDate">Expiry Date</Label>
                    <Input id="expiryDate" name="expiryDate" type="date" required />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="clientId">Client ID (optional)</Label>
                    <Input id="clientId" name="clientId" type="number" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="clientName">Client Name (optional)</Label>
                    <Input id="clientName" name="clientName" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Switch id="autoRenew" name="autoRenew" defaultChecked />
                    <Label htmlFor="autoRenew">Auto-Renew</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="privacyProtection" name="privacyProtection" defaultChecked />
                    <Label htmlFor="privacyProtection">Privacy Protection</Label>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notes (optional)</Label>
                  <Textarea id="notes" name="notes" rows={3} />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Domain</DialogTitle>
            </DialogHeader>
            {selectedDomain && (
              <form onSubmit={handleEditDomain}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-name">Domain Name (without extension)</Label>
                      <Input id="edit-name" name="name" defaultValue={selectedDomain.name} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-extension">Extension</Label>
                      <Select name="extension" defaultValue={selectedDomain.extension}>
                        <SelectTrigger id="edit-extension">
                          <SelectValue placeholder="Select Extension" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value=".com">.com</SelectItem>
                          <SelectItem value=".org">.org</SelectItem>
                          <SelectItem value=".net">.net</SelectItem>
                          <SelectItem value=".co.ke">.co.ke</SelectItem>
                          <SelectItem value=".ke">.ke</SelectItem>
                          <SelectItem value=".info">.info</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-registrationDate">Registration Date</Label>
                      <Input 
                        id="edit-registrationDate" 
                        name="registrationDate" 
                        type="date" 
                        defaultValue={selectedDomain.registrationDate} 
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-expiryDate">Expiry Date</Label>
                      <Input 
                        id="edit-expiryDate" 
                        name="expiryDate" 
                        type="date" 
                        defaultValue={selectedDomain.expiryDate} 
                        required 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-status">Status</Label>
                      <Select name="status" defaultValue={selectedDomain.status}>
                        <SelectTrigger id="edit-status">
                          <SelectValue placeholder="Select Status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="expiring-soon">Expiring Soon</SelectItem>
                          <SelectItem value="expired">Expired</SelectItem>
                          <SelectItem value="transferred-out">Transferred Out</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-clientName">Client Name</Label>
                      <Input 
                        id="edit-clientName" 
                        name="clientName" 
                        defaultValue={selectedDomain.clientName || ""} 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-clientId">Client ID</Label>
                      <Input 
                        id="edit-clientId" 
                        name="clientId" 
                        type="number" 
                        defaultValue={selectedDomain.clientId?.toString() || ""} 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="edit-autoRenew" 
                        name="autoRenew" 
                        checked={selectedDomain.autoRenew} 
                      />
                      <Label htmlFor="edit-autoRenew">Auto-Renew</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="edit-privacyProtection" 
                        name="privacyProtection" 
                        checked={selectedDomain.privacyProtection} 
                      />
                      <Label htmlFor="edit-privacyProtection">Privacy Protection</Label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-notes">Notes</Label>
                    <Textarea 
                      id="edit-notes" 
                      name="notes" 
                      rows={3} 
                      defaultValue={selectedDomain.notes || ""} 
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Update</Button>
                </DialogFooter>
              </form>
            )}
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Deletion</DialogTitle>
            </DialogHeader>
            <p>Are you sure you want to delete the domain <strong>{selectedDomain?.name}{selectedDomain?.extension}</strong>? This action cannot be undone.</p>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="button" variant="destructive" onClick={handleDeleteDomain}>
                Delete
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}