import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { AdminLayout } from "@/layouts/AdminLayout";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Helmet } from "react-helmet";
import { format } from "date-fns";
import { QuoteForm } from "@/components/forms/QuoteForm";
import { Eye, FilePlus } from "lucide-react";

interface QuoteRequest {
  id: number;
  name: string;
  email: string;
  phone?: string;
  serviceType: string;
  message: string;
  status: "pending" | "reviewed" | "quoted" | "rejected";
  createdAt: string;
}

export default function AdminQuotes() {
  const [, params] = useLocation();
  const query = new URLSearchParams(params);
  const clientId = query.get("client");
  
  const [selectedQuoteRequest, setSelectedQuoteRequest] = useState<QuoteRequest | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isCreateQuoteDialogOpen, setIsCreateQuoteDialogOpen] = useState(false);
  
  const { data: quoteRequests = [], isLoading } = useQuery<QuoteRequest[]>({
    queryKey: ["/api/quote-requests"],
  });

  const viewQuoteRequest = (quoteRequest: QuoteRequest) => {
    setSelectedQuoteRequest(quoteRequest);
    setIsViewDialogOpen(true);
  };

  const createQuote = (quoteRequest: QuoteRequest) => {
    setSelectedQuoteRequest(quoteRequest);
    setIsCreateQuoteDialogOpen(true);
  };

  const getStatusBadge = (status: string) => {
    switch(status) {
      case "pending":
        return <Badge variant="secondary">Pending</Badge>;
      case "reviewed":
        return <Badge variant="default">Reviewed</Badge>;
      case "quoted":
        return <Badge className="bg-green-500">Quoted</Badge>;
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const categorizedQuotes = {
    all: quoteRequests,
    pending: quoteRequests.filter(quote => quote.status === "pending"),
    reviewed: quoteRequests.filter(quote => quote.status === "reviewed"),
    quoted: quoteRequests.filter(quote => quote.status === "quoted"),
    rejected: quoteRequests.filter(quote => quote.status === "rejected"),
  };

  const getServiceTypeLabel = (type: string) => {
    switch(type) {
      case "web-development":
        return "Web Development";
      case "mobile-app":
        return "Mobile App Development";
      case "software-development":
        return "Software Development";
      case "web-hosting":
        return "Web Hosting";
      case "domain-registration":
        return "Domain Registration";
      case "bulk-sms":
        return "Bulk SMS";
      case "digital-marketing":
        return "Digital Marketing";
      default:
        return type;
    }
  };

  return (
    <>
      <Helmet>
        <title>Quote Requests | Admin Dashboard | Web Expert Solutions</title>
        <meta name="description" content="Manage quote requests for Web Expert Solutions" />
      </Helmet>
      
      <AdminLayout>
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Quote Requests</h1>
            <p className="text-gray-500">
              Manage and respond to client quote requests
            </p>
          </div>

          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Requests</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="reviewed">Reviewed</TabsTrigger>
              <TabsTrigger value="quoted">Quoted</TabsTrigger>
              <TabsTrigger value="rejected">Rejected</TabsTrigger>
            </TabsList>
            
            {Object.entries(categorizedQuotes).map(([category, quotes]) => (
              <TabsContent key={category} value={category} className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {category === "all" ? "All Quote Requests" : 
                       category === "pending" ? "Pending Requests" : 
                       category === "reviewed" ? "Reviewed Requests" : 
                       category === "quoted" ? "Quoted Requests" : 
                       "Rejected Requests"}
                    </CardTitle>
                    <CardDescription>
                      {quotes.length} quote {quotes.length === 1 ? "request" : "requests"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="space-y-4">
                        {[1, 2, 3, 4, 5].map((i) => (
                          <div key={i} className="animate-pulse flex items-center gap-4 py-4">
                            <div className="flex-1">
                              <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                              <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                            </div>
                            <div className="h-8 w-24 bg-gray-200 rounded"></div>
                          </div>
                        ))}
                      </div>
                    ) : quotes.length === 0 ? (
                      <div className="text-center py-8">
                        <h3 className="text-lg font-medium mb-2">No quote requests found</h3>
                        <p className="text-sm text-gray-500">
                          {category === "all" 
                            ? "There are no quote requests yet." 
                            : `There are no ${category} quote requests.`}
                        </p>
                      </div>
                    ) : (
                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Client</TableHead>
                              <TableHead>Service Type</TableHead>
                              <TableHead>Date</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {quotes.map((quote) => (
                              <TableRow key={quote.id}>
                                <TableCell>
                                  <div className="font-medium">{quote.name}</div>
                                  <div className="text-sm text-muted-foreground">{quote.email}</div>
                                </TableCell>
                                <TableCell>{getServiceTypeLabel(quote.serviceType)}</TableCell>
                                <TableCell>{format(new Date(quote.createdAt), 'MMM d, yyyy')}</TableCell>
                                <TableCell>{getStatusBadge(quote.status)}</TableCell>
                                <TableCell className="text-right space-x-2">
                                  <Button 
                                    variant="ghost" 
                                    size="icon"
                                    onClick={() => viewQuoteRequest(quote)}
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  {(quote.status === "pending" || quote.status === "reviewed") && (
                                    <Button 
                                      variant="outline" 
                                      size="icon"
                                      onClick={() => createQuote(quote)}
                                    >
                                      <FilePlus className="h-4 w-4" />
                                    </Button>
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </AdminLayout>

      {/* View Quote Request Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Quote Request Details</DialogTitle>
            <DialogDescription>
              Review the quote request information
            </DialogDescription>
          </DialogHeader>
          
          {selectedQuoteRequest && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Name:</div>
                <div className="col-span-3">{selectedQuoteRequest.name}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Email:</div>
                <div className="col-span-3">{selectedQuoteRequest.email}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Phone:</div>
                <div className="col-span-3">{selectedQuoteRequest.phone || "—"}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Service Type:</div>
                <div className="col-span-3">{getServiceTypeLabel(selectedQuoteRequest.serviceType)}</div>
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <div className="text-sm font-medium">Message:</div>
                <div className="col-span-3 whitespace-pre-wrap">{selectedQuoteRequest.message}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Date:</div>
                <div className="col-span-3">{format(new Date(selectedQuoteRequest.createdAt), 'MMMM d, yyyy, h:mm a')}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Status:</div>
                <div className="col-span-3">{getStatusBadge(selectedQuoteRequest.status)}</div>
              </div>
            </div>
          )}
          
          <DialogFooter className="gap-2 sm:gap-0">
            {selectedQuoteRequest && (selectedQuoteRequest.status === "pending" || selectedQuoteRequest.status === "reviewed") && (
              <Button onClick={() => {
                setIsViewDialogOpen(false);
                createQuote(selectedQuoteRequest);
              }}>
                Create Quote
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Quote Dialog */}
      <Dialog open={isCreateQuoteDialogOpen} onOpenChange={setIsCreateQuoteDialogOpen}>
        <DialogContent className="sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle>Create Quote</DialogTitle>
            <DialogDescription>
              Create a quote based on the client's request
            </DialogDescription>
          </DialogHeader>
          
          {selectedQuoteRequest && (
            <QuoteForm 
              quoteRequest={selectedQuoteRequest} 
              onSuccess={() => setIsCreateQuoteDialogOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
