import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Helmet } from "react-helmet";

// UI Components
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Check, Edit, Plus, Star, Trash, X } from "lucide-react";
import { AdminLayout } from "@/layouts/AdminLayout";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

// Animation components
import { FadeInContainer, SlideInFromRightContainer } from "@/components/motion/AnimatedContainer";

interface HostingPackage {
  id: number;
  name: string;
  description: string;
  priceRange: string;
  storageSpace: string;
  bandwidth: string;
  emailAccounts: string;
  supportPeriod: string;
  features: {
    name: string;
    included: boolean;
  }[];
  featured: boolean;
  popular: boolean;
  createdAt: string;
}

const hostingPackageFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  priceRange: z.string().min(1, "Price range is required"),
  storageSpace: z.string().min(1, "Storage space is required"),
  bandwidth: z.string().min(1, "Bandwidth is required"),
  emailAccounts: z.string().min(1, "Email accounts is required"),
  supportPeriod: z.string().min(1, "Support period is required"),
  featured: z.boolean(),
  popular: z.boolean(),
  features: z.array(
    z.object({
      name: z.string().min(1, "Feature name is required"),
      included: z.boolean()
    })
  ).min(1, "At least one feature is required")
});

type HostingPackageFormValues = z.infer<typeof hostingPackageFormSchema>;

export default function AdminHostingPackages() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [deletePackageId, setDeletePackageId] = useState<number | null>(null);
  const [currentPackage, setCurrentPackage] = useState<HostingPackage | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all hosting packages
  const { data: packages, isLoading } = useQuery({
    queryKey: ["/api/hosting-packages"],
  });

  // Create hosting package mutation
  const createMutation = useMutation({
    mutationFn: (packageData: HostingPackageFormValues) => 
      apiRequest("POST", "/api/hosting-packages", packageData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/hosting-packages"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Success",
        description: "Hosting package created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create hosting package",
        variant: "destructive",
      });
    }
  });

  // Update hosting package mutation
  const updateMutation = useMutation({
    mutationFn: ({ id, packageData }: { id: number; packageData: HostingPackageFormValues }) => 
      apiRequest("PUT", `/api/hosting-packages/${id}`, packageData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/hosting-packages"] });
      setIsEditDialogOpen(false);
      toast({
        title: "Success",
        description: "Hosting package updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update hosting package",
        variant: "destructive",
      });
    }
  });

  // Delete hosting package mutation
  const deleteMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest("DELETE", `/api/hosting-packages/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/hosting-packages"] });
      setDeletePackageId(null);
      toast({
        title: "Success",
        description: "Hosting package deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete hosting package",
        variant: "destructive",
      });
    }
  });

  // Create form
  const createForm = useForm<HostingPackageFormValues>({
    resolver: zodResolver(hostingPackageFormSchema),
    defaultValues: {
      name: "",
      description: "",
      priceRange: "",
      storageSpace: "",
      bandwidth: "",
      emailAccounts: "",
      supportPeriod: "",
      featured: false,
      popular: false,
      features: [{ name: "", included: true }]
    }
  });

  // Edit form
  const editForm = useForm<HostingPackageFormValues>({
    resolver: zodResolver(hostingPackageFormSchema),
    defaultValues: {
      name: "",
      description: "",
      priceRange: "",
      storageSpace: "",
      bandwidth: "",
      emailAccounts: "",
      supportPeriod: "",
      featured: false,
      popular: false,
      features: [{ name: "", included: true }]
    }
  });

  // Handle create package form submission
  const onCreateSubmit = (values: HostingPackageFormValues) => {
    createMutation.mutate(values);
  };

  // Handle edit package form submission
  const onEditSubmit = (values: HostingPackageFormValues) => {
    if (currentPackage) {
      updateMutation.mutate({ id: currentPackage.id, packageData: values });
    }
  };

  // Add new feature field
  const addFeatureField = (form: any) => {
    const features = form.getValues("features");
    form.setValue("features", [...features, { name: "", included: true }]);
  };

  // Remove feature field
  const removeFeatureField = (form: any, index: number) => {
    const features = form.getValues("features");
    if (features.length > 1) {
      form.setValue("features", features.filter((_, i) => i !== index));
    }
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Manage Hosting Packages | Admin Dashboard</title>
        <meta name="description" content="Create and manage hosting packages for your web development agency" />
      </Helmet>

      <FadeInContainer>
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Hosting Packages</h1>
            <p className="text-muted-foreground">
              Create and manage hosting packages for your clients
            </p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus size={16} /> Add New Package
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Hosting Package</DialogTitle>
                <DialogDescription>
                  Add a new hosting package with details and features
                </DialogDescription>
              </DialogHeader>
              <Form {...createForm}>
                <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={createForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Package Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Basic Hosting" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createForm.control}
                      name="priceRange"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price Range</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Ksh 500 - 1,000 per month" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={createForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe the hosting package" 
                            className="min-h-[100px]" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={createForm.control}
                      name="storageSpace"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Storage Space</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. 5GB" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createForm.control}
                      name="bandwidth"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bandwidth</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. 10GB/month" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={createForm.control}
                      name="emailAccounts"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Accounts</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. 3 accounts" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createForm.control}
                      name="supportPeriod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Support Period</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Standard support" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={createForm.control}
                      name="featured"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Featured Package</FormLabel>
                            <FormDescription>
                              Mark this package as featured on the homepage
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createForm.control}
                      name="popular"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Popular Package</FormLabel>
                            <FormDescription>
                              Mark this package as popular (with a badge)
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="text-lg font-medium">Package Features</h3>
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm"
                        onClick={() => addFeatureField(createForm)}
                      >
                        <Plus size={16} className="mr-2" /> Add Feature
                      </Button>
                    </div>
                    
                    {createForm.watch("features").map((_, index) => (
                      <div key={index} className="flex items-center gap-3 mb-3">
                        <FormField
                          control={createForm.control}
                          name={`features.${index}.name`}
                          render={({ field }) => (
                            <FormItem className="flex-1">
                              <FormControl>
                                <Input placeholder="Feature name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={createForm.control}
                          name={`features.${index}.included`}
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="icon"
                          onClick={() => removeFeatureField(createForm, index)}
                          disabled={createForm.watch("features").length <= 1}
                        >
                          <Trash size={16} className="text-destructive" />
                        </Button>
                      </div>
                    ))}
                  </div>
                  
                  <DialogFooter>
                    <Button 
                      type="submit" 
                      disabled={createMutation.isPending}
                      className="w-full md:w-auto"
                    >
                      {createMutation.isPending ? "Creating..." : "Create Package"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        <Separator className="my-6" />

        {isLoading ? (
          <div className="flex justify-center items-center py-10">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
          </div>
        ) : !packages || packages.length === 0 ? (
          <SlideInFromRightContainer>
            <Card className="border-dashed">
              <CardContent className="pt-6 text-center">
                <div className="flex flex-col items-center justify-center py-10">
                  <div className="rounded-full bg-muted p-3 mb-4">
                    <Plus size={24} className="text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No Hosting Packages</h3>
                  <p className="text-muted-foreground mb-4 max-w-md">
                    You haven't created any hosting packages yet. Start by adding your first hosting package.
                  </p>
                  <Button onClick={() => setIsCreateDialogOpen(true)}>
                    <Plus size={16} className="mr-2" /> Create Your First Package
                  </Button>
                </div>
              </CardContent>
            </Card>
          </SlideInFromRightContainer>
        ) : (
          <SlideInFromRightContainer>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Price Range</TableHead>
                    <TableHead>Storage</TableHead>
                    <TableHead>Bandwidth</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {packages.map((pkg: HostingPackage) => (
                    <TableRow key={pkg.id}>
                      <TableCell className="font-medium">{pkg.name}</TableCell>
                      <TableCell>{pkg.priceRange}</TableCell>
                      <TableCell>{pkg.storageSpace}</TableCell>
                      <TableCell>{pkg.bandwidth}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {pkg.featured && <Badge variant="outline" className="bg-blue-50">Featured</Badge>}
                          {pkg.popular && <Badge variant="outline" className="bg-yellow-50">Popular</Badge>}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setCurrentPackage(pkg);
                              editForm.reset({
                                name: pkg.name,
                                description: pkg.description,
                                priceRange: pkg.priceRange,
                                storageSpace: pkg.storageSpace,
                                bandwidth: pkg.bandwidth, 
                                emailAccounts: pkg.emailAccounts,
                                supportPeriod: pkg.supportPeriod,
                                featured: pkg.featured,
                                popular: pkg.popular,
                                features: pkg.features.length > 0 ? pkg.features : [{ name: "", included: true }]
                              });
                              setIsEditDialogOpen(true);
                            }}
                          >
                            <Edit size={16} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setDeletePackageId(pkg.id)}
                          >
                            <Trash size={16} className="text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </SlideInFromRightContainer>
        )}
      </FadeInContainer>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Hosting Package</DialogTitle>
            <DialogDescription>
              Update the details and features of this hosting package
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Package Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Basic Hosting" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="priceRange"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price Range</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Ksh 500 - 1,000 per month" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={editForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe the hosting package" 
                        className="min-h-[100px]" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="storageSpace"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Storage Space</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 5GB" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="bandwidth"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bandwidth</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 10GB/month" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="emailAccounts"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Accounts</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 3 accounts" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="supportPeriod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Support Period</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Standard support" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="featured"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Featured Package</FormLabel>
                        <FormDescription>
                          Mark this package as featured on the homepage
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="popular"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Popular Package</FormLabel>
                        <FormDescription>
                          Mark this package as popular (with a badge)
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-lg font-medium">Package Features</h3>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    onClick={() => addFeatureField(editForm)}
                  >
                    <Plus size={16} className="mr-2" /> Add Feature
                  </Button>
                </div>
                
                {editForm.watch("features").map((_, index) => (
                  <div key={index} className="flex items-center gap-3 mb-3">
                    <FormField
                      control={editForm.control}
                      name={`features.${index}.name`}
                      render={({ field }) => (
                        <FormItem className="flex-1">
                          <FormControl>
                            <Input placeholder="Feature name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editForm.control}
                      name={`features.${index}.included`}
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="icon"
                      onClick={() => removeFeatureField(editForm, index)}
                      disabled={editForm.watch("features").length <= 1}
                    >
                      <Trash size={16} className="text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
              
              <DialogFooter>
                <Button 
                  type="submit" 
                  disabled={updateMutation.isPending}
                  className="w-full md:w-auto"
                >
                  {updateMutation.isPending ? "Updating..." : "Update Package"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deletePackageId !== null} onOpenChange={(open) => !open && setDeletePackageId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this hosting package. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90"
              onClick={() => {
                if (deletePackageId !== null) {
                  deleteMutation.mutate(deletePackageId);
                }
              }}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete Package"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}