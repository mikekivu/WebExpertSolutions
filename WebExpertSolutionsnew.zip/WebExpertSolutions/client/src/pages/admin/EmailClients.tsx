import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AdminLayout } from "@/layouts/AdminLayout";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Helmet } from "react-helmet";
import { toast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Mail, Send, Users } from "lucide-react";

interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  company?: string;
  role: string;
}

const formSchema = z.object({
  subject: z.string().min(1, { message: "Subject is required" }),
  content: z.string().min(10, { message: "Content must be at least 10 characters" }),
  recipients: z.array(z.number()).min(1, { message: "At least one recipient must be selected" })
});

export default function AdminEmailClients() {
  const [, params] = useLocation();
  const query = new URLSearchParams(params);
  const clientIdParam = query.get("client");
  
  const [selectAll, setSelectAll] = useState(false);
  
  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });
  
  // Filter only clients
  const clients = users.filter(user => user.role === "client");

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      subject: "",
      content: "",
      recipients: clientIdParam ? [parseInt(clientIdParam)] : []
    }
  });

  useEffect(() => {
    if (clientIdParam) {
      form.setValue("recipients", [parseInt(clientIdParam)]);
    }
  }, [clientIdParam, form]);

  // Toggle select all clients
  useEffect(() => {
    const subscribed = form.watch((value, { name }) => {
      if (name === "recipients") {
        const allSelected = clients.length > 0 && value.recipients?.length === clients.length;
        setSelectAll(allSelected);
      }
    });
    
    return () => subscribed.unsubscribe();
  }, [form, clients]);

  // Handle select all change
  const handleSelectAllChange = (checked: boolean) => {
    setSelectAll(checked);
    if (checked) {
      form.setValue("recipients", clients.map(client => client.id));
    } else {
      form.setValue("recipients", []);
    }
  };

  // Send email mutation
  const sendEmail = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      return apiRequest("POST", "/api/emails", values);
    },
    onSuccess: () => {
      toast({
        title: "Email sent successfully",
        description: "Your email has been sent to the selected clients.",
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Failed to send email",
        description: error.message || "An error occurred while sending the email.",
        variant: "destructive",
      });
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    sendEmail.mutate(values);
  }

  // Get recipient count text
  const getRecipientCountText = () => {
    const count = form.watch("recipients")?.length || 0;
    return `${count} ${count === 1 ? "recipient" : "recipients"} selected`;
  };

  return (
    <>
      <Helmet>
        <title>Email Clients | Admin Dashboard | Web Expert Solutions</title>
        <meta name="description" content="Send emails to clients from Web Expert Solutions admin dashboard" />
      </Helmet>
      
      <AdminLayout>
        <div className="flex flex-col gap-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Email Clients</h1>
              <p className="text-gray-500">
                Send emails to one or more clients
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Client Selection */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>Select Recipients</CardTitle>
                <CardDescription>
                  Choose which clients to email
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <div key={i} className="animate-pulse flex items-center gap-4">
                        <div className="h-5 w-5 rounded bg-gray-200"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-gray-200 rounded w-3/4 mb-1"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : clients.length === 0 ? (
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">No clients found</h3>
                    <p className="text-sm text-gray-500">
                      You need to have clients to send emails
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center space-x-2 mb-4 pb-4 border-b">
                      <Checkbox 
                        id="select-all" 
                        checked={selectAll}
                        onCheckedChange={handleSelectAllChange}
                      />
                      <label
                        htmlFor="select-all"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Select All Clients
                      </label>
                    </div>
                    
                    <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                      <FormField
                        control={form.control}
                        name="recipients"
                        render={() => (
                          <FormItem>
                            {clients.map((client) => (
                              <div key={client.id} className="flex flex-row items-start space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={form.watch("recipients")?.includes(client.id)}
                                    onCheckedChange={(checked) => {
                                      const currentRecipients = form.getValues("recipients") || [];
                                      if (checked) {
                                        form.setValue("recipients", [...currentRecipients, client.id]);
                                      } else {
                                        form.setValue("recipients", currentRecipients.filter(id => id !== client.id));
                                      }
                                    }}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel className="font-medium">{client.fullName}</FormLabel>
                                  <p className="text-sm text-muted-foreground">
                                    {client.email} {client.company && `(${client.company})`}
                                  </p>
                                </div>
                              </div>
                            ))}
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="mt-4 pt-4 border-t text-sm text-muted-foreground">
                      {getRecipientCountText()}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Email Form */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Compose Email</CardTitle>
                <CardDescription>
                  Write your email message to send to clients
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                    <FormField
                      control={form.control}
                      name="subject"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Subject</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter email subject..." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="content"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Message</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Type your message here..." 
                              className="min-h-[200px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-muted-foreground">
                        <Mail className="inline-block mr-1 h-4 w-4" />
                        {getRecipientCountText()}
                      </div>
                      <Button
                        type="submit"
                        disabled={
                          sendEmail.isPending || 
                          clients.length === 0 || 
                          form.watch("recipients")?.length === 0
                        }
                      >
                        <Send className="mr-2 h-4 w-4" />
                        {sendEmail.isPending ? "Sending..." : "Send Email"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </AdminLayout>
    </>
  );
}
