import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AdminLayout } from "@/layouts/AdminLayout";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { InvoiceForm } from "@/components/forms/InvoiceForm";
import { Helmet } from "react-helmet";
import { format } from "date-fns";
import { FileText, Plus, Eye, Download } from "lucide-react";

interface Invoice {
  id: number;
  userId: number;
  quoteId?: number;
  invoiceNumber: string;
  items: any[]; // Simplified for this example
  amount: string;
  tax?: string;
  status: "unpaid" | "paid" | "overdue" | "cancelled";
  dueDate: string;
  createdAt: string;
  user?: {
    fullName: string;
    email: string;
    company?: string;
  };
}

export default function AdminInvoices() {
  const [isNewInvoiceDialogOpen, setIsNewInvoiceDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [isViewInvoiceDialogOpen, setIsViewInvoiceDialogOpen] = useState(false);
  
  const { data: invoices = [], isLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices"],
  });

  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
  });

  // Enrich invoices with user details
  const enrichedInvoices = invoices.map(invoice => {
    const user = users.find((u: any) => u.id === invoice.userId);
    return {
      ...invoice,
      user
    };
  });

  const categorizedInvoices = {
    all: enrichedInvoices,
    unpaid: enrichedInvoices.filter(invoice => invoice.status === "unpaid"),
    paid: enrichedInvoices.filter(invoice => invoice.status === "paid"),
    overdue: enrichedInvoices.filter(invoice => invoice.status === "overdue"),
    cancelled: enrichedInvoices.filter(invoice => invoice.status === "cancelled"),
  };

  const getStatusBadge = (status: string) => {
    switch(status) {
      case "paid":
        return <Badge className="bg-green-500">Paid</Badge>;
      case "unpaid":
        return <Badge variant="secondary">Unpaid</Badge>;
      case "overdue":
        return <Badge variant="destructive">Overdue</Badge>;
      case "cancelled":
        return <Badge variant="outline">Cancelled</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const viewInvoice = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setIsViewInvoiceDialogOpen(true);
  };

  const formatCurrency = (amount: string) => {
    return `KES ${parseFloat(amount).toLocaleString()}`;
  };

  return (
    <>
      <Helmet>
        <title>Invoices | Admin Dashboard | Web Expert Solutions</title>
        <meta name="description" content="Manage invoices for Web Expert Solutions" />
      </Helmet>
      
      <AdminLayout>
        <div className="flex flex-col gap-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Invoices</h1>
              <p className="text-gray-500">
                Create and manage client invoices
              </p>
            </div>
            <Button onClick={() => setIsNewInvoiceDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              New Invoice
            </Button>
          </div>

          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Invoices</TabsTrigger>
              <TabsTrigger value="unpaid">Unpaid</TabsTrigger>
              <TabsTrigger value="paid">Paid</TabsTrigger>
              <TabsTrigger value="overdue">Overdue</TabsTrigger>
              <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
            </TabsList>
            
            {Object.entries(categorizedInvoices).map(([category, invoices]) => (
              <TabsContent key={category} value={category} className="mt-0">
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {category === "all" ? "All Invoices" : 
                       category === "unpaid" ? "Unpaid Invoices" : 
                       category === "paid" ? "Paid Invoices" : 
                       category === "overdue" ? "Overdue Invoices" : 
                       "Cancelled Invoices"}
                    </CardTitle>
                    <CardDescription>
                      {invoices.length} {invoices.length === 1 ? "invoice" : "invoices"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="space-y-4">
                        {[1, 2, 3, 4, 5].map((i) => (
                          <div key={i} className="animate-pulse flex items-center gap-4 py-4">
                            <div className="flex-1">
                              <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                              <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                            </div>
                            <div className="h-8 w-24 bg-gray-200 rounded"></div>
                            <div className="h-8 w-24 bg-gray-200 rounded"></div>
                          </div>
                        ))}
                      </div>
                    ) : invoices.length === 0 ? (
                      <div className="text-center py-8">
                        <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium mb-2">No invoices found</h3>
                        <p className="text-sm text-gray-500 mb-4">
                          {category === "all" 
                            ? "You haven't created any invoices yet." 
                            : `You don't have any ${category} invoices.`}
                        </p>
                        <Button onClick={() => setIsNewInvoiceDialogOpen(true)}>
                          Create Invoice
                        </Button>
                      </div>
                    ) : (
                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Invoice</TableHead>
                              <TableHead>Client</TableHead>
                              <TableHead>Amount</TableHead>
                              <TableHead>Date</TableHead>
                              <TableHead>Due Date</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {invoices.map((invoice) => (
                              <TableRow key={invoice.id}>
                                <TableCell className="font-medium">{invoice.invoiceNumber}</TableCell>
                                <TableCell>
                                  {invoice.user ? (
                                    <>
                                      <div>{invoice.user.fullName}</div>
                                      <div className="text-sm text-muted-foreground">
                                        {invoice.user.company || invoice.user.email}
                                      </div>
                                    </>
                                  ) : (
                                    <span className="text-muted-foreground">Unknown client</span>
                                  )}
                                </TableCell>
                                <TableCell>{formatCurrency(invoice.amount)}</TableCell>
                                <TableCell>{format(new Date(invoice.createdAt), 'MMM d, yyyy')}</TableCell>
                                <TableCell>{format(new Date(invoice.dueDate), 'MMM d, yyyy')}</TableCell>
                                <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                                <TableCell className="text-right space-x-2">
                                  <Button 
                                    variant="ghost" 
                                    size="icon"
                                    onClick={() => viewInvoice(invoice)}
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="icon"
                                  >
                                    <Download className="h-4 w-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </AdminLayout>

      {/* New Invoice Dialog */}
      <Dialog open={isNewInvoiceDialogOpen} onOpenChange={setIsNewInvoiceDialogOpen}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle>Create New Invoice</DialogTitle>
            <DialogDescription>
              Create a new invoice for a client
            </DialogDescription>
          </DialogHeader>
          
          <InvoiceForm 
            onSuccess={() => setIsNewInvoiceDialogOpen(false)} 
            clients={users.filter((user: any) => user.role === "client")}
          />
        </DialogContent>
      </Dialog>

      {/* View Invoice Dialog */}
      <Dialog open={isViewInvoiceDialogOpen} onOpenChange={setIsViewInvoiceDialogOpen}>
        <DialogContent className="sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle>Invoice Details</DialogTitle>
            <DialogDescription>
              {selectedInvoice && `Invoice #${selectedInvoice.invoiceNumber}`}
            </DialogDescription>
          </DialogHeader>
          
          {selectedInvoice && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">From</h3>
                  <div className="mt-1">
                    <p className="font-medium">Web Expert Solutions Kenya</p>
                    <p>Nairobi, Kenya</p>
                    <p>info@webexpertsolutions.co.ke</p>
                    <p>+254 123 456 789</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">To</h3>
                  <div className="mt-1">
                    {selectedInvoice.user ? (
                      <>
                        <p className="font-medium">{selectedInvoice.user.fullName}</p>
                        {selectedInvoice.user.company && <p>{selectedInvoice.user.company}</p>}
                        <p>{selectedInvoice.user.email}</p>
                      </>
                    ) : (
                      <p>Unknown client</p>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Invoice Number</h3>
                  <p className="mt-1 font-medium">{selectedInvoice.invoiceNumber}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Date</h3>
                  <p className="mt-1">{format(new Date(selectedInvoice.createdAt), 'MMMM d, yyyy')}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Due Date</h3>
                  <p className="mt-1">{format(new Date(selectedInvoice.dueDate), 'MMMM d, yyyy')}</p>
                </div>
              </div>
              
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Description</TableHead>
                      <TableHead className="text-right">Quantity</TableHead>
                      <TableHead className="text-right">Unit Price</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedInvoice.items.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell>{item.description}</TableCell>
                        <TableCell className="text-right">{item.quantity}</TableCell>
                        <TableCell className="text-right">{formatCurrency(item.unitPrice)}</TableCell>
                        <TableCell className="text-right">{formatCurrency(item.total)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              <div className="flex justify-end">
                <div className="w-60 space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>{formatCurrency(selectedInvoice.amount)}</span>
                  </div>
                  {selectedInvoice.tax && (
                    <div className="flex justify-between">
                      <span>Tax:</span>
                      <span>{formatCurrency(selectedInvoice.tax)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold border-t pt-2">
                    <span>Total:</span>
                    <span>{formatCurrency(selectedInvoice.amount)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Status:</span>
                    <span>{getStatusBadge(selectedInvoice.status)}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Download PDF
                </Button>
                {selectedInvoice.status === "unpaid" && (
                  <Button variant="outline">
                    Mark as Paid
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
