import { useState } from "react";
import { Helmet } from "react-helmet";
import { AdminSidebar } from "../../components/admin/AdminSidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("general");
  const [isExpanded, setIsExpanded] = useState(true);
  
  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const handleClearCache = () => {
    // Simulate clearing cache
    setTimeout(() => {
      toast({
        title: "Cache cleared",
        description: "Application cache has been successfully cleared.",
      });
    }, 1000);
  };

  const handleResetApplication = () => {
    // Simulate application reset
    setTimeout(() => {
      toast({
        title: "Application reset",
        description: "Application settings have been reset to defaults.",
      });
    }, 1000);
  };

  return (
    <div className="min-h-screen flex">
      <AdminSidebar isExpanded={isExpanded} toggleExpanded={toggleExpanded} />
      <div className={`flex-1 ${isExpanded ? "ml-64" : "ml-16"} p-6 transition-all duration-300`}>
        <Helmet>
          <title>Settings - Admin Dashboard</title>
        </Helmet>

        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>General Settings</CardTitle>
                <CardDescription>
                  Configure general application settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <div className="flex flex-col space-y-1.5">
                    <h3 className="text-lg font-semibold">Application Name</h3>
                    <p className="text-sm text-muted-foreground">
                      The name of your application. This will be displayed in browser tabs and emails.
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <input
                        type="text"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                        value="Web Expert Solutions" 
                        readOnly
                      />
                      <Button variant="outline">Change</Button>
                    </div>
                  </div>

                  <div className="flex flex-col space-y-1.5">
                    <h3 className="text-lg font-semibold">Time Zone</h3>
                    <p className="text-sm text-muted-foreground">
                      Set your local time zone to ensure dates and times are correctly displayed.
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
                        <option value="Africa/Nairobi">Africa/Nairobi (EAT, +03:00)</option>
                        <option value="UTC">UTC (+00:00)</option>
                        <option value="America/New_York">America/New_York (EST, -05:00)</option>
                        <option value="Europe/London">Europe/London (GMT, +00:00)</option>
                      </select>
                      <Button variant="outline">Save</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Security Settings</CardTitle>
                <CardDescription>
                  Manage security and authentication settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-6">
                  <div className="flex flex-col space-y-1.5">
                    <h3 className="text-lg font-semibold">Two-Factor Authentication</h3>
                    <p className="text-sm text-muted-foreground">
                      Add an extra layer of security to your account.
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-sm bg-yellow-100 text-yellow-800 px-2 py-1 rounded-md">Not Enabled</span>
                      <Button>Enable 2FA</Button>
                    </div>
                  </div>

                  <div className="flex flex-col space-y-1.5">
                    <h3 className="text-lg font-semibold">Change Password</h3>
                    <p className="text-sm text-muted-foreground">
                      Update your account password.
                    </p>
                    <div className="grid gap-2 mt-2">
                      <input
                        type="password"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                        placeholder="Current password"
                      />
                      <input
                        type="password"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                        placeholder="New password"
                      />
                      <input
                        type="password"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                        placeholder="Confirm new password"
                      />
                      <Button className="mt-2">Update Password</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="appearance" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Appearance Settings</CardTitle>
                <CardDescription>
                  Customize how the application looks
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <div className="flex flex-col space-y-1.5">
                    <h3 className="text-lg font-semibold">Theme</h3>
                    <p className="text-sm text-muted-foreground">
                      Select your preferred application theme.
                    </p>
                    <div className="flex gap-4 mt-2">
                      <div className="flex items-center gap-2">
                        <input type="radio" id="light" name="theme" value="light" defaultChecked />
                        <label htmlFor="light">Light</label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input type="radio" id="dark" name="theme" value="dark" />
                        <label htmlFor="dark">Dark</label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input type="radio" id="system" name="theme" value="system" />
                        <label htmlFor="system">System</label>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>
                  Configure how and when you receive notifications
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Email Notifications</h3>
                      <p className="text-sm text-muted-foreground">
                        Receive email notifications for important updates.
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="email-notifications" defaultChecked className="h-4 w-4" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Invoice Alerts</h3>
                      <p className="text-sm text-muted-foreground">
                        Get notified about new and overdue invoices.
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="invoice-alerts" defaultChecked className="h-4 w-4" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Quote Request Notifications</h3>
                      <p className="text-sm text-muted-foreground">
                        Get notified when customers submit quote requests.
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="quote-notifications" defaultChecked className="h-4 w-4" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="maintenance" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Maintenance Settings</CardTitle>
                <CardDescription>
                  Perform maintenance tasks on your application
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <div className="flex flex-col space-y-1.5">
                    <h3 className="text-lg font-semibold">Clear Cache</h3>
                    <p className="text-sm text-muted-foreground">
                      Clear the application cache to resolve any display issues.
                    </p>
                    <Button variant="outline" onClick={handleClearCache} className="mt-2 w-fit">
                      Clear Cache
                    </Button>
                  </div>

                  <div className="flex flex-col space-y-1.5">
                    <h3 className="text-lg font-semibold">Reset Application</h3>
                    <p className="text-sm text-muted-foreground">
                      Reset all application settings to default values. This will not affect your data.
                    </p>
                    <Button variant="destructive" onClick={handleResetApplication} className="mt-2 w-fit">
                      Reset Application
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}