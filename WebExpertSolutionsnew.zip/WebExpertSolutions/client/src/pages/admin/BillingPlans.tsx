import { useState } from "react";
import { Helmet } from "react-helmet";
import { AdminLayout } from "@/layouts/AdminLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Trash2,
  Edit,
  Plus,
  Clock,
  Loader2,
  RefreshCw,
  CreditCard,
  CalendarClock,
  CheckCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

// Form schema for billing plans
const billingPlanSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  description: z.string().optional(),
  billingCycle: z.enum(["monthly", "quarterly", "annual"], {
    required_error: "Please select a billing cycle",
  }),
  trialPeriod: z.number().int().min(0).default(0),
  active: z.boolean().default(true),
});

type BillingCycle = {
  label: string;
  value: string;
  daysInterval: number;
  description: string;
};

const billingCycles: BillingCycle[] = [
  {
    label: "Monthly",
    value: "monthly",
    daysInterval: 30,
    description: "Bill customer every month",
  },
  {
    label: "Quarterly",
    value: "quarterly",
    daysInterval: 90,
    description: "Bill customer every 3 months",
  },
  {
    label: "Annual",
    value: "annual",
    daysInterval: 365,
    description: "Bill customer once a year",
  },
];

export default function BillingPlans() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentBillingPlan, setCurrentBillingPlan] = useState<any>(null);

  // Fetch billing plans
  const { data: billingPlans, isLoading: isLoadingBillingPlans } = useQuery({
    queryKey: ["/api/billing/billing-plans"],
  });

  // Fetch recurring invoices to show usage of plans
  const { data: recurringInvoices } = useQuery({
    queryKey: ["/api/billing/recurring-invoices"],
  });

  // Create form
  const createForm = useForm<z.infer<typeof billingPlanSchema>>({
    resolver: zodResolver(billingPlanSchema),
    defaultValues: {
      name: "",
      description: "",
      billingCycle: "monthly",
      trialPeriod: 0,
      active: true,
    },
  });

  // Edit form
  const editForm = useForm<z.infer<typeof billingPlanSchema>>({
    resolver: zodResolver(billingPlanSchema),
    defaultValues: {
      name: "",
      description: "",
      billingCycle: "monthly",
      trialPeriod: 0,
      active: true,
    },
  });

  // Create billing plan mutation
  const createBillingPlanMutation = useMutation({
    mutationFn: (data: z.infer<typeof billingPlanSchema>) => {
      return apiRequest("POST", "/api/billing/billing-plans", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Billing plan created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/billing/billing-plans"] });
      setIsCreateDialogOpen(false);
      createForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create billing plan",
        variant: "destructive",
      });
    },
  });

  // Update billing plan mutation
  const updateBillingPlanMutation = useMutation({
    mutationFn: (data: z.infer<typeof billingPlanSchema> & { id: number }) => {
      const { id, ...planData } = data;
      return apiRequest("PUT", `/api/billing/billing-plans/${id}`, planData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Billing plan updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/billing/billing-plans"] });
      setIsEditDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update billing plan",
        variant: "destructive",
      });
    },
  });

  // Delete billing plan mutation
  const deleteBillingPlanMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `/api/billing/billing-plans/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Billing plan deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/billing/billing-plans"] });
      setIsDeleteDialogOpen(false);
      setCurrentBillingPlan(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete billing plan. It may be in use by recurring invoices.",
        variant: "destructive",
      });
    },
  });

  // Handle create form submission
  const onCreateSubmit = (data: z.infer<typeof billingPlanSchema>) => {
    createBillingPlanMutation.mutate(data);
  };

  // Handle edit form submission
  const onEditSubmit = (data: z.infer<typeof billingPlanSchema>) => {
    if (currentBillingPlan) {
      updateBillingPlanMutation.mutate({
        id: currentBillingPlan.id,
        ...data,
      });
    }
  };

  // Handle delete confirmation
  const onDeleteConfirm = () => {
    if (currentBillingPlan) {
      deleteBillingPlanMutation.mutate(currentBillingPlan.id);
    }
  };

  // Open edit dialog with billing plan data
  const handleEditBillingPlan = (plan: any) => {
    setCurrentBillingPlan(plan);
    editForm.reset({
      name: plan.name,
      description: plan.description || "",
      billingCycle: plan.billingCycle,
      trialPeriod: plan.trialPeriod,
      active: plan.active,
    });
    setIsEditDialogOpen(true);
  };

  // Open delete dialog with billing plan data
  const handleDeleteBillingPlan = (plan: any) => {
    setCurrentBillingPlan(plan);
    setIsDeleteDialogOpen(true);
  };

  // Get billing cycle info by value
  const getBillingCycleInfo = (value: string) => {
    return billingCycles.find((cycle) => cycle.value === value) || billingCycles[0];
  };

  // Check if plan is in use
  const isPlanInUse = (planId: number) => {
    if (!recurringInvoices) return false;
    return recurringInvoices.some((invoice: any) => invoice.billingPlanId === planId);
  };

  // Get count of recurring invoices using this plan
  const getPlanUsageCount = (planId: number) => {
    if (!recurringInvoices) return 0;
    return recurringInvoices.filter((invoice: any) => invoice.billingPlanId === planId).length;
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Billing Plans | Admin Dashboard</title>
      </Helmet>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Billing Plans</h1>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add Billing Plan
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Create Billing Plan</DialogTitle>
                <DialogDescription>
                  Create a new billing plan for recurring invoices.
                </DialogDescription>
              </DialogHeader>

              <Form {...createForm}>
                <form
                  onSubmit={createForm.handleSubmit(onCreateSubmit)}
                  className="space-y-4 py-2"
                >
                  <FormField
                    control={createForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Plan Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Monthly Premium Hosting" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={createForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., For premium hosting services" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={createForm.control}
                    name="billingCycle"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Billing Cycle</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select billing cycle" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {billingCycles.map((cycle) => (
                              <SelectItem key={cycle.value} value={cycle.value}>
                                <div className="flex flex-col">
                                  <span>{cycle.label}</span>
                                  <span className="text-xs text-muted-foreground">
                                    {cycle.description}
                                  </span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          How often the customer will be billed
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={createForm.control}
                    name="trialPeriod"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Trial Period (Days)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="0"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormDescription>
                          Number of days before the first billing occurs (0 for no trial)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={createForm.control}
                    name="active"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Active</FormLabel>
                          <FormDescription>
                            Make this plan available for new subscriptions
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />

                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsCreateDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createBillingPlanMutation.isPending}
                    >
                      {createBillingPlanMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating...
                        </>
                      ) : (
                        "Create Plan"
                      )}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {isLoadingBillingPlans ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <CreditCard className="h-5 w-5 text-blue-500" />
                    Total Billing Plans
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{billingPlans ? billingPlans.length : 0}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <CalendarClock className="h-5 w-5 text-green-500" />
                    Active Plans
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {billingPlans ? billingPlans.filter((plan: any) => plan.active).length : 0}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <RefreshCw className="h-5 w-5 text-amber-500" />
                    Plans In Use
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {billingPlans
                      ? billingPlans.filter((plan: any) => isPlanInUse(plan.id)).length
                      : 0}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Table>
              <TableCaption>List of billing plans for recurring invoices</TableCaption>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Billing Cycle</TableHead>
                  <TableHead>Trial Period</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Usage</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {billingPlans && billingPlans.length > 0 ? (
                  billingPlans.map((plan: any) => (
                    <TableRow key={plan.id}>
                      <TableCell className="font-medium">
                        <div>
                          {plan.name}
                          {plan.description && (
                            <div className="text-xs text-muted-foreground mt-1">
                              {plan.description}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          {getBillingCycleInfo(plan.billingCycle).label}
                        </div>
                      </TableCell>
                      <TableCell>
                        {plan.trialPeriod > 0 ? (
                          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                            {plan.trialPeriod} days
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground">No trial</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={plan.active ? "default" : "outline"}
                          className={
                            plan.active
                              ? "bg-green-100 text-green-800 border-green-200"
                              : "bg-gray-100 text-gray-800 border-gray-200"
                          }
                        >
                          {plan.active ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <RefreshCw className="h-4 w-4 text-muted-foreground" />
                          <span>
                            {getPlanUsageCount(plan.id)} {getPlanUsageCount(plan.id) === 1 ? "subscription" : "subscriptions"}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEditBillingPlan(plan)}
                            title="Edit Plan"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteBillingPlan(plan)}
                            title="Delete Plan"
                            disabled={isPlanInUse(plan.id)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-6">
                      <p className="text-muted-foreground">No billing plans found</p>
                      <Button
                        variant="outline"
                        className="mt-2"
                        onClick={() => setIsCreateDialogOpen(true)}
                      >
                        <Plus className="h-4 w-4 mr-2" /> Add your first billing plan
                      </Button>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </>
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Billing Plan</DialogTitle>
            <DialogDescription>
              Update the details of this billing plan.
            </DialogDescription>
          </DialogHeader>

          <Form {...editForm}>
            <form
              onSubmit={editForm.handleSubmit(onEditSubmit)}
              className="space-y-4 py-2"
            >
              <FormField
                control={editForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Plan Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Monthly Premium Hosting" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., For premium hosting services" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="billingCycle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Billing Cycle</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select billing cycle" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {billingCycles.map((cycle) => (
                          <SelectItem key={cycle.value} value={cycle.value}>
                            <div className="flex flex-col">
                              <span>{cycle.label}</span>
                              <span className="text-xs text-muted-foreground">
                                {cycle.description}
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      How often the customer will be billed
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="trialPeriod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Trial Period (Days)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="0"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                    <FormDescription>
                      Number of days before the first billing occurs (0 for no trial)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="active"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Active</FormLabel>
                      <FormDescription>
                        Make this plan available for new subscriptions
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={updateBillingPlanMutation.isPending}
                >
                  {updateBillingPlanMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update Plan"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the billing plan "{currentBillingPlan?.name}"?
              This action cannot be undone.
              {isPlanInUse(currentBillingPlan?.id) && (
                <div className="mt-2 p-3 bg-amber-50 border border-amber-200 rounded-md text-amber-700 flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 mt-0.5 flex-shrink-0" />
                  <span>
                    This plan is currently in use by {getPlanUsageCount(currentBillingPlan?.id)}{" "}
                    {getPlanUsageCount(currentBillingPlan?.id) === 1
                      ? "subscription"
                      : "subscriptions"}
                    . You must remove all subscriptions using this plan before it can be deleted.
                  </span>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={onDeleteConfirm}
              disabled={
                deleteBillingPlanMutation.isPending || isPlanInUse(currentBillingPlan?.id)
              }
            >
              {deleteBillingPlanMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Plan"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}