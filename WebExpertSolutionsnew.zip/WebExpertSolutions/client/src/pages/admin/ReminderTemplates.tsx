import { useState } from "react";
import { Helmet } from "react-helmet";
import { AdminLayout } from "@/layouts/AdminLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Trash2,
  Edit,
  Plus,
  FileText,
  Clock,
  CheckCircle,
  Loader2,
  Eye,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

// Form schema for reminder templates
const reminderTemplateSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  type: z.enum(["upcoming", "due", "overdue", "renewal"], {
    required_error: "Please select a reminder type",
  }),
  daysOffset: z.number().int(),
  subject: z.string().min(2, { message: "Subject must be at least 2 characters" }),
  body: z.string().min(10, { message: "Body must be at least 10 characters" }),
  active: z.boolean().default(true),
});

export default function ReminderTemplates() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false);
  const [currentTemplate, setCurrentTemplate] = useState<any>(null);

  // Fetch reminder templates
  const { data: reminderTemplates, isLoading: isLoadingTemplates } = useQuery({
    queryKey: ["/api/billing/reminder-templates"],
  });

  // Create form
  const createForm = useForm<z.infer<typeof reminderTemplateSchema>>({
    resolver: zodResolver(reminderTemplateSchema),
    defaultValues: {
      name: "",
      type: "upcoming",
      daysOffset: 3,
      subject: "",
      body: "",
      active: true,
    },
  });

  // Edit form
  const editForm = useForm<z.infer<typeof reminderTemplateSchema>>({
    resolver: zodResolver(reminderTemplateSchema),
    defaultValues: {
      name: "",
      type: "upcoming",
      daysOffset: 3,
      subject: "",
      body: "",
      active: true,
    },
  });

  // Create template mutation
  const createTemplateMutation = useMutation({
    mutationFn: (data: z.infer<typeof reminderTemplateSchema>) => {
      return apiRequest("POST", "/api/billing/reminder-templates", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Reminder template created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/billing/reminder-templates"] });
      setIsCreateDialogOpen(false);
      createForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create reminder template",
        variant: "destructive",
      });
    },
  });

  // Update template mutation
  const updateTemplateMutation = useMutation({
    mutationFn: (data: z.infer<typeof reminderTemplateSchema> & { id: number }) => {
      const { id, ...templateData } = data;
      return apiRequest("PUT", `/api/billing/reminder-templates/${id}`, templateData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Reminder template updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/billing/reminder-templates"] });
      setIsEditDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update reminder template",
        variant: "destructive",
      });
    },
  });

  // Delete template mutation
  const deleteTemplateMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `/api/billing/reminder-templates/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Reminder template deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/billing/reminder-templates"] });
      setIsDeleteDialogOpen(false);
      setCurrentTemplate(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete reminder template",
        variant: "destructive",
      });
    },
  });

  // Handle create form submission
  const onCreateSubmit = (data: z.infer<typeof reminderTemplateSchema>) => {
    createTemplateMutation.mutate(data);
  };

  // Handle edit form submission
  const onEditSubmit = (data: z.infer<typeof reminderTemplateSchema>) => {
    if (currentTemplate) {
      updateTemplateMutation.mutate({
        id: currentTemplate.id,
        ...data,
      });
    }
  };

  // Handle delete confirmation
  const onDeleteConfirm = () => {
    if (currentTemplate) {
      deleteTemplateMutation.mutate(currentTemplate.id);
    }
  };

  // Open edit dialog with template data
  const handleEditTemplate = (template: any) => {
    setCurrentTemplate(template);
    editForm.reset({
      name: template.name,
      type: template.type,
      daysOffset: template.daysOffset,
      subject: template.subject,
      body: template.body,
      active: template.active,
    });
    setIsEditDialogOpen(true);
  };

  // Open delete dialog with template data
  const handleDeleteTemplate = (template: any) => {
    setCurrentTemplate(template);
    setIsDeleteDialogOpen(true);
  };

  // Open preview dialog with template data
  const handlePreviewTemplate = (template: any) => {
    setCurrentTemplate(template);
    setIsPreviewDialogOpen(true);
  };

  // Format reminder type for display
  const formatReminderType = (type: string) => {
    switch (type) {
      case "upcoming":
        return { label: "Upcoming", color: "bg-blue-100 text-blue-800 border-blue-200" };
      case "due":
        return { label: "Due", color: "bg-orange-100 text-orange-800 border-orange-200" };
      case "overdue":
        return { label: "Overdue", color: "bg-red-100 text-red-800 border-red-200" };
      case "renewal":
        return { label: "Renewal", color: "bg-green-100 text-green-800 border-green-200" };
      default:
        return { label: type, color: "bg-slate-100 text-slate-800 border-slate-200" };
    }
  };

  // Format days offset description
  const formatDaysOffset = (type: string, daysOffset: number) => {
    if (type === "upcoming" || type === "renewal") {
      return `${daysOffset} days before`;
    } else if (type === "overdue") {
      return `${daysOffset} days after`;
    } else {
      return `On due date`;
    }
  };

  const getTemplateBodyPreview = (body: string) => {
    return body.length > 100 ? `${body.substring(0, 100)}...` : body;
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Reminder Templates | Admin Dashboard</title>
      </Helmet>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Reminder Templates</h1>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add Template
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create Reminder Template</DialogTitle>
                <DialogDescription>
                  Create a new email template for automated invoice reminders.
                </DialogDescription>
              </DialogHeader>

              <Form {...createForm}>
                <form
                  onSubmit={createForm.handleSubmit(onCreateSubmit)}
                  className="space-y-4 py-2"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={createForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Template Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Invoice Due Tomorrow" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={createForm.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Reminder Type</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select template type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="upcoming">Upcoming Invoice</SelectItem>
                              <SelectItem value="due">Due Invoice</SelectItem>
                              <SelectItem value="overdue">Overdue Invoice</SelectItem>
                              <SelectItem value="renewal">Subscription Renewal</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={createForm.control}
                      name="daysOffset"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Days Offset</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormDescription>
                            {createForm.watch("type") === "upcoming" || 
                              createForm.watch("type") === "renewal"
                              ? "Days before due date to send reminder"
                              : createForm.watch("type") === "overdue"
                              ? "Days after due date to send reminder"
                              : "Set to 0 for sending on the due date"}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={createForm.control}
                      name="subject"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Subject</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Your invoice is due tomorrow" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={createForm.control}
                    name="body"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Body</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Dear {client_name}, your invoice #{invoice_number} for {amount} is due on {due_date}..."
                            className="h-48"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          You can use placeholders like {"{client_name}"}, {"{invoice_number}"}, {"{amount}"}, {"{due_date}"}, etc.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={createForm.control}
                    name="active"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Active</FormLabel>
                          <FormDescription>
                            Enable this template for automated reminders
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />

                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsCreateDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createTemplateMutation.isPending}
                    >
                      {createTemplateMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating...
                        </>
                      ) : (
                        "Create Template"
                      )}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {isLoadingTemplates ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <Table>
            <TableCaption>List of reminder templates for automatic emails</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Timing</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reminderTemplates && reminderTemplates.length > 0 ? (
                reminderTemplates.map((template: any) => (
                  <TableRow key={template.id}>
                    <TableCell className="font-medium">{template.name}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={formatReminderType(template.type).color}
                      >
                        {formatReminderType(template.type).label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        {formatDaysOffset(template.type, template.daysOffset)}
                      </div>
                    </TableCell>
                    <TableCell>
                      {template.subject.length > 30
                        ? `${template.subject.substring(0, 30)}...`
                        : template.subject}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <CheckCircle
                          className={`h-4 w-4 ${
                            template.active
                              ? "text-green-500"
                              : "text-muted-foreground"
                          }`}
                        />
                        {template.active ? "Active" : "Inactive"}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handlePreviewTemplate(template)}
                          title="Preview Template"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEditTemplate(template)}
                          title="Edit Template"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteTemplate(template)}
                          title="Delete Template"
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-6">
                    <p className="text-muted-foreground">No reminder templates found</p>
                    <Button
                      variant="outline"
                      className="mt-2"
                      onClick={() => setIsCreateDialogOpen(true)}
                    >
                      <Plus className="h-4 w-4 mr-2" /> Add your first reminder template
                    </Button>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Reminder Template</DialogTitle>
            <DialogDescription>
              Update the details of this reminder template.
            </DialogDescription>
          </DialogHeader>

          <Form {...editForm}>
            <form
              onSubmit={editForm.handleSubmit(onEditSubmit)}
              className="space-y-4 py-2"
            >
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Template Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Invoice Due Tomorrow" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reminder Type</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select template type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="upcoming">Upcoming Invoice</SelectItem>
                          <SelectItem value="due">Due Invoice</SelectItem>
                          <SelectItem value="overdue">Overdue Invoice</SelectItem>
                          <SelectItem value="renewal">Subscription Renewal</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="daysOffset"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Days Offset</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>
                        {editForm.watch("type") === "upcoming" || 
                          editForm.watch("type") === "renewal"
                          ? "Days before due date to send reminder"
                          : editForm.watch("type") === "overdue"
                          ? "Days after due date to send reminder"
                          : "Set to 0 for sending on the due date"}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Subject</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Your invoice is due tomorrow" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={editForm.control}
                name="body"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Body</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Dear {client_name}, your invoice #{invoice_number} for {amount} is due on {due_date}..."
                        className="h-48"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      You can use placeholders like {"{client_name}"}, {"{invoice_number}"}, {"{amount}"}, {"{due_date}"}, etc.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="active"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Active</FormLabel>
                      <FormDescription>
                        Enable this template for automated reminders
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={updateTemplateMutation.isPending}
                >
                  {updateTemplateMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update Template"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the reminder template "{currentTemplate?.name}"?
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={onDeleteConfirm}
              disabled={deleteTemplateMutation.isPending}
            >
              {deleteTemplateMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Template"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={isPreviewDialogOpen} onOpenChange={setIsPreviewDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Template Preview</DialogTitle>
            <DialogDescription>
              Preview how this email template will appear to clients.
            </DialogDescription>
          </DialogHeader>
          
          {currentTemplate && (
            <div className="mt-4 space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">
                    <Badge
                      variant="outline"
                      className={formatReminderType(currentTemplate.type).color}
                    >
                      {formatReminderType(currentTemplate.type).label}
                    </Badge>
                    <span className="ml-2">{currentTemplate.name}</span>
                  </CardTitle>
                  <CardDescription className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    {formatDaysOffset(currentTemplate.type, currentTemplate.daysOffset)}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="border rounded-md p-4 space-y-4">
                    <div className="border-b pb-2">
                      <h3 className="text-sm font-semibold">Subject:</h3>
                      <p>{currentTemplate.subject}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold">Body:</h3>
                      <div className="whitespace-pre-wrap text-sm mt-2">
                        {currentTemplate.body}
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="pt-2">
                  <div className="flex justify-between w-full items-center">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        Template ID: {currentTemplate.id}
                      </span>
                    </div>
                    <Badge variant={currentTemplate.active ? "default" : "outline"}>
                      {currentTemplate.active ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </CardFooter>
              </Card>
              
              <DialogFooter>
                <Button 
                  variant="outline" 
                  onClick={() => setIsPreviewDialogOpen(false)}
                >
                  Close
                </Button>
                <Button onClick={() => {
                  setIsPreviewDialogOpen(false);
                  handleEditTemplate(currentTemplate);
                }}>
                  Edit Template
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}