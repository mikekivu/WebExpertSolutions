import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { PlusCircle, Edit, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { WebPackage } from "@/components/WebPackages";
import { Helmet } from "react-helmet";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  description: z.string().min(5, { message: "Description must be at least 5 characters." }),
  priceRange: z.string().min(1, { message: "Price range is required." }),
  pagesCount: z.string().min(1, { message: "Page count is required." }),
  deliveryTime: z.string().min(1, { message: "Delivery time is required." }),
  supportPeriod: z.string().min(1, { message: "Support period is required." }),
  features: z.array(
    z.object({
      name: z.string().min(1, { message: "Feature name is required." }),
      included: z.boolean().default(true),
    })
  ),
  featured: z.boolean().default(false),
  popular: z.boolean().default(false),
});

type FormValues = z.infer<typeof formSchema>;

export default function AdminWebPackages() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentPackage, setCurrentPackage] = useState<WebPackage | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all packages
  const { data: packages, isLoading } = useQuery({
    queryKey: ["/api/web-packages"],
  });

  // Create form setup
  const createForm = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      priceRange: "",
      pagesCount: "",
      deliveryTime: "",
      supportPeriod: "",
      features: [
        { name: "Interactive", included: true },
        { name: "Basic SEO", included: true },
        { name: "Free Domain", included: false },
        { name: "Database Driven", included: false },
        { name: "Demo Design", included: false },
        { name: "Free Hosting", included: false },
        { name: "Mobile Ready", included: true },
      ],
      featured: false,
      popular: false,
    },
  });

  // Edit form setup
  const editForm = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      priceRange: "",
      pagesCount: "",
      deliveryTime: "",
      supportPeriod: "",
      features: [],
      featured: false,
      popular: false,
    },
  });

  // Reset form when dialog closes
  const handleCreateDialogChange = (open: boolean) => {
    setIsCreateDialogOpen(open);
    if (!open) {
      createForm.reset();
    }
  };

  const handleEditDialogChange = (open: boolean) => {
    setIsEditDialogOpen(open);
    if (!open) {
      editForm.reset();
    }
  };

  // Handle editing a package
  const handleEditPackage = (pkg: WebPackage) => {
    setCurrentPackage(pkg);
    
    // Initialize edit form with package data
    editForm.reset({
      name: pkg.name,
      description: pkg.description,
      priceRange: pkg.priceRange,
      pagesCount: pkg.pagesCount,
      deliveryTime: pkg.deliveryTime,
      supportPeriod: pkg.supportPeriod,
      features: pkg.features,
      featured: pkg.featured,
      popular: pkg.popular,
    });
    
    setIsEditDialogOpen(true);
  };

  // Handle deletion dialog
  const handleDeleteDialog = (pkg: WebPackage) => {
    setCurrentPackage(pkg);
    setIsDeleteDialogOpen(true);
  };

  // Add more features to form
  const addFeature = () => {
    const currentFeatures = createForm.getValues("features");
    createForm.setValue("features", [
      ...currentFeatures,
      { name: "", included: true }
    ]);
  };

  const addFeatureToEdit = () => {
    const currentFeatures = editForm.getValues("features");
    editForm.setValue("features", [
      ...currentFeatures,
      { name: "", included: true }
    ]);
  };

  // Remove a feature from form
  const removeFeature = (index: number) => {
    const currentFeatures = createForm.getValues("features");
    createForm.setValue("features", 
      currentFeatures.filter((_, i) => i !== index)
    );
  };

  const removeFeatureFromEdit = (index: number) => {
    const currentFeatures = editForm.getValues("features");
    editForm.setValue("features", 
      currentFeatures.filter((_, i) => i !== index)
    );
  };

  // Submit create form
  const onCreateSubmit = async (values: FormValues) => {
    try {
      await apiRequest("/api/web-packages", {
        method: "POST",
        body: JSON.stringify(values),
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/web-packages"] });
      toast({
        title: "Success",
        description: "Package created successfully.",
      });
      
      setIsCreateDialogOpen(false);
      createForm.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create package. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Submit edit form
  const onEditSubmit = async (values: FormValues) => {
    if (!currentPackage) return;
    
    try {
      await apiRequest(`/api/web-packages/${currentPackage.id}`, {
        method: "PUT",
        body: JSON.stringify(values),
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/web-packages"] });
      toast({
        title: "Success",
        description: "Package updated successfully.",
      });
      
      setIsEditDialogOpen(false);
      editForm.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update package. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Handle delete
  const handleDelete = async () => {
    if (!currentPackage) return;
    
    try {
      await apiRequest(`/api/web-packages/${currentPackage.id}`, {
        method: "DELETE",
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/web-packages"] });
      toast({
        title: "Success",
        description: "Package deleted successfully.",
      });
      
      setIsDeleteDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete package. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto py-10">
      <Helmet>
        <title>Manage Website Packages | Admin Dashboard</title>
      </Helmet>
      
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Manage Website Packages</h1>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={handleCreateDialogChange}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <PlusCircle size={16} />
              <span>Add Package</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Package</DialogTitle>
            </DialogHeader>
            
            <Form {...createForm}>
              <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-6 py-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={createForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Package Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Basic Plan" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="priceRange"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price Range</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. 'K.SH 8,000-15,000'" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={createForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Brief description of the package..."
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={createForm.control}
                    name="pagesCount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Pages Count</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. 'Up-To 4 Pages'" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="deliveryTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Delivery Time</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. '1-3 Days Delivery'" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="supportPeriod"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Support Period</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. '1 Week Support'" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-md font-medium">Features</h3>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={addFeature}
                      size="sm"
                    >
                      Add Feature
                    </Button>
                  </div>
                  
                  {createForm.watch("features").map((feature, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <Input
                        placeholder="Feature name"
                        value={feature.name}
                        onChange={(e) => {
                          const features = [...createForm.getValues("features")];
                          features[index].name = e.target.value;
                          createForm.setValue("features", features);
                        }}
                      />
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={feature.included}
                          onCheckedChange={(checked) => {
                            const features = [...createForm.getValues("features")];
                            features[index].included = !!checked;
                            createForm.setValue("features", features);
                          }}
                        />
                        <Label>Included</Label>
                      </div>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        onClick={() => removeFeature(index)}
                        size="sm"
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  ))}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={createForm.control}
                    name="featured"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Featured Package
                          </FormLabel>
                          <FormDescription>
                            Mark this package as featured in the list
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="popular"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Popular Package
                          </FormLabel>
                          <FormDescription>
                            Mark this package as popular in the list
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex justify-end gap-3 pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">Create Package</Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      {isLoading ? (
        <div className="text-center py-10">Loading packages...</div>
      ) : !packages || packages.length === 0 ? (
        <div className="text-center py-10">
          <p className="mb-4">No packages found. Create your first package!</p>
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Price Range</TableHead>
                <TableHead>Pages</TableHead>
                <TableHead>Delivery</TableHead>
                <TableHead>Featured/Popular</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {packages.map((pkg: WebPackage) => (
                <TableRow key={pkg.id}>
                  <TableCell className="font-medium">{pkg.name}</TableCell>
                  <TableCell>{pkg.priceRange}</TableCell>
                  <TableCell>{pkg.pagesCount}</TableCell>
                  <TableCell>{pkg.deliveryTime}</TableCell>
                  <TableCell>
                    {pkg.featured && <span className="mr-2 px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">Featured</span>}
                    {pkg.popular && <span className="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">Popular</span>}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handleEditPackage(pkg)}
                      >
                        <Edit size={16} />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handleDeleteDialog(pkg)}
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      
      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={handleEditDialogChange}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Package</DialogTitle>
          </DialogHeader>
          
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-6 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Package Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="priceRange"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price Range</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={editForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={editForm.control}
                  name="pagesCount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pages Count</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="deliveryTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Delivery Time</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="supportPeriod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Support Period</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-md font-medium">Features</h3>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={addFeatureToEdit}
                    size="sm"
                  >
                    Add Feature
                  </Button>
                </div>
                
                {editForm.watch("features").map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <Input
                      placeholder="Feature name"
                      value={feature.name}
                      onChange={(e) => {
                        const features = [...editForm.getValues("features")];
                        features[index].name = e.target.value;
                        editForm.setValue("features", features);
                      }}
                    />
                    <div className="flex items-center gap-2">
                      <Checkbox
                        checked={feature.included}
                        onCheckedChange={(checked) => {
                          const features = [...editForm.getValues("features")];
                          features[index].included = !!checked;
                          editForm.setValue("features", features);
                        }}
                      />
                      <Label>Included</Label>
                    </div>
                    <Button 
                      type="button" 
                      variant="ghost" 
                      onClick={() => removeFeatureFromEdit(index)}
                      size="sm"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                ))}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="featured"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">
                          Featured Package
                        </FormLabel>
                        <FormDescription>
                          Mark this package as featured in the list
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="popular"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">
                          Popular Package
                        </FormLabel>
                        <FormDescription>
                          Mark this package as popular in the list
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="flex justify-end gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Save Changes</Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>Are you sure you want to delete the <strong>{currentPackage?.name}</strong> package? This action cannot be undone.</p>
          </div>
          <div className="flex justify-end gap-3">
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDelete}
            >
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}