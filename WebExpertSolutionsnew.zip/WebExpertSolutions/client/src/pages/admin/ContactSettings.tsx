import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Helmet } from "react-helmet";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { AdminLayout } from "@/layouts/AdminLayout";
import type { ContactInfo, InsertContactInfo } from "@shared/schema";

const contactFormSchema = z.object({
  phoneNumber1: z.string().min(5, "Phone number is required"),
  phoneNumber2: z.string().optional(),
  email: z.string().email("Please enter a valid email address"),
  location: z.string().min(5, "Location is required"),
  googleMapLink: z.string().optional(),
});

export default function ContactSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: contactInfo, isLoading } = useQuery<ContactInfo>({
    queryKey: ['/api/contact'],
  });

  const form = useForm<z.infer<typeof contactFormSchema>>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      phoneNumber1: "",
      phoneNumber2: "",
      email: "",
      location: "",
      googleMapLink: "",
    },
  });

  useEffect(() => {
    if (contactInfo) {
      form.reset({
        phoneNumber1: contactInfo.phoneNumber1 || "",
        phoneNumber2: contactInfo.phoneNumber2 || "",
        email: contactInfo.email || "",
        location: contactInfo.location || "",
        googleMapLink: contactInfo.googleMapLink || "",
      });
    }
  }, [contactInfo, form]);

  const updateMutation = useMutation({
    mutationFn: async (data: InsertContactInfo) => {
      return await apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "Contact information updated",
        description: "The contact information has been successfully updated.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/contact'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update contact information. Please try again.",
        variant: "destructive",
      });
      console.error("Error updating contact information:", error);
    },
  });

  const onSubmit = (data: z.infer<typeof contactFormSchema>) => {
    updateMutation.mutate(data);
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Contact Settings - Admin Dashboard</title>
      </Helmet>
      
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Contact Settings</h1>
          <p className="text-muted-foreground">
            Manage your company's contact information displayed on the website.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Contact Information</CardTitle>
            <CardDescription>
              Update the contact details that will be displayed on your website's contact page.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center items-center h-40">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="phoneNumber1"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Primary Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="+1234567890" {...field} />
                          </FormControl>
                          <FormDescription>
                            This will be displayed as your main contact number.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phoneNumber2"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Secondary Phone Number (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="+1234567890" {...field} />
                          </FormControl>
                          <FormDescription>
                            An additional contact number (optional).
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="contact@example.com" {...field} />
                        </FormControl>
                        <FormDescription>
                          The email address where customers can reach you.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Physical Address</FormLabel>
                        <FormControl>
                          <Input placeholder="123 Business St, City, Country" {...field} />
                        </FormControl>
                        <FormDescription>
                          Your office location or business address.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="googleMapLink"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Google Maps Link (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="https://maps.google.com/?q=..." {...field} />
                        </FormControl>
                        <FormDescription>
                          A link to your location on Google Maps.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="mt-4"
                    disabled={updateMutation.isPending}
                  >
                    {updateMutation.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    Save Changes
                  </Button>
                </form>
              </Form>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}