import { useState } from "react";
import { AdminLayout } from "@/layouts/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Edit, Trash, Plus } from "lucide-react";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export default function AdminSoftwareSolutions() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedSolution, setSelectedSolution] = useState<any>(null);

  // Mock data for software solutions
  const [softwareSolutions, setSoftwareSolutions] = useState([
    {
      id: 1,
      name: "Point of Sale (POS) System",
      description: "Complete POS solution for retail, restaurants, and service businesses with inventory management, sales tracking, and reporting.",
      category: "pos",
      price: 120000,
      deploymentType: "cloud",
      supportPeriod: "12 months",
      featured: true,
      status: "active",
    },
    {
      id: 2,
      name: "Microfinance Management System",
      description: "Comprehensive management system for microfinance institutions with loan processing, client management, and financial reporting.",
      category: "finance",
      price: 250000,
      deploymentType: "on-premise",
      supportPeriod: "24 months",
      featured: true,
      status: "active",
    },
    {
      id: 3,
      name: "School Management System",
      description: "Complete school administration software for managing students, staff, curriculum, and administrative tasks.",
      category: "education",
      price: 180000,
      deploymentType: "hybrid",
      supportPeriod: "12 months",
      featured: false,
      status: "active",
    },
  ]);

  const handleAddSolution = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newSolution = {
      id: softwareSolutions.length + 1,
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      category: formData.get("category") as string,
      price: Number(formData.get("price")),
      deploymentType: formData.get("deploymentType") as string,
      supportPeriod: formData.get("supportPeriod") as string,
      featured: formData.get("featured") === "on",
      status: "active",
    };

    setSoftwareSolutions([...softwareSolutions, newSolution]);
    setIsAddDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Software solution has been added successfully.",
    });
  };

  const handleEditSolution = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedSolution) return;

    const formData = new FormData(e.currentTarget);
    const updatedSolutions = softwareSolutions.map(solution => {
      if (solution.id === selectedSolution.id) {
        return {
          ...solution,
          name: formData.get("name") as string,
          description: formData.get("description") as string,
          category: formData.get("category") as string,
          price: Number(formData.get("price")),
          deploymentType: formData.get("deploymentType") as string,
          supportPeriod: formData.get("supportPeriod") as string,
          featured: formData.get("featured") === "on",
        };
      }
      return solution;
    });

    setSoftwareSolutions(updatedSolutions);
    setIsEditDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Software solution has been updated successfully.",
    });
  };

  const handleDeleteSolution = () => {
    if (!selectedSolution) return;

    const updatedSolutions = softwareSolutions.filter(solution => solution.id !== selectedSolution.id);
    setSoftwareSolutions(updatedSolutions);
    setIsDeleteDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Software solution has been deleted successfully.",
    });
  };

  const openEditDialog = (solution: any) => {
    setSelectedSolution(solution);
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (solution: any) => {
    setSelectedSolution(solution);
    setIsDeleteDialogOpen(true);
  };

  const getCategoryLabel = (category: string) => {
    switch(category) {
      case 'pos': return 'Point of Sale';
      case 'finance': return 'Finance';
      case 'education': return 'Education';
      case 'healthcare': return 'Healthcare';
      case 'crm': return 'CRM';
      case 'erp': return 'ERP';
      default: return category;
    }
  };

  const getDeploymentTypeLabel = (type: string) => {
    switch(type) {
      case 'cloud': return 'Cloud-based';
      case 'on-premise': return 'On-premise';
      case 'hybrid': return 'Hybrid';
      default: return type;
    }
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Manage Software Solutions | Admin Dashboard</title>
      </Helmet>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Software Solutions</h1>
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" /> Add New Solution
          </Button>
        </div>

        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Solutions</TabsTrigger>
            <TabsTrigger value="featured">Featured</TabsTrigger>
            <TabsTrigger value="pos">POS Systems</TabsTrigger>
            <TabsTrigger value="finance">Finance Systems</TabsTrigger>
            <TabsTrigger value="education">Education Systems</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>All Software Solutions</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Deployment</TableHead>
                      <TableHead>Price (KSh)</TableHead>
                      <TableHead>Support Period</TableHead>
                      <TableHead>Featured</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {softwareSolutions.map(solution => (
                      <TableRow key={solution.id}>
                        <TableCell className="font-medium">{solution.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {getCategoryLabel(solution.category)}
                          </Badge>
                        </TableCell>
                        <TableCell>{getDeploymentTypeLabel(solution.deploymentType)}</TableCell>
                        <TableCell>{solution.price.toLocaleString()}</TableCell>
                        <TableCell>{solution.supportPeriod}</TableCell>
                        <TableCell>{solution.featured ? "Yes" : "No"}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" onClick={() => openEditDialog(solution)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => openDeleteDialog(solution)}>
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="featured">
            <Card>
              <CardHeader>
                <CardTitle>Featured Software Solutions</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Deployment</TableHead>
                      <TableHead>Price (KSh)</TableHead>
                      <TableHead>Support Period</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {softwareSolutions.filter(solution => solution.featured).map(solution => (
                      <TableRow key={solution.id}>
                        <TableCell className="font-medium">{solution.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {getCategoryLabel(solution.category)}
                          </Badge>
                        </TableCell>
                        <TableCell>{getDeploymentTypeLabel(solution.deploymentType)}</TableCell>
                        <TableCell>{solution.price.toLocaleString()}</TableCell>
                        <TableCell>{solution.supportPeriod}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" onClick={() => openEditDialog(solution)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => openDeleteDialog(solution)}>
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          {['pos', 'finance', 'education'].map(category => (
            <TabsContent key={category} value={category}>
              <Card>
                <CardHeader>
                  <CardTitle>{getCategoryLabel(category)} Solutions</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Deployment</TableHead>
                        <TableHead>Price (KSh)</TableHead>
                        <TableHead>Support Period</TableHead>
                        <TableHead>Featured</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {softwareSolutions.filter(solution => solution.category === category).map(solution => (
                        <TableRow key={solution.id}>
                          <TableCell className="font-medium">{solution.name}</TableCell>
                          <TableCell>{getDeploymentTypeLabel(solution.deploymentType)}</TableCell>
                          <TableCell>{solution.price.toLocaleString()}</TableCell>
                          <TableCell>{solution.supportPeriod}</TableCell>
                          <TableCell>{solution.featured ? "Yes" : "No"}</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline" onClick={() => openEditDialog(solution)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => openDeleteDialog(solution)}>
                                <Trash className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>

        {/* Add Dialog */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Software Solution</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddSolution}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Solution Name</Label>
                  <Input id="name" name="name" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" name="description" rows={4} required />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select name="category" defaultValue="pos">
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Select Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pos">Point of Sale</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="education">Education</SelectItem>
                        <SelectItem value="healthcare">Healthcare</SelectItem>
                        <SelectItem value="crm">CRM</SelectItem>
                        <SelectItem value="erp">ERP</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="deploymentType">Deployment Type</Label>
                    <Select name="deploymentType" defaultValue="cloud">
                      <SelectTrigger id="deploymentType">
                        <SelectValue placeholder="Select Deployment Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cloud">Cloud-based</SelectItem>
                        <SelectItem value="on-premise">On-premise</SelectItem>
                        <SelectItem value="hybrid">Hybrid</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="price">Price (KSh)</Label>
                    <Input id="price" name="price" type="number" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="supportPeriod">Support Period</Label>
                    <Input id="supportPeriod" name="supportPeriod" placeholder="e.g., 12 months" required />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="featured" name="featured" />
                  <Label htmlFor="featured">Featured Solution</Label>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Software Solution</DialogTitle>
            </DialogHeader>
            {selectedSolution && (
              <form onSubmit={handleEditSolution}>
                <div className="grid gap-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-name">Solution Name</Label>
                    <Input id="edit-name" name="name" defaultValue={selectedSolution.name} required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-description">Description</Label>
                    <Textarea id="edit-description" name="description" rows={4} defaultValue={selectedSolution.description} required />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-category">Category</Label>
                      <Select name="category" defaultValue={selectedSolution.category}>
                        <SelectTrigger id="edit-category">
                          <SelectValue placeholder="Select Category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pos">Point of Sale</SelectItem>
                          <SelectItem value="finance">Finance</SelectItem>
                          <SelectItem value="education">Education</SelectItem>
                          <SelectItem value="healthcare">Healthcare</SelectItem>
                          <SelectItem value="crm">CRM</SelectItem>
                          <SelectItem value="erp">ERP</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-deploymentType">Deployment Type</Label>
                      <Select name="deploymentType" defaultValue={selectedSolution.deploymentType}>
                        <SelectTrigger id="edit-deploymentType">
                          <SelectValue placeholder="Select Deployment Type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cloud">Cloud-based</SelectItem>
                          <SelectItem value="on-premise">On-premise</SelectItem>
                          <SelectItem value="hybrid">Hybrid</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-price">Price (KSh)</Label>
                      <Input id="edit-price" name="price" type="number" defaultValue={selectedSolution.price} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-supportPeriod">Support Period</Label>
                      <Input id="edit-supportPeriod" name="supportPeriod" defaultValue={selectedSolution.supportPeriod} required />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch id="edit-featured" name="featured" checked={selectedSolution.featured} />
                    <Label htmlFor="edit-featured">Featured Solution</Label>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Update</Button>
                </DialogFooter>
              </form>
            )}
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Deletion</DialogTitle>
            </DialogHeader>
            <p>Are you sure you want to delete this software solution? This action cannot be undone.</p>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="button" variant="destructive" onClick={handleDeleteSolution}>
                Delete
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}