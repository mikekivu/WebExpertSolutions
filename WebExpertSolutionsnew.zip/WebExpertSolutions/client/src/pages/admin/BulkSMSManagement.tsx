import { useState } from "react";
import { AdminLayout } from "@/layouts/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Edit, Trash, Plus, MessageSquare, Users, Send } from "lucide-react";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function AdminBulkSMSManagement() {
  const { toast } = useToast();
  const [isAddSMSPackageDialogOpen, setIsAddSMSPackageDialogOpen] = useState(false);
  const [isEditSMSPackageDialogOpen, setIsEditSMSPackageDialogOpen] = useState(false);
  const [isDeleteSMSPackageDialogOpen, setIsDeleteSMSPackageDialogOpen] = useState(false);
  const [isNewCampaignDialogOpen, setIsNewCampaignDialogOpen] = useState(false);
  const [selectedSMSPackage, setSelectedSMSPackage] = useState<any>(null);
  const [selectedRecipientGroup, setSelectedRecipientGroup] = useState<string>("all");

  // Mock data for SMS packages
  const [smsPackages, setSMSPackages] = useState([
    {
      id: 1,
      name: "Basic SMS Package",
      description: "Entry-level SMS package for small businesses",
      price: 0.80,
      minQuantity: 1000,
      maxQuantity: 9999,
      features: [
        "Web-based SMS platform",
        "Delivery reports",
        "Basic contact management",
        "30-day message history"
      ],
      status: "active",
      featured: false
    },
    {
      id: 2,
      name: "Standard SMS Package",
      description: "Mid-level SMS package for growing businesses",
      price: 0.65,
      minQuantity: 10000,
      maxQuantity: 49999,
      features: [
        "Advanced web dashboard",
        "Detailed analytics",
        "Group messaging",
        "Message scheduling",
        "90-day message history"
      ],
      status: "active",
      featured: true
    },
    {
      id: 3,
      name: "Enterprise SMS Package",
      description: "Advanced SMS package for large organizations",
      price: 0.50,
      minQuantity: 50000,
      maxQuantity: null,
      features: [
        "Premium dashboard access",
        "Priority delivery",
        "API integration",
        "Advanced personalization",
        "Dedicated account manager",
        "1-year message history"
      ],
      status: "active",
      featured: false
    }
  ]);

  // Mock data for SMS campaigns
  const [smsCampaigns, setSmsCampaigns] = useState([
    {
      id: 1,
      name: "May Promotion",
      status: "completed",
      sentDate: "2023-05-10T14:30:00",
      totalRecipients: 1250,
      deliveryRate: 98,
      message: "Get 20% off on all products this May with code MAY23. Visit our website at example.com or call us at 0712345678. Reply STOP to opt out."
    },
    {
      id: 2,
      name: "June Newsletter",
      status: "scheduled",
      scheduledDate: "2023-06-15T09:00:00",
      totalRecipients: 2500,
      message: "Our June newsletter is out! Check your email for exciting updates and special offers. Reply STOP to opt out."
    },
    {
      id: 3,
      name: "Event Reminder",
      status: "in-progress",
      sentDate: "2023-05-17T08:00:00",
      totalRecipients: 500,
      deliveryRate: 75,
      message: "Reminder: Your appointment is tomorrow at 2:00 PM. Reply C to confirm or R to reschedule. Call 0712345678 for assistance."
    }
  ]);

  // Mock data for contact groups
  const [contactGroups, setContactGroups] = useState([
    {
      id: 1,
      name: "All Customers",
      count: 3500,
      description: "Complete customer database"
    },
    {
      id: 2,
      name: "Premium Members",
      count: 750,
      description: "High-value customers with premium subscriptions"
    },
    {
      id: 3,
      name: "New Subscribers",
      count: 1200,
      description: "Customers who signed up in the last 30 days"
    },
    {
      id: 4,
      name: "Event Attendees",
      count: 500,
      description: "Customers registered for upcoming event"
    }
  ]);

  const handleAddSMSPackage = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const featuresText = formData.get("features") as string;
    const features = featuresText.split('\n').filter(feature => feature.trim() !== '');
    
    const newPackage = {
      id: smsPackages.length + 1,
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      price: parseFloat(formData.get("price") as string),
      minQuantity: parseInt(formData.get("minQuantity") as string),
      maxQuantity: formData.get("maxQuantity") ? parseInt(formData.get("maxQuantity") as string) : null,
      features,
      status: "active",
      featured: formData.get("featured") === "on"
    };

    setSMSPackages([...smsPackages, newPackage]);
    setIsAddSMSPackageDialogOpen(false);
    
    toast({
      title: "Success",
      description: "SMS package has been added successfully.",
    });
  };

  const handleEditSMSPackage = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedSMSPackage) return;

    const formData = new FormData(e.currentTarget);
    
    const featuresText = formData.get("features") as string;
    const features = featuresText.split('\n').filter(feature => feature.trim() !== '');
    
    const updatedPackages = smsPackages.map(pkg => {
      if (pkg.id === selectedSMSPackage.id) {
        return {
          ...pkg,
          name: formData.get("name") as string,
          description: formData.get("description") as string,
          price: parseFloat(formData.get("price") as string),
          minQuantity: parseInt(formData.get("minQuantity") as string),
          maxQuantity: formData.get("maxQuantity") ? parseInt(formData.get("maxQuantity") as string) : null,
          features,
          featured: formData.get("featured") === "on"
        };
      }
      return pkg;
    });

    setSMSPackages(updatedPackages);
    setIsEditSMSPackageDialogOpen(false);
    
    toast({
      title: "Success",
      description: "SMS package has been updated successfully.",
    });
  };

  const handleDeleteSMSPackage = () => {
    if (!selectedSMSPackage) return;

    const updatedPackages = smsPackages.filter(pkg => pkg.id !== selectedSMSPackage.id);
    setSMSPackages(updatedPackages);
    setIsDeleteSMSPackageDialogOpen(false);
    
    toast({
      title: "Success",
      description: "SMS package has been deleted successfully.",
    });
  };

  const handleCreateCampaign = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const name = formData.get("campaignName") as string;
    const message = formData.get("message") as string;
    const isScheduled = formData.get("scheduleType") === "scheduled";
    
    let recipientCount = 0;
    if (selectedRecipientGroup === "all") {
      recipientCount = contactGroups.reduce((sum, group) => sum + group.count, 0);
    } else {
      const group = contactGroups.find(g => g.id.toString() === selectedRecipientGroup);
      if (group) {
        recipientCount = group.count;
      }
    }
    
    const newCampaign = {
      id: smsCampaigns.length + 1,
      name,
      status: isScheduled ? "scheduled" : "in-progress",
      sentDate: isScheduled ? null : new Date().toISOString(),
      scheduledDate: isScheduled ? (formData.get("scheduledDate") as string + "T" + formData.get("scheduledTime") as string) : null,
      totalRecipients: recipientCount,
      deliveryRate: isScheduled ? null : 0,
      message
    };

    setSmsCampaigns([...smsCampaigns, newCampaign]);
    setIsNewCampaignDialogOpen(false);
    
    toast({
      title: "Success",
      description: isScheduled ? "SMS campaign has been scheduled successfully." : "SMS campaign is being sent now.",
    });
  };

  const openEditSMSPackageDialog = (pkg: any) => {
    setSelectedSMSPackage(pkg);
    setIsEditSMSPackageDialogOpen(true);
  };

  const openDeleteSMSPackageDialog = (pkg: any) => {
    setSelectedSMSPackage(pkg);
    setIsDeleteSMSPackageDialogOpen(true);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getCampaignStatusBadge = (status: string) => {
    switch(status) {
      case 'completed':
        return <Badge variant="default" className="bg-green-500">Completed</Badge>;
      case 'in-progress':
        return <Badge variant="secondary">In Progress</Badge>;
      case 'scheduled':
        return <Badge variant="outline">Scheduled</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <AdminLayout>
      <Helmet>
        <title>Bulk SMS Management | Admin Dashboard</title>
      </Helmet>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Bulk SMS Management</h1>
        </div>

        <Tabs defaultValue="campaigns">
          <TabsList className="mb-4">
            <TabsTrigger value="campaigns">SMS Campaigns</TabsTrigger>
            <TabsTrigger value="packages">SMS Packages</TabsTrigger>
            <TabsTrigger value="contacts">Contact Groups</TabsTrigger>
          </TabsList>
          
          {/* SMS Campaigns Tab */}
          <TabsContent value="campaigns">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">SMS Campaigns</h2>
              <Button onClick={() => setIsNewCampaignDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" /> New Campaign
              </Button>
            </div>
            <Card>
              <CardContent className="p-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Campaign Name</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Recipients</TableHead>
                      <TableHead>Delivery</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {smsCampaigns.map(campaign => (
                      <TableRow key={campaign.id}>
                        <TableCell className="font-medium">{campaign.name}</TableCell>
                        <TableCell>{getCampaignStatusBadge(campaign.status)}</TableCell>
                        <TableCell>
                          {campaign.status === 'scheduled' 
                            ? formatDate(campaign.scheduledDate as string) 
                            : formatDate(campaign.sentDate as string)}
                        </TableCell>
                        <TableCell>{campaign.totalRecipients.toLocaleString()}</TableCell>
                        <TableCell>
                          {campaign.deliveryRate ? (
                            <div className="flex flex-col space-y-1">
                              <div className="flex justify-between items-center text-xs">
                                <span>{campaign.deliveryRate}%</span>
                              </div>
                              <Progress value={campaign.deliveryRate} className="h-2" />
                            </div>
                          ) : (
                            campaign.status === 'scheduled' ? "Pending" : "In progress"
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline">
                              <MessageSquare className="h-4 w-4" />
                            </Button>
                            {campaign.status === 'scheduled' && (
                              <Button size="sm" variant="destructive">
                                <Trash className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* SMS Packages Tab */}
          <TabsContent value="packages">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">SMS Packages</h2>
              <Button onClick={() => setIsAddSMSPackageDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" /> Add Package
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {smsPackages.map(pkg => (
                <Card key={pkg.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{pkg.name}</CardTitle>
                        {pkg.featured && <Badge className="mt-2">Featured</Badge>}
                      </div>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" onClick={() => openEditSMSPackageDialog(pkg)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => openDeleteSMSPackageDialog(pkg)}>
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <div className="text-3xl font-bold mb-1">Ksh {pkg.price.toFixed(2)}</div>
                      <div className="text-sm text-muted-foreground">per SMS</div>
                    </div>
                    <div className="text-sm mb-4">{pkg.description}</div>
                    <div className="text-sm mb-4">
                      {pkg.maxQuantity 
                        ? `${pkg.minQuantity.toLocaleString()} - ${pkg.maxQuantity.toLocaleString()} SMS` 
                        : `${pkg.minQuantity.toLocaleString()}+ SMS`}
                    </div>
                    <div className="border-t pt-4">
                      <h4 className="font-medium mb-2">Features:</h4>
                      <ul className="space-y-2 text-sm">
                        {pkg.features.map((feature, index) => (
                          <li key={index} className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          {/* Contact Groups Tab */}
          <TabsContent value="contacts">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Contact Groups</h2>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Add Group
              </Button>
            </div>
            <Card>
              <CardContent className="p-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Group Name</TableHead>
                      <TableHead>Contacts</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contactGroups.map(group => (
                      <TableRow key={group.id}>
                        <TableCell className="font-medium">{group.name}</TableCell>
                        <TableCell>{group.count.toLocaleString()}</TableCell>
                        <TableCell>{group.description}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline">
                              <Users className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="destructive">
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Add SMS Package Dialog */}
        <Dialog open={isAddSMSPackageDialogOpen} onOpenChange={setIsAddSMSPackageDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New SMS Package</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddSMSPackage}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Package Name</Label>
                  <Input id="name" name="name" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" name="description" rows={2} required />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="price">Price per SMS (KSh)</Label>
                    <Input id="price" name="price" type="number" step="0.01" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="minQuantity">Minimum Quantity</Label>
                    <Input id="minQuantity" name="minQuantity" type="number" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maxQuantity">Maximum Quantity (optional)</Label>
                    <Input id="maxQuantity" name="maxQuantity" type="number" placeholder="Leave empty for unlimited" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="features">Features (one per line)</Label>
                  <Textarea 
                    id="features" 
                    name="features" 
                    rows={4} 
                    placeholder="Web-based SMS platform
Delivery reports
Basic contact management"
                    required 
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="featured" name="featured" />
                  <Label htmlFor="featured">Featured Package</Label>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddSMSPackageDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Edit SMS Package Dialog */}
        <Dialog open={isEditSMSPackageDialogOpen} onOpenChange={setIsEditSMSPackageDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit SMS Package</DialogTitle>
            </DialogHeader>
            {selectedSMSPackage && (
              <form onSubmit={handleEditSMSPackage}>
                <div className="grid gap-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-name">Package Name</Label>
                    <Input id="edit-name" name="name" defaultValue={selectedSMSPackage.name} required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-description">Description</Label>
                    <Textarea 
                      id="edit-description" 
                      name="description" 
                      rows={2} 
                      defaultValue={selectedSMSPackage.description} 
                      required 
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-price">Price per SMS (KSh)</Label>
                      <Input 
                        id="edit-price" 
                        name="price" 
                        type="number" 
                        step="0.01" 
                        defaultValue={selectedSMSPackage.price} 
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-minQuantity">Minimum Quantity</Label>
                      <Input 
                        id="edit-minQuantity" 
                        name="minQuantity" 
                        type="number" 
                        defaultValue={selectedSMSPackage.minQuantity} 
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-maxQuantity">Maximum Quantity (optional)</Label>
                      <Input 
                        id="edit-maxQuantity" 
                        name="maxQuantity" 
                        type="number" 
                        defaultValue={selectedSMSPackage.maxQuantity || ""} 
                        placeholder="Leave empty for unlimited" 
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-features">Features (one per line)</Label>
                    <Textarea 
                      id="edit-features" 
                      name="features" 
                      rows={4} 
                      defaultValue={selectedSMSPackage.features.join('\n')} 
                      required 
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="edit-featured" 
                      name="featured" 
                      checked={selectedSMSPackage.featured} 
                    />
                    <Label htmlFor="edit-featured">Featured Package</Label>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsEditSMSPackageDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Update</Button>
                </DialogFooter>
              </form>
            )}
          </DialogContent>
        </Dialog>

        {/* Delete SMS Package Dialog */}
        <Dialog open={isDeleteSMSPackageDialogOpen} onOpenChange={setIsDeleteSMSPackageDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Deletion</DialogTitle>
            </DialogHeader>
            <p>Are you sure you want to delete the <strong>{selectedSMSPackage?.name}</strong> package? This action cannot be undone.</p>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDeleteSMSPackageDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="button" variant="destructive" onClick={handleDeleteSMSPackage}>
                Delete
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* New Campaign Dialog */}
        <Dialog open={isNewCampaignDialogOpen} onOpenChange={setIsNewCampaignDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New SMS Campaign</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateCampaign}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="campaignName">Campaign Name</Label>
                  <Input id="campaignName" name="campaignName" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">Message Content</Label>
                  <Textarea 
                    id="message" 
                    name="message" 
                    rows={4} 
                    placeholder="Type your SMS message here..."
                    required 
                  />
                  <p className="text-xs text-muted-foreground">
                    Character count: 0/160 (1 SMS)
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Recipients</Label>
                  <Select 
                    defaultValue="all" 
                    onValueChange={setSelectedRecipientGroup}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select recipient group" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Contact Groups ({contactGroups.reduce((sum, group) => sum + group.count, 0).toLocaleString()} contacts)</SelectItem>
                      {contactGroups.map(group => (
                        <SelectItem key={group.id} value={group.id.toString()}>
                          {group.name} ({group.count.toLocaleString()} contacts)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Scheduling</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="sendNow" 
                        name="scheduleType" 
                        value="now" 
                        defaultChecked 
                        className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                      />
                      <Label htmlFor="sendNow" className="cursor-pointer">Send immediately</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="schedule" 
                        name="scheduleType" 
                        value="scheduled" 
                        className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                      />
                      <Label htmlFor="schedule" className="cursor-pointer">Schedule for later</Label>
                    </div>
                  </div>
                </div>

                <div id="scheduleDetails" className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="scheduledDate">Date</Label>
                    <Input 
                      id="scheduledDate" 
                      name="scheduledDate" 
                      type="date" 
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="scheduledTime">Time</Label>
                    <Input 
                      id="scheduledTime" 
                      name="scheduledTime" 
                      type="time" 
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsNewCampaignDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="gap-2">
                  <Send className="h-4 w-4" /> Create Campaign
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}