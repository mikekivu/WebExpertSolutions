import { Helmet } from "react-helmet";
import { Separator } from "@/components/ui/separator";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { QuoteRequestForm } from "@/components/QuoteRequestForm";
import { Button } from "@/components/ui/button";
import { Database, CreditCard, Store, School, ChartBar, BarChart } from "lucide-react";

export default function SoftwareDevelopment() {
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Custom Software Development | Web Expert Solutions</title>
        <meta 
          name="description" 
          content="Specialized custom software development services including POS systems, microfinance software, and school management systems. Tailored solutions for your business needs." 
        />
        <meta property="og:title" content="Custom Software Development | Web Expert Solutions" />
        <meta 
          property="og:description" 
          content="Specialized custom software development services including POS systems, microfinance software, and school management systems. Tailored solutions for your business needs." 
        />
        <meta property="og:type" content="website" />
      </Helmet>

      <Header />

      <main className="flex-grow">
        <section className="bg-gradient-to-b from-slate-50 to-white py-12 md:py-24">
          <div className="container px-4 mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Custom Software Development</h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-12">
              We develop specialized software solutions including POS systems, microfinance software, and 
              school management systems tailored to your specific business requirements.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <Button size="lg" asChild>
                <a href="#contact-us">Request a Quote</a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#solutions">Explore Solutions</a>
              </Button>
            </div>
          </div>
        </section>

        <section id="solutions" className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Our Specialized Software Solutions</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                We develop custom software applications that solve specific business challenges and optimize your operations.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
              <div className="bg-slate-50 p-8 rounded-lg">
                <Store className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Point of Sale (POS) Systems</h3>
                <p className="text-muted-foreground mb-4">
                  Streamlined POS solutions for retail, restaurants, and service businesses with inventory management, sales tracking, and customer management.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Inventory management</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Sales and payment processing</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Customer management</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Reporting and analytics</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <CreditCard className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Microfinance Software</h3>
                <p className="text-muted-foreground mb-4">
                  Complete management systems for microfinance institutions with loan processing, client management, and financial reporting.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Loan origination and management</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Client portfolio tracking</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Risk assessment tools</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Financial reporting and compliance</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <School className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">School Management Systems</h3>
                <p className="text-muted-foreground mb-4">
                  Comprehensive solutions for educational institutions to manage students, staff, curriculum, and administrative tasks.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Student information management</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Attendance tracking</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Gradebook and assessment tools</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Fee management and reporting</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Database className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Custom Database Solutions</h3>
                <p className="text-muted-foreground mb-4">
                  Tailored database applications for efficient data management, analysis, and reporting across your organization.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Data migration and integration</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Secure data storage and access</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Custom query tools</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Automated backup solutions</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <ChartBar className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Business Intelligence Tools</h3>
                <p className="text-muted-foreground mb-4">
                  Data analysis and visualization solutions to help you make informed business decisions based on your data.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Custom dashboards and reporting</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Data visualization tools</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Trend analysis and forecasting</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>KPI tracking and alerts</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <BarChart className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Integration Solutions</h3>
                <p className="text-muted-foreground mb-4">
                  Connect your existing systems and software to create a unified workflow across your business operations.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>API development and integration</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Third-party system connections</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Data synchronization</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                    <span>Workflow automation</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <Separator />

        <section className="py-16 bg-slate-50">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Our Development Process</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                We follow a systematic and collaborative approach to custom software development.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <div className="bg-primary/10 text-primary h-16 w-16 rounded-full flex items-center justify-center font-bold text-2xl mb-6">1</div>
                <h3 className="text-xl font-semibold mb-3">Requirements Analysis</h3>
                <p className="text-muted-foreground">
                  We work closely with you to understand your business processes, challenges, and goals to define clear software requirements.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <div className="bg-primary/10 text-primary h-16 w-16 rounded-full flex items-center justify-center font-bold text-2xl mb-6">2</div>
                <h3 className="text-xl font-semibold mb-3">Design & Architecture</h3>
                <p className="text-muted-foreground">
                  Our team creates a comprehensive system design and architecture to ensure scalability, security, and performance.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <div className="bg-primary/10 text-primary h-16 w-16 rounded-full flex items-center justify-center font-bold text-2xl mb-6">3</div>
                <h3 className="text-xl font-semibold mb-3">Development</h3>
                <p className="text-muted-foreground">
                  We build your software using industry best practices and modern development methodologies with regular client feedback.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <div className="bg-primary/10 text-primary h-16 w-16 rounded-full flex items-center justify-center font-bold text-2xl mb-6">4</div>
                <h3 className="text-xl font-semibold mb-3">Testing & QA</h3>
                <p className="text-muted-foreground">
                  Rigorous testing and quality assurance to ensure your software is reliable, secure, and bug-free before deployment.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <div className="bg-primary/10 text-primary h-16 w-16 rounded-full flex items-center justify-center font-bold text-2xl mb-6">5</div>
                <h3 className="text-xl font-semibold mb-3">Deployment</h3>
                <p className="text-muted-foreground">
                  Smooth implementation of your software solution with data migration, user training, and documentation.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <div className="bg-primary/10 text-primary h-16 w-16 rounded-full flex items-center justify-center font-bold text-2xl mb-6">6</div>
                <h3 className="text-xl font-semibold mb-3">Support & Maintenance</h3>
                <p className="text-muted-foreground">
                  Ongoing technical support, updates, and enhancements to ensure your software continues to meet your evolving business needs.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold mb-6">Why Choose Us for Custom Software?</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  We deliver custom software solutions that address your specific business challenges and drive operational efficiency.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Tailored solutions designed for your specific business needs</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Experienced development team with industry-specific knowledge</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Focus on user experience and intuitive interface design</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Scalable solutions that grow with your business</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p>Comprehensive post-launch support and maintenance</p>
                  </div>
                </div>
              </div>
              <div id="contact-us">
                <QuoteRequestForm serviceType="software" />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}