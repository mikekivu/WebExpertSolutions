import { Helmet } from "react-helmet";
import { Separator } from "@/components/ui/separator";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { QuoteRequestForm } from "@/components/QuoteRequestForm";
import { Button } from "@/components/ui/button";
import { MessageSquare, Users, BarChart3, Clock, CheckCircle, Calendar } from "lucide-react";

export default function BulkSMS() {
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Bulk SMS Services | Web Expert Solutions</title>
        <meta 
          name="description" 
          content="Reach your customers instantly with our reliable and affordable bulk SMS services. Perfect for businesses, organizations, and institutions to send mass text messages." 
        />
        <meta property="og:title" content="Bulk SMS Services | Web Expert Solutions" />
        <meta 
          property="og:description" 
          content="Reach your customers instantly with our reliable and affordable bulk SMS services. Perfect for businesses, organizations, and institutions to send mass text messages." 
        />
        <meta property="og:type" content="website" />
      </Helmet>

      <Header />

      <main className="flex-grow">
        <section className="bg-gradient-to-b from-slate-50 to-white py-12 md:py-24">
          <div className="container px-4 mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Bulk SMS Services</h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-12">
              Connect with your audience instantly through our reliable and affordable bulk SMS services. 
              Perfect for businesses, organizations, and institutions looking to reach customers effectively.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <Button size="lg" asChild>
                <a href="#pricing">View Pricing</a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#contact-us">Get Started</a>
              </Button>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Why Choose Our Bulk SMS Service?</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                We provide a reliable, cost-effective SMS solution with high delivery rates and powerful features.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
              <div className="bg-slate-50 p-8 rounded-lg">
                <CheckCircle className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Guaranteed Delivery</h3>
                <p className="text-muted-foreground">
                  High delivery rates with multiple gateway options to ensure your messages reach your audience reliably.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Clock className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Instant Delivery</h3>
                <p className="text-muted-foreground">
                  Send messages immediately or schedule them for later, reaching your audience at the optimal time.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Users className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Group Management</h3>
                <p className="text-muted-foreground">
                  Organize your contacts into groups for targeted messaging and efficient campaign management.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <BarChart3 className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Detailed Reports</h3>
                <p className="text-muted-foreground">
                  Track message delivery status, open rates, and engagement with comprehensive analytics.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <Calendar className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Scheduled Messaging</h3>
                <p className="text-muted-foreground">
                  Plan your SMS campaigns in advance and schedule messages for future delivery at specific times.
                </p>
              </div>
              
              <div className="bg-slate-50 p-8 rounded-lg">
                <MessageSquare className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-3">Personalization</h3>
                <p className="text-muted-foreground">
                  Create customized messages with recipient names and personalized content for higher engagement.
                </p>
              </div>
            </div>
          </div>
        </section>

        <Separator />

        <section id="pricing" className="py-16 bg-slate-50">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Simple, Transparent Pricing</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                Affordable SMS packages with volume-based discounts. No hidden fees or long-term contracts.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
              <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold">Basic Package</h3>
                  <div className="mt-4 mb-2">
                    <span className="text-4xl font-bold">Ksh 0.80</span>
                    <span className="text-muted-foreground"> / SMS</span>
                  </div>
                  <p className="text-sm text-muted-foreground">1,000 - 9,999 SMS</p>
                </div>
                <ul className="space-y-3 flex-grow mb-6">
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Web-based SMS platform</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Delivery reports</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Basic contact management</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>30-day message history</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full" asChild>
                  <a href="#contact-us">Get Started</a>
                </Button>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-md flex flex-col relative border-2 border-primary">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-primary text-white px-4 py-1 rounded-full text-sm font-medium">
                  Most Popular
                </div>
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold">Standard Package</h3>
                  <div className="mt-4 mb-2">
                    <span className="text-4xl font-bold">Ksh 0.65</span>
                    <span className="text-muted-foreground"> / SMS</span>
                  </div>
                  <p className="text-sm text-muted-foreground">10,000 - 49,999 SMS</p>
                </div>
                <ul className="space-y-3 flex-grow mb-6">
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Advanced web dashboard</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Detailed analytics</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Group messaging</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Message scheduling</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>90-day message history</span>
                  </li>
                </ul>
                <Button className="w-full" asChild>
                  <a href="#contact-us">Get Started</a>
                </Button>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold">Enterprise Package</h3>
                  <div className="mt-4 mb-2">
                    <span className="text-4xl font-bold">Ksh 0.50</span>
                    <span className="text-muted-foreground"> / SMS</span>
                  </div>
                  <p className="text-sm text-muted-foreground">50,000+ SMS</p>
                </div>
                <ul className="space-y-3 flex-grow mb-6">
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Premium dashboard access</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Priority delivery</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>API integration</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Advanced personalization</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Dedicated account manager</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>1-year message history</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full" asChild>
                  <a href="#contact-us">Get Started</a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold mb-6">Perfect For All Industries</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  Our Bulk SMS service is used by businesses, organizations, and institutions across various sectors
                  to effectively communicate with their audiences.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">Retail & E-commerce</h3>
                    <p className="text-sm text-muted-foreground">
                      Send promotional offers, order updates, and delivery notifications.
                    </p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">Financial Services</h3>
                    <p className="text-sm text-muted-foreground">
                      Send transaction alerts, payment reminders, and security notifications.
                    </p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">Education</h3>
                    <p className="text-sm text-muted-foreground">
                      Notify parents about events, attendance, and emergency information.
                    </p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">Healthcare</h3>
                    <p className="text-sm text-muted-foreground">
                      Send appointment reminders, medication alerts, and health tips.
                    </p>
                  </div>
                </div>
                <p className="text-muted-foreground">
                  Need a custom solution for your industry? Contact us to discuss your specific requirements.
                </p>
              </div>
              <div id="contact-us">
                <QuoteRequestForm serviceType="bulk-sms" />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}