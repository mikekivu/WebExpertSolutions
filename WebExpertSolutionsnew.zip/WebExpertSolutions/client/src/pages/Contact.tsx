import { useQuery } from "@tanstack/react-query";
import { Phone, Mail, MapPin } from "lucide-react";
import { Helmet } from "react-helmet";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { 
  Card, 
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { AnimatedContactForm } from "@/components/AnimatedContactForm";
import type { ContactInfo } from "@shared/schema";

export default function Contact() {
  const { data: contactInfo, isLoading } = useQuery<ContactInfo>({
    queryKey: ['/api/contact'],
  });

  return (
    <>
      <Helmet>
        <title>Contact Us - Web Expert Solutions</title>
        <meta name="description" content="Get in touch with Web Expert Solutions for website development, mobile apps, hosting, and more. We're here to answer your questions and help with your project." />
      </Helmet>
      
      <div className="flex flex-col min-h-screen">
        <Header />
        
        <main className="flex-grow">
          <div className="container mx-auto py-10 px-4 md:px-6">
            <div className="text-center mb-10">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Contact Us</h1>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Have a question or need assistance with a project? Reach out to us. Our team is ready to help you with your website development, mobile app, or any other digital needs.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              {!isLoading && contactInfo && (
                <>
                  <Card className="text-center shadow-md hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-2">
                        <Phone className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle>Call Us</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="mb-2">{contactInfo.phoneNumber1}</p>
                      {contactInfo.phoneNumber2 && (
                        <p>{contactInfo.phoneNumber2}</p>
                      )}
                    </CardContent>
                  </Card>

                  <Card className="text-center shadow-md hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-2">
                        <Mail className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle>Email Us</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>{contactInfo.email}</p>
                    </CardContent>
                  </Card>

                  <Card className="text-center shadow-md hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-2">
                        <MapPin className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle>Visit Us</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>{contactInfo.location}</p>
                      {contactInfo.googleMapLink && (
                        <a
                          href={contactInfo.googleMapLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary hover:underline mt-2 inline-block"
                        >
                          View on Google Maps
                        </a>
                      )}
                    </CardContent>
                  </Card>
                </>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h2 className="text-2xl font-bold mb-6">Send us a Message</h2>
                <AnimatedContactForm />
              </div>
              
              <div className="bg-muted rounded-lg overflow-hidden h-[400px] md:h-auto">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63920.028976920436!2d36.80901174863279!3d-1.2833006!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f10893d9bd399%3A0xca9de1ef8432cbc6!2sCBD%2C%20Nairobi!5e0!3m2!1sen!2ske!4v1716151570574!5m2!1sen!2ske" 
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  allowFullScreen={false} 
                  loading="lazy" 
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Web Expert Solutions Location"
                />
              </div>
            </div>
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}