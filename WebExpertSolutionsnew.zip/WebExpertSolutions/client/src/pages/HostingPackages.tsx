import { Helmet } from "react-helmet";
import { HostingPackages as HostingPackagesComponent } from "@/components/HostingPackages";
import { Separator } from "@/components/ui/separator";
import { HeroSection } from "@/components/HeroSection";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export default function HostingPackages() {
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Hosting Packages | Web Expert Solutions</title>
        <meta name="description" content="Choose from our range of reliable, high-performance web hosting packages. From personal blogs to enterprise solutions, we have the perfect hosting plan for your needs." />
        <meta property="og:title" content="Hosting Packages | Web Expert Solutions" />
        <meta property="og:description" content="Choose from our range of reliable, high-performance web hosting packages. From personal blogs to enterprise solutions, we have the perfect hosting plan for your needs." />
        <meta property="og:type" content="website" />
      </Helmet>

      <Header />

      <main className="flex-grow">
        <HeroSection
          title="Web Hosting Packages"
          description="Choose from our range of reliable, high-performance web hosting packages. From personal blogs to enterprise solutions, we have the perfect hosting plan for your needs."
          imagePath="/images/hosting-banner.jpg"
        />

        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto">
            <HostingPackagesComponent />
          </div>
        </section>

        <Separator />

        <section className="py-16 bg-muted/50">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight">Why Choose Our Hosting?</h2>
              <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
                We provide reliable, high-performance hosting solutions backed by 24/7 support and industry-leading uptime guarantees.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-3">99.9% Uptime Guarantee</h3>
                <p className="text-muted-foreground">
                  We ensure your website stays online with our industry-leading uptime guarantee.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-3">24/7 Expert Support</h3>
                <p className="text-muted-foreground">
                  Our technical team is available round the clock to solve any issues that may arise.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-3">High-Speed Servers</h3>
                <p className="text-muted-foreground">
                  Experience lightning-fast load times with our optimized server infrastructure.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-3">Daily Backups</h3>
                <p className="text-muted-foreground">
                  Your data is safe with daily automated backups for all our hosting plans.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-3">Free SSL Certificates</h3>
                <p className="text-muted-foreground">
                  Enhance security and SEO with free SSL certificates included with all hosting packages.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-3">Easy Scalability</h3>
                <p className="text-muted-foreground">
                  Upgrade or downgrade your plan easily as your business needs change.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container px-4 mx-auto text-center">
            <h2 className="text-3xl font-bold tracking-tight mb-6">Ready to Get Started?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Choose the perfect hosting plan for your website and experience the difference.
            </p>
            <div className="flex justify-center gap-4">
              <a href="#contact" className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
                Contact Us
              </a>
              <a href="#packages" className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2">
                View Packages
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}