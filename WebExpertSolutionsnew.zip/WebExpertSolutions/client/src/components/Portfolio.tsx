import { useQuery } from "@tanstack/react-query";
import { PortfolioItem } from "@/components/PortfolioItem";
import { Button } from "@/components/ui/button";

export interface PortfolioItemType {
  id: number;
  title: string;
  description: string;
  category: string;
  imageUrl: string;
  tags: string[];
  projectUrl?: string;
  featured: boolean;
}

export function Portfolio() {
  // Fetch portfolio items from the API
  const { data: portfolioItems = [], isLoading } = useQuery<PortfolioItemType[]>({
    queryKey: ["/api/portfolio"],
  });

  return (
    <section id="portfolio" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-gray-800 font-inter">Our Recent Work</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Check out some of our recent projects delivered to satisfied clients
          </p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <div key={item} className="rounded-lg overflow-hidden shadow-md bg-white h-80 animate-pulse">
                <div className="w-full h-64 bg-gray-300"></div>
                <div className="p-6">
                  <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-full mb-3"></div>
                  <div className="flex flex-wrap gap-2">
                    <div className="h-3 bg-blue-100 rounded-full w-16"></div>
                    <div className="h-3 bg-blue-100 rounded-full w-20"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {portfolioItems.map((item) => (
              <PortfolioItem key={item.id} item={item} />
            ))}
          </div>
        )}

        <div className="text-center mt-12">
          <Button asChild className="inline-block px-6 py-3 bg-primary hover:bg-blue-700 text-white font-medium rounded-md transition-colors">
            <a href="/portfolio">View All Projects</a>
          </Button>
        </div>
      </div>
    </section>
  );
}
