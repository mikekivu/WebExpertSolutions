import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { QuoteRequestForm } from "@/components/QuoteRequestForm";

// Define the WebPackage type matching the schema
export interface WebPackage {
  id: number;
  name: string;
  description: string;
  priceRange: string;
  pagesCount: string;
  deliveryTime: string;
  supportPeriod: string;
  features: {
    name: string;
    included: boolean;
  }[];
  featured: boolean;
  popular: boolean;
  createdAt: string;
}

export function WebPackages() {
  const [selectedPackage, setSelectedPackage] = useState<WebPackage | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Fetch all web packages
  const { data: packages, isLoading, error } = useQuery({
    queryKey: ["/api/web-packages"],
  });

  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em]"></div>
        <p className="mt-4 text-lg">Loading packages...</p>
      </div>
    );
  }

  if (error || !packages || packages.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-muted-foreground">
          No packages found. Please check back later.
        </p>
      </div>
    );
  }

  const handleQuoteRequest = (pkg: WebPackage) => {
    setSelectedPackage(pkg);
    setIsDialogOpen(true);
  };

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {packages.map((pkg: WebPackage) => (
          <Card key={pkg.id} className={`relative overflow-hidden ${pkg.popular ? 'border-primary border-2' : ''}`}>
            {pkg.popular && (
              <div className="absolute top-0 right-0">
                <Badge variant="default" className="rounded-bl-lg rounded-tr-lg rounded-br-none rounded-tl-none">
                  Most Popular
                </Badge>
              </div>
            )}
            {pkg.featured && (
              <div className="absolute top-0 left-0">
                <Badge variant="secondary" className="rounded-br-lg rounded-tl-lg rounded-bl-none rounded-tr-none">
                  Featured
                </Badge>
              </div>
            )}
            
            <CardHeader>
              <CardTitle className="text-xl">{pkg.name}</CardTitle>
              <CardDescription>{pkg.description}</CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="text-center">
                <p className="text-3xl font-bold">{pkg.priceRange}</p>
                <p className="text-sm text-muted-foreground mt-1">Starting price</p>
              </div>
              
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path>
                    </svg>
                    <span>{pkg.pagesCount}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="12" cy="12" r="10"></circle>
                      <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                    <span>{pkg.deliveryTime}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.85.83 6.72 2.25"></path>
                    <path d="M21 3v7h-7"></path>
                  </svg>
                  <span>{pkg.supportPeriod}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="font-medium">Features:</p>
                <ul className="space-y-2">
                  {pkg.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      {feature.included ? (
                        <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      ) : (
                        <X className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                      )}
                      <span className={feature.included ? "" : "text-muted-foreground"}>
                        {feature.name}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
            
            <CardFooter>
              <Button 
                className="w-full"
                size="lg"
                onClick={() => handleQuoteRequest(pkg)}
              >
                Request Quote
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Request Quote for {selectedPackage?.name}</DialogTitle>
            <DialogDescription>
              Fill out the form below to request a quote for the {selectedPackage?.name} package.
            </DialogDescription>
          </DialogHeader>
          
          <QuoteRequestForm serviceType="website" />
        </DialogContent>
      </Dialog>
    </div>
  );
}