import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { 
  LayoutDashboard, 
  Package, 
  FileText, 
  CreditCard, 
  HelpCircle, 
  Settings, 
  LogOut, 
  User, 
  Menu,
  ChevronDown,
  Bell,
  Globe
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { trackEvent } from "@/lib/analytics";

interface SidebarLinkProps {
  icon: React.ReactNode;
  label: string;
  href: string;
  isActive: boolean;
  badge?: number;
  onClick?: () => void;
}

const SidebarLink = ({ icon, label, href, isActive, badge, onClick }: SidebarLinkProps) => {
  return (
    <Link href={href}>
      <a 
        className={cn(
          "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors",
          isActive 
            ? "bg-primary text-primary-foreground" 
            : "text-gray-700 hover:bg-gray-100 hover:text-gray-900"
        )}
        onClick={onClick}
      >
        {icon}
        <span className="flex-grow">{label}</span>
        {badge && (
          <span className="bg-primary text-primary-foreground px-2 py-0.5 rounded-full text-xs font-medium">
            {badge}
          </span>
        )}
      </a>
    </Link>
  );
};

interface ClientLayoutProps {
  children: React.ReactNode;
}

export function ClientLayout({ children }: ClientLayoutProps) {
  const [location] = useLocation();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Fetch user information
  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  // Close mobile sidebar when route changes
  useEffect(() => {
    setIsMobileSidebarOpen(false);
  }, [location]);

  // Track client portal page views
  useEffect(() => {
    trackEvent(
      'client_portal_view',
      'engagement',
      `client_page_${location.replace('/client/', '')}`
    );
  }, [location]);

  const handleLogout = () => {
    trackEvent('user_logout', 'authentication', 'client_logout');
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <div className="flex-grow flex">
        {/* Mobile sidebar toggle */}
        <div className="md:hidden p-4 fixed bottom-6 right-6 z-50">
          <Button 
            className="w-12 h-12 rounded-full shadow-lg"
            onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
          >
            <Menu />
          </Button>
        </div>
        
        {/* Sidebar - Mobile version with overlay */}
        {isMobileSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-40 md:hidden"
            onClick={() => setIsMobileSidebarOpen(false)}
          />
        )}
        
        {/* Sidebar content */}
        <div 
          className={cn(
            "fixed left-0 top-0 bottom-0 z-50 w-64 bg-white border-r shadow-sm pt-20 transition-transform duration-300 md:translate-x-0 flex flex-col",
            isMobileSidebarOpen ? "translate-x-0" : "-translate-x-full",
            "md:relative md:z-0 md:pt-0"
          )}
        >
          {/* User info */}
          <div className="p-4 border-b">
            <div className="flex items-start gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src="/placeholder-avatar.jpg" alt="User avatar" />
                <AvatarFallback>
                  {user?.firstName?.charAt(0) || user?.username?.charAt(0) || 'U'}
                </AvatarFallback>
              </Avatar>
              <div className="flex-grow overflow-hidden">
                <p className="font-medium truncate">
                  {user?.firstName && user?.lastName 
                    ? `${user.firstName} ${user.lastName}` 
                    : user?.username || 'Client'}
                </p>
                <p className="text-sm text-gray-500 truncate">
                  {user?.email || ''}
                </p>
              </div>
            </div>
          </div>
          
          {/* Sidebar links */}
          <div className="flex-grow overflow-auto p-3 space-y-1.5">
            <SidebarLink 
              icon={<LayoutDashboard className="h-5 w-5" />} 
              label="Dashboard" 
              href="/client/dashboard" 
              isActive={location === "/client/dashboard"} 
            />
            <SidebarLink 
              icon={<Package className="h-5 w-5" />} 
              label="My Services" 
              href="/client/services" 
              isActive={location === "/client/services"}
            />
            <SidebarLink 
              icon={<Globe className="h-5 w-5" />} 
              label="My Domains" 
              href="/client/domains" 
              isActive={location === "/client/domains"}
            />
            <SidebarLink 
              icon={<FileText className="h-5 w-5" />} 
              label="Quotes" 
              href="/client/quotes" 
              isActive={location === "/client/quotes"}
            />
            <SidebarLink 
              icon={<CreditCard className="h-5 w-5" />} 
              label="Invoices" 
              href="/client/invoices" 
              isActive={location === "/client/invoices"}
            />
            <SidebarLink 
              icon={<HelpCircle className="h-5 w-5" />} 
              label="Support" 
              href="/client/support" 
              isActive={location === "/client/support"}
            />
            <SidebarLink 
              icon={<Settings className="h-5 w-5" />} 
              label="Account Settings" 
              href="/client/settings" 
              isActive={location === "/client/settings"}
            />
          </div>
          
          {/* Logout button */}
          <div className="p-3 border-t">
            <Link href="/api/logout">
              <a 
                className="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors text-red-600 hover:bg-red-50"
                onClick={handleLogout}
              >
                <LogOut className="h-5 w-5" />
                <span>Logout</span>
              </a>
            </Link>
          </div>
        </div>
        
        {/* Main content */}
        <div className="flex-grow w-full md:ml-64">
          <main className="min-h-screen bg-gray-50">
            {children}
          </main>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}