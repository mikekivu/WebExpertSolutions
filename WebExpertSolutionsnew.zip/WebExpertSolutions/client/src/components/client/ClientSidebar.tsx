import { Link, useLocation } from "wouter";
import {
  CreditCard,
  FileText,
  Home,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Server,
  Settings,
  ShoppingCart,
  UserCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";

interface SidebarItemProps {
  icon: React.ReactNode;
  text: string;
  href: string;
  isExpanded: boolean;
  isActive: boolean;
  badge?: number;
}

function SidebarItem({ icon, text, href, isExpanded, isActive, badge }: SidebarItemProps) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Link href={href}>
            <Button
              variant="ghost"
              size={isExpanded ? "default" : "icon"}
              className={cn(
                "w-full justify-start",
                isActive && "bg-accent text-accent-foreground"
              )}
            >
              {icon}
              {isExpanded && <span className="ml-2">{text}</span>}
              {badge !== undefined && badge > 0 && (
                <span className={cn(
                  "ml-auto",
                  isExpanded ? "rounded-full bg-primary px-2 py-0.5 text-xs font-medium text-primary-foreground" : "absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground"
                )}>
                  {badge}
                </span>
              )}
            </Button>
          </Link>
        </TooltipTrigger>
        {!isExpanded && <TooltipContent side="right">{text}</TooltipContent>}
      </Tooltip>
    </TooltipProvider>
  );
}

interface ClientSidebarProps {
  isExpanded: boolean;
  toggleExpanded: () => void;
}

export function ClientSidebar({ isExpanded, toggleExpanded }: ClientSidebarProps) {
  const [location] = useLocation();
  
  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout");
      window.location.href = "/";
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "Could not log out. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className={cn(
      "bg-sidebar h-screen flex flex-col border-r transition-all duration-300 overflow-hidden",
      isExpanded ? "w-56" : "w-14"
    )}>
      <div className="p-4 mb-2 flex justify-between items-center">
        {isExpanded && (
          <span className="text-lg font-semibold whitespace-nowrap">Client Portal</span>
        )}
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleExpanded}
          className={cn("ml-auto", !isExpanded && "mx-auto")}
        >
          {isExpanded ? (
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-left"><path d="m15 18-6-6 6-6"/></svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg>
          )}
        </Button>
      </div>
      
      <div className="flex-1 flex flex-col gap-1 px-2 overflow-y-auto">
        <SidebarItem
          icon={<Home className="h-5 w-5" />}
          text="Home"
          href="/"
          isExpanded={isExpanded}
          isActive={location === "/"}
        />
        
        <SidebarItem
          icon={<LayoutDashboard className="h-5 w-5" />}
          text="Dashboard"
          href="/client/dashboard"
          isExpanded={isExpanded}
          isActive={location === "/client/dashboard"}
        />
        
        <SidebarItem
          icon={<Server className="h-5 w-5" />}
          text="My Services"
          href="/client/services"
          isExpanded={isExpanded}
          isActive={location === "/client/services"}
        />
        
        <SidebarItem
          icon={<CreditCard className="h-5 w-5" />}
          text="Invoices"
          href="/client/invoices"
          isExpanded={isExpanded}
          isActive={location === "/client/invoices"}
          badge={2}
        />
        
        <SidebarItem
          icon={<ShoppingCart className="h-5 w-5" />}
          text="Order Services"
          href="/#services"
          isExpanded={isExpanded}
          isActive={false}
        />
        
        <SidebarItem
          icon={<MessageSquare className="h-5 w-5" />}
          text="Support"
          href="/client/support"
          isExpanded={isExpanded}
          isActive={location === "/client/support"}
        />
      </div>
      
      <div className="mt-auto px-2 mb-2">
        <div className="border-t my-2"></div>
        <SidebarItem
          icon={<UserCircle className="h-5 w-5" />}
          text="Profile"
          href="/client/profile"
          isExpanded={isExpanded}
          isActive={location === "/client/profile"}
        />
        
        <SidebarItem
          icon={<Settings className="h-5 w-5" />}
          text="Settings"
          href="/client/settings"
          isExpanded={isExpanded}
          isActive={location === "/client/settings"}
        />
        
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size={isExpanded ? "default" : "icon"}
                className="w-full justify-start mt-1 text-red-500 hover:text-red-500 hover:bg-red-100"
                onClick={handleLogout}
              >
                <LogOut className="h-5 w-5" />
                {isExpanded && <span className="ml-2">Logout</span>}
              </Button>
            </TooltipTrigger>
            {!isExpanded && <TooltipContent side="right">Logout</TooltipContent>}
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  );
}
