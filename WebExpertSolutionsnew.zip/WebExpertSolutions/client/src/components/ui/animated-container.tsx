import React, { ReactNode, useRef, useEffect, useState } from "react";
import { cn } from "@/lib/utils";

interface AnimatedContainerProps {
  children: ReactNode;
  className?: string;
  animation?: "fadeIn" | "slideUp" | "slideRight" | "pulse" | "none";
  delay?: number;
  duration?: number;
  threshold?: number;
  once?: boolean;
}

export function AnimatedContainer({
  children,
  className,
  animation = "fadeIn",
  delay = 0,
  duration = 500,
  threshold = 0.1,
  once = true,
}: AnimatedContainerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          if (once && containerRef.current) {
            observer.unobserve(containerRef.current);
          }
        } else if (!once) {
          setIsVisible(false);
        }
      },
      { threshold }
    );
    
    if (containerRef.current) {
      observer.observe(containerRef.current);
    }
    
    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current);
      }
    };
  }, [once, threshold]);
  
  // Define animation styles
  const getAnimationStyle = () => {
    const baseStyle = {
      opacity: isVisible ? 1 : 0,
      transition: `all ${duration}ms ease-out ${delay}ms`,
    };
    
    switch (animation) {
      case "fadeIn":
        return baseStyle;
      case "slideUp":
        return {
          ...baseStyle,
          transform: isVisible ? "translateY(0)" : "translateY(20px)",
        };
      case "slideRight":
        return {
          ...baseStyle,
          transform: isVisible ? "translateX(0)" : "translateX(-20px)",
        };
      case "pulse":
        return {
          ...baseStyle,
          transform: isVisible ? "scale(1)" : "scale(0.95)",
        };
      case "none":
        return {};
      default:
        return baseStyle;
    }
  };
  
  return (
    <div
      ref={containerRef}
      className={cn(className)}
      style={getAnimationStyle()}
    >
      {children}
    </div>
  );
}