import { useState, useEffect } from "react";
import { FieldErrors, FieldValues, UseFormReturn, useFormState } from "react-hook-form";
import { Check, AlertCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { FormControl, FormItem } from "@/components/ui/form";
import { cn } from "@/lib/utils";

interface FormValidationIndicatorProps {
  control: UseFormReturn<any, any, undefined>["control"];
  name: string;
}

export function FormValidationIndicator({ control, name }: FormValidationIndicatorProps) {
  const { errors, touchedFields, dirtyFields } = useFormState({ control });
  const [showValidation, setShowValidation] = useState(false);
  
  useEffect(() => {
    // Only show validation after field has been touched/dirty
    if (touchedFields[name] || dirtyFields[name]) {
      setShowValidation(true);
    }
  }, [touchedFields, dirtyFields, name]);
  
  if (!showValidation) return null;
  
  const fieldError = getNestedError(errors, name);
  
  return (
    <div className="absolute right-3 top-8 flex items-center">
      {fieldError ? (
        <AlertCircle className="h-4 w-4 text-destructive animate-pulse" />
      ) : (
        <Check className="h-4 w-4 text-green-500 animate-fadeIn" />
      )}
    </div>
  );
}

// Integrated input component with validation indicator
interface FormInputWithValidationProps {
  control: any;
  name: string;
  placeholder?: string;
  type?: string;
  className?: string;
  showOnlyWhenTouched?: boolean;
  showOnlyWhenInvalid?: boolean;
  showMessage?: boolean;
  value?: string;
  onChange?: (...event: any[]) => void;
  onBlur?: (...event: any[]) => void;
}

export function FormInputWithValidation({
  control,
  name,
  placeholder,
  type = "text",
  className,
  showOnlyWhenTouched = true,
  showOnlyWhenInvalid = false,
  showMessage = true,
  value,
  onChange,
  onBlur,
  ...props
}: FormInputWithValidationProps) {
  return (
    <div className="relative">
      <FormControl>
        <Input
          type={type}
          placeholder={placeholder}
          className={cn("pr-10", className)}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          {...props}
        />
      </FormControl>
      <FormValidationIndicator 
        control={control} 
        name={name} 
      />
    </div>
  );
}

// Helper function to get nested errors 
// (e.g. for fields like 'features.0.name')
function getNestedError(errors: FieldErrors<FieldValues>, path: string): any {
  const parts = path.split('.');
  let current: any = errors;
  
  for (const part of parts) {
    if (!current[part]) return null;
    current = current[part];
  }
  
  return current;
}