import React, { useState, useEffect } from 'react';
import { Check, AlertCircle, X } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { cn } from '@/lib/utils';

type ValidationType = 'success' | 'error' | 'warning' | 'info' | 'loading' | 'none';

interface FormFeedbackProps {
  type?: ValidationType;
  message?: string;
  className?: string;
  animate?: boolean;
  showIcon?: boolean;
  isActive?: boolean;
}

const iconMap = {
  success: <Check className="h-4 w-4" />,
  error: <X className="h-4 w-4" />,
  warning: <AlertCircle className="h-4 w-4" />,
  info: <AlertCircle className="h-4 w-4" />,
  loading: (
    <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
  ),
  none: null,
};

const colorMap = {
  success: 'text-green-600 bg-green-50 border-green-200',
  error: 'text-red-600 bg-red-50 border-red-200',
  warning: 'text-amber-600 bg-amber-50 border-amber-200',
  info: 'text-blue-600 bg-blue-50 border-blue-200',
  loading: 'text-gray-600 bg-gray-50 border-gray-200',
  none: 'hidden',
};

export const FormFeedback: React.FC<FormFeedbackProps> = ({
  type = 'none',
  message = '',
  className = '',
  animate = true,
  showIcon = true,
  isActive = true,
}) => {
  // Track when validation type changes to trigger animation
  const [prevType, setPrevType] = useState<ValidationType>(type);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  
  useEffect(() => {
    if (prevType !== type) {
      // Capture that we're changing validation types
      setIsTransitioning(true);
      setPrevType(type);
      
      // Reset transition state after animation completes
      const timer = setTimeout(() => {
        setIsTransitioning(false);
      }, 500);
      
      return () => clearTimeout(timer);
    }
  }, [type, prevType]);

  if (!isActive || type === 'none' || !message) {
    return null;
  }

  const feedbackContainer = (
    <div
      className={cn(
        'px-3 py-1.5 text-sm font-medium rounded-md border flex items-center gap-2 transition-all duration-200',
        colorMap[type],
        isTransitioning ? 'scale-105' : '',
        className
      )}
      role="alert"
    >
      {showIcon && (
        <span className="flex-shrink-0 opacity-85">{iconMap[type]}</span>
      )}
      <span>{message}</span>
    </div>
  );

  if (!animate) {
    return feedbackContainer;
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={type + message}
        initial={{ opacity: 0, y: -10, height: 0 }}
        animate={{ opacity: 1, y: 0, height: 'auto' }}
        exit={{ opacity: 0, y: 10, height: 0 }}
        transition={{ duration: 0.2 }}
      >
        {feedbackContainer}
      </motion.div>
    </AnimatePresence>
  );
};

// Input validation that shows as the user types
export function LiveValidationMessage({
  value,
  validationFn,
  successMessage = 'Looks good!',
  errorMessage = 'Invalid input',
  showSuccess = true
}: {
  value: string;
  validationFn: (value: string) => boolean;
  successMessage?: string;
  errorMessage?: string;
  showSuccess?: boolean;
}) {
  // Don't show anything until user has typed something
  if (!value) return null;

  const isValid = validationFn(value);
  
  return (
    <FormFeedback 
      type={isValid ? 'success' : 'error'} 
      message={isValid ? (showSuccess ? successMessage : '') : errorMessage}
      isActive={!isValid || showSuccess}
    />
  );
}

// Password strength indicator component
export function PasswordStrengthIndicator({ password }: { password: string }) {
  // Calculate password strength
  const getStrength = (pwd: string): number => {
    let score = 0;
    
    // Length check
    if (pwd.length > 6) score += 1;
    if (pwd.length > 10) score += 1;
    
    // Character variety checks
    if (/[A-Z]/.test(pwd)) score += 1;
    if (/[0-9]/.test(pwd)) score += 1;
    if (/[^A-Za-z0-9]/.test(pwd)) score += 1;
    
    return Math.min(score, 5); // Max score is 5
  };
  
  const getStrengthText = (strength: number): string => {
    if (strength === 0) return 'Very weak';
    if (strength === 1) return 'Weak';
    if (strength === 2) return 'Fair';
    if (strength === 3) return 'Good';
    if (strength === 4) return 'Strong';
    return 'Very strong';
  };
  
  const getStrengthColor = (strength: number): string => {
    if (strength < 2) return 'bg-red-500';
    if (strength < 3) return 'bg-amber-500';
    if (strength < 4) return 'bg-yellow-500';
    if (strength === 4) return 'bg-green-500';
    return 'bg-emerald-500';
  };
  
  // Don't show anything if no password entered
  if (!password) return null;
  
  const strength = getStrength(password);
  const text = getStrengthText(strength);
  const color = getStrengthColor(strength);
  const percentage = (strength / 5) * 100;
  
  return (
    <div className="mt-2 space-y-1">
      <div className="flex justify-between text-xs">
        <span>Password strength:</span>
        <span className={
          strength < 2 ? 'text-red-600' : 
          strength < 3 ? 'text-amber-600' : 
          strength < 4 ? 'text-yellow-600' : 
          'text-green-600'
        }>
          {text}
        </span>
      </div>
      <div className="h-1.5 w-full bg-gray-200 rounded-full overflow-hidden">
        <motion.div 
          className={`h-full ${color} rounded-full`}
          initial={{ width: "0%" }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.3 }}
        />
      </div>
    </div>
  );
}

// Field indicator that provides feedback as user types
export function FieldIndicator({
  value,
  rules,
  label,
}: {
  value: string;
  rules: { test: (val: string) => boolean; message: string }[];
  label: string;
}) {
  return (
    <>
      <p className="text-sm font-medium mb-2">{label} requirements:</p>
      <ul className="space-y-1 mb-3">
        {rules.map((rule, index) => {
          const isPassing = rule.test(value);
          
          return (
            <motion.li 
              key={index}
              className="flex items-center gap-2 text-sm"
              animate={{
                opacity: value ? 1 : 0.7,
                color: isPassing ? '#16a34a' : '#6b7280'
              }}
            >
              <span className={cn(
                "flex-shrink-0 w-5 h-5 flex items-center justify-center rounded-full transition-colors",
                isPassing 
                  ? "bg-green-100 text-green-600"
                  : "bg-gray-100 text-gray-400"
              )}>
                <Check className="h-3 w-3" />
              </span>
              <span>{rule.message}</span>
            </motion.li>
          );
        })}
      </ul>
    </>
  );
}

// Animated character counter for text inputs 
export function CharacterCounter({
  value,
  maxLength,
  warningThreshold = 0.8, // Show warning color at 80% by default
}: {
  value: string;
  maxLength: number;
  warningThreshold?: number;
}) {
  const remainingChars = maxLength - value.length;
  const percentage = value.length / maxLength;
  
  return (
    <div className="text-right">
      <motion.p
        className={cn(
          "text-xs transition-colors inline-flex items-center gap-1",
          percentage > warningThreshold 
            ? percentage >= 1 
              ? "text-red-500 font-medium" 
              : "text-amber-500"
            : "text-gray-500"
        )}
        animate={{
          scale: percentage >= 1 ? [1, 1.05, 1] : 1
        }}
        transition={{ duration: 0.3 }}
      >
        {remainingChars < 0 ? (
          <>
            <span className="font-semibold">{Math.abs(remainingChars)}</span> characters over limit
          </>
        ) : (
          <>
            <span className="font-semibold">{remainingChars}</span> characters remaining
          </>
        )}
      </motion.p>
    </div>
  );
}