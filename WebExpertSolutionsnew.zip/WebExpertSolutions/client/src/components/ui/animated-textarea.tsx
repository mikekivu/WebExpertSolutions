import * as React from "react";
import { cn } from "@/lib/utils";
import { useFormField, FormValidationIcon } from "./form-with-animations";
import { motion } from "framer-motion";

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  showValidation?: boolean;
}

const AnimatedTextarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, showValidation = true, ...props }, ref) => {
    const { error, isDirty } = useFormField();
    const isValid = isDirty && !error;
    const hasError = !!error;
    
    // Border animation state
    const borderVariants = {
      idle: { 
        boxShadow: "0 0 0 0 rgba(0, 0, 0, 0)",
        borderColor: "hsl(var(--input))" 
      },
      focus: { 
        boxShadow: "0 0 0 2px rgba(var(--primary-rgb), 0.3)", 
        borderColor: "hsl(var(--primary))" 
      },
      error: { 
        boxShadow: "0 0 0 2px rgba(var(--destructive-rgb), 0.3)",
        borderColor: "hsl(var(--destructive))" 
      },
      valid: { 
        boxShadow: "0 0 0 2px rgba(var(--success-rgb), 0.3)",
        borderColor: "hsl(var(--success))" 
      }
    };

    // Determine initial animation state based on validation status
    const [animationState, setAnimationState] = React.useState(
      hasError ? "error" : isValid ? "valid" : "idle"
    );

    // Update animation state when validation status changes
    React.useEffect(() => {
      if (hasError) setAnimationState("error");
      else if (isValid) setAnimationState("valid");
      else setAnimationState("idle");
    }, [hasError, isValid]);

    return (
      <div className="relative">
        <motion.textarea
          className={cn(
            "flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50 min-h-[120px] resize-y",
            hasError && "border-destructive",
            isValid && isDirty && !hasError && "border-success",
            className
          )}
          ref={ref}
          initial="idle"
          animate={animationState}
          variants={borderVariants}
          transition={{ duration: 0.2 }}
          onFocus={() => setAnimationState(hasError ? "error" : isValid ? "valid" : "focus")}
          onBlur={() => setAnimationState(hasError ? "error" : isValid ? "valid" : "idle")}
          {...props}
        />
        
        {showValidation && (
          <FormValidationIcon 
            isValid={isValid} 
            isDirty={isDirty} 
            isError={hasError}
            className="top-6" 
          />
        )}
      </div>
    );
  }
);

AnimatedTextarea.displayName = "AnimatedTextarea";

export { AnimatedTextarea };