import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface FormSubmitButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  loadingText?: string;
  successText?: string;
  isSubmitting?: boolean;
  isSuccess?: boolean;
  showSuccess?: boolean;
  resetDelay?: number;
  onReset?: () => void;
}

export function FormSubmitButton({
  children,
  className,
  loadingText = "Submitting...",
  successText = "Success!",
  isSubmitting = false,
  isSuccess = false,
  showSuccess = true,
  resetDelay = 2000,
  onReset,
  ...props
}: FormSubmitButtonProps) {
  const [showSuccessState, setShowSuccessState] = useState(false);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    
    if (isSuccess && showSuccess) {
      setShowSuccessState(true);
      
      timer = setTimeout(() => {
        setShowSuccessState(false);
        onReset && onReset();
      }, resetDelay);
    }
    
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [isSuccess, resetDelay, onReset, showSuccess]);

  return (
    <Button
      className={cn("relative", className)}
      disabled={isSubmitting || showSuccessState}
      {...props}
    >
      {isSubmitting && (
        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
      )}
      {showSuccessState && (
        <Check className="mr-2 h-4 w-4 text-green-500" />
      )}
      {isSubmitting ? loadingText : showSuccessState ? successText : children}
    </Button>
  );
}