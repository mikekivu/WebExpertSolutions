import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { trackEvent } from "@/lib/analytics";

export function CallToAction() {
  const handleGetQuoteClick = () => {
    trackEvent(
      'cta_click',
      'conversion',
      'get_free_quote'
    );
  };

  const handleClientLoginClick = () => {
    trackEvent(
      'cta_click',
      'engagement',
      'client_portal_login'
    );
  };

  return (
    <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 font-inter">Ready to Transform Your Business?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Get started with Web Expert Solutions today and take your business to the next level
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/contact/quote" onClick={handleGetQuoteClick}>
              <Button className="px-8 py-4 bg-white text-primary font-bold rounded-md hover:bg-gray-100 transition-colors w-full sm:w-auto">
                Get a Free Quote
              </Button>
            </Link>
            <Link href="/login" onClick={handleClientLoginClick}>
              <Button 
                variant="outline" 
                className="px-8 py-4 bg-transparent border-2 border-white text-white font-bold rounded-md hover:bg-white hover:bg-opacity-10 transition-colors w-full sm:w-auto"
              >
                Login to Client Portal
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
