import { ReactNode, useState } from "react";
import { useLocation } from "wouter";
import { AdminSidebar } from "./AdminSidebar";

interface AdminLayoutProps {
  children: ReactNode;
}

export function AdminLayout({ children }: AdminLayoutProps) {
  const [location] = useLocation();
  const [isExpanded, setIsExpanded] = useState(true);
  
  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  // Redirect to login if not authenticated
  // This is just a placeholder - in a real app, you would check authentication status
  // const { isAuthenticated } = useAuth();
  // if (!isAuthenticated) {
  //   return <Redirect to="/login" />;
  // }

  return (
    <div className="min-h-screen flex">
      <AdminSidebar isExpanded={isExpanded} toggleExpanded={toggleExpanded} />
      <div className={`flex-1 ${isExpanded ? "ml-64" : "ml-16"} p-6 transition-all duration-300`}>
        {children}
      </div>
    </div>
  );
}