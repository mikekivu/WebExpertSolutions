import { Link, useLocation } from "wouter";
import {
  AlertCircle,
  BarChart3,
  Database,
  FileText,
  Home,
  Image,
  LayoutDashboard,
  LogOut,
  Mail,
  Package,
  Settings,
  Users,
  Smartphone,
  Monitor,
  Globe,
  MessageSquare,
  BarChart,
  CreditCard,
  CalendarClock,
  BellRing,
  RefreshCw,
  PhoneCall,
  Info,
  Layout,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";

interface SidebarItemProps {
  icon: React.ReactNode;
  text: string;
  href: string;
  isExpanded: boolean;
  isActive: boolean;
  badge?: number;
}

function SidebarItem({ icon, text, href, isExpanded, isActive, badge }: SidebarItemProps) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Link href={href}>
            <Button
              variant="ghost"
              size={isExpanded ? "default" : "icon"}
              className={cn(
                "w-full justify-start",
                isActive && "bg-accent text-accent-foreground"
              )}
            >
              {icon}
              {isExpanded && <span className="ml-2">{text}</span>}
              {badge !== undefined && badge > 0 && (
                <span className={cn(
                  "ml-auto",
                  isExpanded ? "rounded-full bg-primary px-2 py-0.5 text-xs font-medium text-primary-foreground" : "absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground"
                )}>
                  {badge}
                </span>
              )}
            </Button>
          </Link>
        </TooltipTrigger>
        {!isExpanded && <TooltipContent side="right">{text}</TooltipContent>}
      </Tooltip>
    </TooltipProvider>
  );
}

interface AdminSidebarProps {
  isExpanded: boolean;
  toggleExpanded: () => void;
}

export function AdminSidebar({ isExpanded, toggleExpanded }: AdminSidebarProps) {
  const [location] = useLocation();
  const [previousPendingCount, setPreviousPendingCount] = useState(0);
  const [hasNewRequests, setHasNewRequests] = useState(false);
  
  // Fetch quote requests
  const { data: quoteRequests = [] } = useQuery<any[]>({
    queryKey: ["/api/quote-requests"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });
  
  // Count pending quote requests
  const pendingQuoteRequests = quoteRequests.filter(quote => quote.status === "pending");
  
  // Show notification when new quote requests come in
  useEffect(() => {
    const pendingCount = pendingQuoteRequests.length;
    
    if (pendingCount > previousPendingCount && previousPendingCount !== 0) {
      setHasNewRequests(true);
      toast({
        title: "New Quote Request",
        description: `You have ${pendingCount - previousPendingCount} new quote request${pendingCount - previousPendingCount > 1 ? 's' : ''}.`,
        variant: "default",
        action: (
          <Button 
            variant="default" 
            onClick={() => {
              window.location.href = "/admin/quotes";
              setHasNewRequests(false);
            }}
          >
            View
          </Button>
        ),
      });
    }
    
    setPreviousPendingCount(pendingCount);
  }, [pendingQuoteRequests.length, previousPendingCount]);
  
  // Reset notification indicator when visiting the quotes page
  useEffect(() => {
    if (location === "/admin/quotes") {
      setHasNewRequests(false);
    }
  }, [location]);
  
  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout");
      window.location.href = "/";
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "Could not log out. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className={cn(
      "bg-sidebar h-screen flex flex-col border-r transition-all duration-300 overflow-hidden",
      isExpanded ? "w-56" : "w-14"
    )}>
      <div className="p-4 mb-2 flex justify-between items-center">
        {isExpanded && (
          <span className="text-lg font-semibold whitespace-nowrap">Admin Panel</span>
        )}
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleExpanded}
          className={cn("ml-auto", !isExpanded && "mx-auto")}
        >
          {isExpanded ? (
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-left"><path d="m15 18-6-6 6-6"/></svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg>
          )}
        </Button>
      </div>
      
      <div className="flex-1 flex flex-col gap-1 px-2 overflow-y-auto">
        <SidebarItem
          icon={<Home className="h-5 w-5" />}
          text="Home"
          href="/"
          isExpanded={isExpanded}
          isActive={location === "/"}
        />
        
        <SidebarItem
          icon={<LayoutDashboard className="h-5 w-5" />}
          text="Dashboard"
          href="/admin/dashboard"
          isExpanded={isExpanded}
          isActive={location === "/admin/dashboard"}
        />
        
        <SidebarItem
          icon={<Users className="h-5 w-5" />}
          text="Clients"
          href="/admin/clients"
          isExpanded={isExpanded}
          isActive={location === "/admin/clients"}
        />
        
        <SidebarItem
          icon={<AlertCircle className={cn("h-5 w-5", hasNewRequests ? "text-primary animate-pulse" : "")} />}
          text="Quote Requests"
          href="/admin/quotes"
          isExpanded={isExpanded}
          isActive={location === "/admin/quotes"}
          badge={pendingQuoteRequests.length > 0 ? pendingQuoteRequests.length : undefined}
        />
        
        <SidebarItem
          icon={<FileText className="h-5 w-5" />}
          text="Invoices"
          href="/admin/invoices"
          isExpanded={isExpanded}
          isActive={location === "/admin/invoices"}
        />
        
        <SidebarItem
          icon={<Image className="h-5 w-5" />}
          text="Portfolio"
          href="/admin/portfolio"
          isExpanded={isExpanded}
          isActive={location === "/admin/portfolio"}
        />
        
        <SidebarItem
          icon={<Package className="h-5 w-5" />}
          text="Web Packages"
          href="/admin/web-packages"
          isExpanded={isExpanded}
          isActive={location === "/admin/web-packages"}
        />
        
        <SidebarItem
          icon={<Database className="h-5 w-5" />}
          text="Hosting Packages"
          href="/admin/hosting-packages"
          isExpanded={isExpanded}
          isActive={location === "/admin/hosting-packages"}
        />
        
        <SidebarItem
          icon={<Smartphone className="h-5 w-5" />}
          text="Mobile Apps"
          href="/admin/mobile-apps"
          isExpanded={isExpanded}
          isActive={location === "/admin/mobile-apps"}
        />
        
        <SidebarItem
          icon={<Monitor className="h-5 w-5" />}
          text="Software Solutions"
          href="/admin/software-solutions"
          isExpanded={isExpanded}
          isActive={location === "/admin/software-solutions"}
        />
        
        <SidebarItem
          icon={<Globe className="h-5 w-5" />}
          text="Domain Management"
          href="/admin/domain-management"
          isExpanded={isExpanded}
          isActive={location === "/admin/domain-management"}
        />
        
        <SidebarItem
          icon={<MessageSquare className="h-5 w-5" />}
          text="Bulk SMS"
          href="/admin/bulk-sms"
          isExpanded={isExpanded}
          isActive={location === "/admin/bulk-sms"}
        />
        
        <SidebarItem
          icon={<BarChart className="h-5 w-5" />}
          text="Digital Marketing"
          href="/admin/digital-marketing"
          isExpanded={isExpanded}
          isActive={location === "/admin/digital-marketing"}
        />
        
        <SidebarItem
          icon={<Mail className="h-5 w-5" />}
          text="Email Clients"
          href="/admin/email-clients"
          isExpanded={isExpanded}
          isActive={location === "/admin/email-clients"}
        />
        
        <div className="mt-2 mb-1 px-3">
          <div className="text-xs uppercase text-muted-foreground font-semibold">
            {isExpanded ? "Billing System" : ""}
          </div>
        </div>
        
        <SidebarItem
          icon={<CreditCard className="h-5 w-5" />}
          text="Billing Plans"
          href="/admin/billing-plans"
          isExpanded={isExpanded}
          isActive={location === "/admin/billing-plans"}
        />
        
        <SidebarItem
          icon={<CalendarClock className="h-5 w-5" />}
          text="Recurring Invoices"
          href="/admin/recurring-invoices"
          isExpanded={isExpanded}
          isActive={location === "/admin/recurring-invoices"}
        />
        
        <SidebarItem
          icon={<BellRing className="h-5 w-5" />}
          text="Reminder Templates"
          href="/admin/reminder-templates"
          isExpanded={isExpanded}
          isActive={location === "/admin/reminder-templates"}
        />
        
        <SidebarItem
          icon={<BarChart3 className="h-5 w-5" />}
          text="Analytics"
          href="/admin/analytics"
          isExpanded={isExpanded}
          isActive={location === "/admin/analytics"}
        />
      </div>
      
      <div className="mt-auto px-2 mb-2">
        <div className="border-t my-2"></div>
        <SidebarItem
          icon={<Layout className="h-5 w-5" />}
          text="Content Settings"
          href="/admin/content-settings"
          isExpanded={isExpanded}
          isActive={location === "/admin/content-settings"}
        />
        
        <SidebarItem
          icon={<PhoneCall className="h-5 w-5" />}
          text="Contact Settings"
          href="/admin/contact-settings"
          isExpanded={isExpanded}
          isActive={location === "/admin/contact-settings"}
        />
        
        <SidebarItem
          icon={<Info className="h-5 w-5" />}
          text="About Us Settings"
          href="/admin/about-us-settings"
          isExpanded={isExpanded}
          isActive={location === "/admin/about-us-settings"}
        />
        
        <SidebarItem
          icon={<Settings className="h-5 w-5" />}
          text="Settings"
          href="/admin/settings"
          isExpanded={isExpanded}
          isActive={location === "/admin/settings"}
        />
        
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size={isExpanded ? "default" : "icon"}
                className="w-full justify-start mt-1 text-red-500 hover:text-red-500 hover:bg-red-100"
                onClick={handleLogout}
              >
                <LogOut className="h-5 w-5" />
                {isExpanded && <span className="ml-2">Logout</span>}
              </Button>
            </TooltipTrigger>
            {!isExpanded && <TooltipContent side="right">Logout</TooltipContent>}
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  );
}
