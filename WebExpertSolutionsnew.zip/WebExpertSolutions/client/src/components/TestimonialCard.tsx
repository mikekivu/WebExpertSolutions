interface TestimonialCardProps {
  testimonial: {
    id: number;
    name: string;
    position: string;
    company: string;
    content: string;
    rating: number;
    imageUrl: string;
    isActive: boolean;
  };
}

export function TestimonialCard({ testimonial }: TestimonialCardProps) {
  // Generate stars based on rating
  const renderStars = () => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      if (i <= testimonial.rating) {
        stars.push(<i key={i} className="fas fa-star"></i>);
      } else if (i - 0.5 <= testimonial.rating) {
        stars.push(<i key={i} className="fas fa-star-half-alt"></i>);
      } else {
        stars.push(<i key={i} className="far fa-star"></i>);
      }
    }
    return stars;
  };

  return (
    <div className="bg-gray-50 rounded-lg p-6 shadow-md border border-gray-100">
      <div className="flex items-center mb-4">
        <div className="text-amber-400 flex">
          {renderStars()}
        </div>
      </div>
      <p className="text-gray-600 mb-6 italic">
        "{testimonial.content}"
      </p>
      <div className="flex items-center">
        <div className="w-12 h-12 rounded-full bg-gray-300 overflow-hidden mr-4">
          <img 
            src={testimonial.imageUrl} 
            alt={testimonial.name} 
            className="w-full h-full object-cover"
          />
        </div>
        <div>
          <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
          <p className="text-gray-500 text-sm">{testimonial.position}, {testimonial.company}</p>
        </div>
      </div>
    </div>
  );
}
