import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { QuoteRequestForm } from "@/components/QuoteRequestForm";

// Define the HostingPackage type matching the schema
export interface HostingPackage {
  id: number;
  name: string;
  description: string;
  priceRange: string;
  storageSpace: string;
  bandwidth: string;
  emailAccounts: string;
  supportPeriod: string;
  features: {
    name: string;
    included: boolean;
  }[];
  featured: boolean;
  popular: boolean;
  createdAt: string;
}

export function HostingPackages() {
  const [selectedPackage, setSelectedPackage] = useState<HostingPackage | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Fetch all hosting packages
  const { data: packages, isLoading, error } = useQuery({
    queryKey: ["/api/hosting-packages"],
  });

  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em]"></div>
        <p className="mt-4 text-lg">Loading packages...</p>
      </div>
    );
  }

  if (error || !packages) {
    return (
      <div className="text-center py-12 text-destructive">
        <p>Error loading hosting packages. Please try again later.</p>
      </div>
    );
  }

  const handleRequestQuote = (pkg: HostingPackage) => {
    setSelectedPackage(pkg);
    setIsDialogOpen(true);
  };

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {packages.map((pkg: HostingPackage) => (
          <Card key={pkg.id} className={`relative overflow-hidden ${pkg.popular ? 'border-primary border-2' : ''}`}>
            {pkg.popular && (
              <div className="absolute top-0 right-0">
                <Badge variant="default" className="rounded-bl-lg rounded-tr-lg rounded-br-none rounded-tl-none">
                  Most Popular
                </Badge>
              </div>
            )}
            {pkg.featured && (
              <div className="absolute top-0 left-0">
                <Badge variant="secondary" className="rounded-br-lg rounded-tl-lg rounded-bl-none rounded-tr-none">
                  Featured
                </Badge>
              </div>
            )}
            
            <CardHeader>
              <CardTitle className="text-xl">{pkg.name}</CardTitle>
              <CardDescription>{pkg.description}</CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="text-center">
                <p className="text-3xl font-bold">{pkg.priceRange}</p>
                <p className="text-sm text-muted-foreground mt-1">Starting price</p>
              </div>
              
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Storage:</span>
                  </div>
                  <div>{pkg.storageSpace}</div>
                  
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Bandwidth:</span>
                  </div>
                  <div>{pkg.bandwidth}</div>
                  
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Email Accounts:</span>
                  </div>
                  <div>{pkg.emailAccounts}</div>
                  
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Support:</span>
                  </div>
                  <div>{pkg.supportPeriod}</div>
                </div>
              </div>
              
              <div className="space-y-1">
                <h4 className="text-sm font-medium mb-2">Features:</h4>
                {pkg.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm">
                    {feature.included ? (
                      <Check className="h-4 w-4 text-primary" />
                    ) : (
                      <X className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span className={feature.included ? 'text-foreground' : 'text-muted-foreground'}>
                      {feature.name}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
            
            <CardFooter>
              <Button 
                className="w-full" 
                onClick={() => handleRequestQuote(pkg)}
              >
                Request Quote
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Request a Quote</DialogTitle>
            <DialogDescription>
              {selectedPackage ? `Fill out the form below to request a quote for the ${selectedPackage.name} hosting package.` : 'Fill out the form below to request a quote.'}
            </DialogDescription>
          </DialogHeader>
          <QuoteRequestForm
            serviceType="Hosting"
            packageName={selectedPackage?.name || ''}
            onRequestSuccess={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}