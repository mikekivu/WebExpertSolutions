import { ServiceCard } from "@/components/ServiceCard";
import { Link } from "wouter";

const services = [
  {
    id: "web-development",
    icon: "laptop-code",
    title: "Web Development",
    description: "Custom websites that are responsive, fast, and designed to convert visitors into customers.",
    link: "/website-packages"
  },
  {
    id: "mobile-apps",
    icon: "mobile-alt",
    title: "Mobile Apps",
    description: "Native and cross-platform mobile applications for iOS and Android devices.",
    link: "/mobile-app-development"
  },
  {
    id: "software-development",
    icon: "cogs",
    title: "Software Development",
    description: "Custom software solutions including POS, microfinance, and school management systems.",
    link: "/software-development"
  },
  {
    id: "web-hosting",
    icon: "server",
    title: "Web Hosting",
    description: "Fast, secure, and reliable hosting solutions for websites of all sizes.",
    link: "/hosting-packages"
  },
  {
    id: "domain-registration",
    icon: "globe",
    title: "Domain Registration",
    description: "Register and manage domain names with competitive pricing and excellent support.",
    link: "/domain-registration"
  },
  {
    id: "bulk-sms",
    icon: "sms",
    title: "Bulk SMS",
    description: "Reach your customers instantly with our reliable bulk SMS messaging service.",
    link: "/bulk-sms"
  },
  {
    id: "digital-marketing",
    icon: "bullhorn",
    title: "Digital Marketing",
    description: "SEO, social media marketing, and PPC campaigns to increase your online visibility.",
    link: "/digital-marketing"
  },
  {
    id: "client-portal",
    icon: "user-lock",
    title: "Client Portal",
    description: "Access your services, invoices, and support through our convenient client portal.",
    link: "/login",
    linkText: "Access Portal"
  }
];

export function ServicesOverview() {
  return (
    <section id="services" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-gray-800 font-inter">Our Services</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Comprehensive digital solutions tailored to help your business succeed in the modern digital landscape.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((service) => (
            <ServiceCard
              key={service.id}
              id={service.id}
              icon={service.icon}
              title={service.title}
              description={service.description}
              link={service.link}
              linkText={service.linkText}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
