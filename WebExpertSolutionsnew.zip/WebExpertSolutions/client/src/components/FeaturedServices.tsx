import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const featuredServices = [
  {
    title: "Web Development",
    description: "Our web development team creates custom, responsive websites that are designed to convert visitors into customers. We focus on user experience, performance, and SEO to ensure your website stands out.",
    features: [
      "Responsive design for all devices",
      "SEO-optimized structure and content",
      "E-commerce and payment integration",
      "Content management systems (CMS)"
    ],
    imageUrl: "https://images.unsplash.com/photo-1522542550221-31fd19575a2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    imageAlt: "Web development services",
    reversed: false,
    buttonLink: "/website-packages",
    buttonText: "View Packages"
  },
  {
    title: "Mobile App Development",
    description: "We develop native and cross-platform mobile applications that provide seamless experiences across all devices. Our apps are built with the latest technologies for optimal performance.",
    features: [
      "Native iOS and Android development",
      "Cross-platform solutions",
      "UI/UX design for mobile interfaces",
      "App maintenance and support"
    ],
    imageUrl: "https://images.unsplash.com/photo-1581287053822-fd7bf4f4bfec?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    imageAlt: "Mobile app development",
    reversed: true
  },
  {
    title: "Custom Software Solutions",
    description: "We develop tailor-made software solutions to address your specific business needs. Our expertise includes point of sale systems, microfinance management software, and school management systems.",
    features: [
      "Point of Sale (POS) systems",
      "Microfinance management software",
      "School management systems",
      "Custom business automation tools"
    ],
    imageUrl: "https://images.unsplash.com/photo-1549692520-acc6669e2f0c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    imageAlt: "Software development solutions",
    reversed: false
  }
];

export function FeaturedServices() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-gray-800 font-inter">Featured Services</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Our most popular services that help businesses transform digitally
          </p>
        </div>

        {featuredServices.map((service, index) => (
          <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center mb-16">
            <div className={service.reversed ? "order-2 md:order-1" : ""}>
              {!service.reversed && (
                <>
                  <h3 className="text-2xl font-bold mb-4 text-gray-800 font-inter">{service.title}</h3>
                  <p className="text-gray-600 mb-4">
                    {service.description}
                  </p>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start">
                        <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href={service.buttonLink || "#contact"}>
                    <Button className="inline-block px-6 py-3 bg-primary hover:bg-blue-700 text-white font-medium rounded-md transition-colors">
                      {service.buttonText || "Get a Quote"}
                    </Button>
                  </Link>
                </>
              )}
              {service.reversed && (
                <div className="rounded-lg overflow-hidden shadow-lg">
                  <img src={service.imageUrl} alt={service.imageAlt} className="w-full h-auto" />
                </div>
              )}
            </div>
            
            <div className={service.reversed ? "order-1 md:order-2" : ""}>
              {service.reversed && (
                <>
                  <h3 className="text-2xl font-bold mb-4 text-gray-800 font-inter">{service.title}</h3>
                  <p className="text-gray-600 mb-4">
                    {service.description}
                  </p>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start">
                        <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href={service.buttonLink || "#contact"}>
                    <Button className="inline-block px-6 py-3 bg-primary hover:bg-blue-700 text-white font-medium rounded-md transition-colors">
                      {service.buttonText || "Get a Quote"}
                    </Button>
                  </Link>
                </>
              )}
              {!service.reversed && (
                <div className="rounded-lg overflow-hidden shadow-lg">
                  <img src={service.imageUrl} alt={service.imageAlt} className="w-full h-auto" />
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
