import { Link } from "wouter";
import { trackEvent } from "@/lib/analytics";

interface ServiceCardProps {
  id: string;
  icon: string;
  title: string;
  description: string;
  link: string;
  linkText?: string;
}

export function ServiceCard({ id, icon, title, description, link, linkText }: ServiceCardProps) {
  const handleServiceClick = () => {
    // Track when users click on a service card
    trackEvent(
      'service_selection',
      'engagement',
      `service_${id}`
    );
  };

  return (
    <div id={id} className="bg-white rounded-lg shadow-md p-6 transition-transform duration-300 hover:shadow-lg border border-gray-100 hover:-translate-y-1">
      <div className="text-primary mb-4 flex justify-center">
        <i className={`fas fa-${icon} text-3xl`}></i>
      </div>
      <h3 className="text-xl font-semibold mb-3 text-center text-gray-800 font-inter">{title}</h3>
      <p className="text-gray-600 mb-4 text-center">
        {description}
      </p>
      <Link 
        href={link} 
        className="block text-center text-primary hover:text-blue-700 font-medium"
        onClick={handleServiceClick}
      >
        {linkText || "Learn More"} <i className="fas fa-arrow-right ml-1"></i>
      </Link>
    </div>
  );
}
