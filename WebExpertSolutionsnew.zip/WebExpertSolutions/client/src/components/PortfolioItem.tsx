import { Button } from "@/components/ui/button";

interface PortfolioItemProps {
  item: {
    id: number;
    title: string;
    description: string;
    category: string;
    imageUrl: string;
    tags: string[];
    projectUrl?: string;
    featured: boolean;
  };
}

export function PortfolioItem({ item }: PortfolioItemProps) {
  return (
    <div className="rounded-lg overflow-hidden shadow-md bg-white portfolio-item relative group">
      <img 
        src={item.imageUrl} 
        alt={item.title} 
        className="w-full h-64 object-cover"
      />
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2 text-gray-800 font-inter">{item.title}</h3>
        <p className="text-gray-600 mb-3">{item.description}</p>
        <div className="flex flex-wrap gap-2">
          {item.tags.map((tag, index) => (
            <span key={index} className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
              {tag}
            </span>
          ))}
        </div>
      </div>
      <div className="absolute inset-0 bg-primary bg-opacity-80 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        <a 
          href={item.projectUrl || "#"} 
          target={item.projectUrl ? "_blank" : "_self"} 
          rel="noopener noreferrer"
        >
          <Button variant="secondary" className="px-6 py-3 bg-white text-primary font-medium rounded-md hover:bg-gray-100 transition-colors">
            View Project
          </Button>
        </a>
      </div>
    </div>
  );
}
