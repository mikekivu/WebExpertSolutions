import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export function HostingDomain() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-gray-800 font-inter">Web Hosting & Domain Services</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Fast, secure, and reliable hosting solutions with 24/7 support
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-blue-50 rounded-lg shadow-md p-8 border border-blue-100">
            <div className="flex items-center mb-6">
              <i className="fas fa-server text-primary text-3xl mr-4"></i>
              <h3 className="text-2xl font-bold text-gray-800 font-inter">Web Hosting</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Our hosting solutions are designed to provide optimal performance, security, and reliability for your website or application.
            </p>
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                <span>99.9% uptime guarantee</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                <span>Free SSL certificates</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                <span>Daily backups</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                <span>Managed security updates</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                <span>24/7 technical support</span>
              </li>
            </ul>
            {/* Server rack in a modern data center */}
            <img src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500" alt="Web hosting services" className="w-full h-auto rounded-lg shadow-md mb-6" />
            <Link href="#contact">
              <Button className="inline-block w-full text-center px-6 py-3 bg-primary hover:bg-blue-700 text-white font-medium rounded-md transition-colors">
                View Hosting Plans
              </Button>
            </Link>
          </div>

          <div className="bg-blue-50 rounded-lg shadow-md p-8 border border-blue-100">
            <div className="flex items-center mb-6">
              <i className="fas fa-globe text-primary text-3xl mr-4"></i>
              <h3 className="text-2xl font-bold text-gray-800 font-inter">Domain Registration</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Secure your online identity with our domain registration services. We offer competitive pricing and easy management.
            </p>
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                <span>Wide range of TLDs (.com, .co.ke, .org, etc.)</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                <span>Free WHOIS privacy protection</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                <span>Domain management dashboard</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                <span>Auto-renewal options</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-600 mt-1 mr-2"></i>
                <span>Email forwarding</span>
              </li>
            </ul>
            {/* A laptop showing a domain registration interface */}
            <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500" alt="Domain registration services" className="w-full h-auto rounded-lg shadow-md mb-6" />
            <Link href="#contact">
              <Button className="inline-block w-full text-center px-6 py-3 bg-primary hover:bg-blue-700 text-white font-medium rounded-md transition-colors">
                Check Domain Availability
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
