import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format, addDays } from "date-fns";
import { cn } from "@/lib/utils";
import { CalendarIcon, Plus, Trash2 } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";

interface User {
  id: number;
  fullName: string;
  email: string;
  company?: string;
}

const invoiceItemSchema = z.object({
  description: z.string().min(1, { message: "Description is required" }),
  quantity: z.string().min(1, { message: "Quantity is required" }).transform(val => Number(val)),
  unitPrice: z.string().min(1, { message: "Unit price is required" }).transform(val => val),
  total: z.string().optional(),
});

const formSchema = z.object({
  userId: z.number().min(1, { message: "Client is required" }),
  quoteId: z.number().optional(),
  items: z.array(invoiceItemSchema).min(1, { message: "At least one item is required" }),
  tax: z.string().optional(),
  dueDate: z.date().min(new Date(), { message: "Due date must be in the future" }),
});

interface InvoiceFormProps {
  onSuccess: () => void;
  clients: User[];
}

export function InvoiceForm({ onSuccess, clients }: InvoiceFormProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      items: [
        { description: "", quantity: "1", unitPrice: "", total: "0.00" },
      ],
      dueDate: addDays(new Date(), 14),
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items",
  });

  // Create invoice mutation
  const createInvoice = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      const { items, ...rest } = values;
      
      // Calculate totals for each item if not provided
      const calculatedItems = items.map(item => ({
        ...item,
        total: item.total || (Number(item.unitPrice) * item.quantity).toFixed(2)
      }));
      
      // Calculate the overall total
      const total = calculatedItems.reduce((sum, item) => {
        return sum + Number(item.total);
      }, 0);
      
      // Add tax if provided
      const taxAmount = values.tax ? Number(values.tax) : 0;
      const finalAmount = (total + taxAmount).toFixed(2);
      
      return apiRequest("POST", "/api/invoices", {
        ...rest,
        items: calculatedItems,
        amount: finalAmount
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({
        title: "Invoice created",
        description: "The invoice has been created successfully.",
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Failed to create invoice",
        description: error.message || "An error occurred while creating the invoice.",
        variant: "destructive",
      });
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    createInvoice.mutate(values);
  }

  // Calculate item total when quantity or unit price changes
  const calculateItemTotal = (index: number) => {
    const quantity = form.watch(`items.${index}.quantity`);
    const unitPrice = form.watch(`items.${index}.unitPrice`);
    
    if (quantity && unitPrice) {
      const total = (Number(quantity) * Number(unitPrice)).toFixed(2);
      form.setValue(`items.${index}.total`, total);
    }
  };

  // Calculate invoice total
  const calculateInvoiceTotal = () => {
    const items = form.watch("items");
    const tax = form.watch("tax") || "0";
    
    let subtotal = 0;
    items.forEach(item => {
      if (item.quantity && item.unitPrice) {
        subtotal += Number(item.quantity) * Number(item.unitPrice);
      }
    });
    
    const taxAmount = Number(tax);
    const total = subtotal + taxAmount;
    
    return {
      subtotal: subtotal.toFixed(2),
      tax: taxAmount.toFixed(2),
      total: total.toFixed(2)
    };
  };

  const totals = calculateInvoiceTotal();

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Client Selection */}
          <FormField
            control={form.control}
            name="userId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Client</FormLabel>
                <Select
                  onValueChange={(value) => field.onChange(parseInt(value))}
                  defaultValue={field.value?.toString()}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a client" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {clients.map((client) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.fullName} {client.company && `(${client.company})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormDescription>
                  The client who will receive this invoice
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Due Date */}
          <FormField
            control={form.control}
            name="dueDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Due Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      disabled={(date) => date < new Date()}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormDescription>
                  The date by which payment is due
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* Invoice Items */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-lg font-medium">Invoice Items</h3>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => append({ description: "", quantity: "1", unitPrice: "", total: "0.00" })}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Item
            </Button>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-12 gap-2 font-medium text-sm">
              <div className="col-span-6">Description</div>
              <div className="col-span-2">Quantity</div>
              <div className="col-span-2">Unit Price</div>
              <div className="col-span-1">Total</div>
              <div className="col-span-1"></div>
            </div>

            {fields.map((field, index) => (
              <div key={field.id} className="grid grid-cols-12 gap-2 items-start">
                <div className="col-span-6">
                  <FormField
                    control={form.control}
                    name={`items.${index}.description`}
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input placeholder="Item description" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="col-span-2">
                  <FormField
                    control={form.control}
                    name={`items.${index}.quantity`}
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="1" 
                            step="1" 
                            {...field} 
                            onChange={(e) => {
                              field.onChange(e);
                              calculateItemTotal(index);
                            }}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="col-span-2">
                  <FormField
                    control={form.control}
                    name={`items.${index}.unitPrice`}
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="0" 
                            step="0.01" 
                            placeholder="0.00" 
                            {...field} 
                            onChange={(e) => {
                              field.onChange(e);
                              calculateItemTotal(index);
                            }}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="col-span-1">
                  <FormField
                    control={form.control}
                    name={`items.${index}.total`}
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input
                            type="text"
                            readOnly
                            value={field.value}
                            className="bg-gray-50"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="col-span-1 flex justify-center pt-2">
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => remove(index)}
                    disabled={fields.length === 1}
                  >
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Invoice Summary */}
        <div className="flex justify-end">
          <div className="w-60 space-y-2">
            <div className="flex justify-between items-center">
              <span>Subtotal:</span>
              <span>KES {totals.subtotal}</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <span>Tax:</span>
              <FormField
                control={form.control}
                name="tax"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0" 
                        step="0.01" 
                        placeholder="0.00" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="flex justify-between items-center pt-2 border-t font-bold">
              <span>Total:</span>
              <span>KES {totals.total}</span>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-4">
          <Button 
            type="submit"
            disabled={createInvoice.isPending}
          >
            {createInvoice.isPending ? "Creating Invoice..." : "Create Invoice"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
