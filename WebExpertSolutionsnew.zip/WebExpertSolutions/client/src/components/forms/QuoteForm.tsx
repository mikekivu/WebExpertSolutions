import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useMutation, useQuery } from "@tanstack/react-query";
import { format, addDays } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

interface QuoteRequest {
  id: number;
  name: string;
  email: string;
  phone?: string;
  serviceType: string;
  message: string;
  status: string;
  createdAt: string;
}

interface QuoteFormProps {
  quoteRequest: QuoteRequest;
  onSuccess: () => void;
}

const formSchema = z.object({
  userId: z.number().optional(),
  quoteRequestId: z.number(),
  title: z.string().min(2, { message: "Title must be at least 2 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  amount: z.string().min(1, { message: "Amount is required" }),
  validUntil: z.date().min(new Date(), { message: "Valid until date must be in the future" })
});

export function QuoteForm({ quoteRequest, onSuccess }: QuoteFormProps) {
  // Find user by email in quoteRequest
  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
  });
  
  const matchingUser = users.find((user: any) => user.email === quoteRequest.email);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      userId: matchingUser?.id,
      quoteRequestId: quoteRequest.id,
      title: `Quote for ${getServiceTypeLabel(quoteRequest.serviceType)}`,
      description: `Based on your request: "${quoteRequest.message.slice(0, 100)}${quoteRequest.message.length > 100 ? '...' : ''}"`,
      amount: "",
      validUntil: addDays(new Date(), 14)
    },
  });

  // Create quote mutation
  const createQuote = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      return apiRequest("POST", "/api/quotes", values);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quote-requests"] });
      
      // Update quote request status to "quoted"
      updateQuoteRequestStatus.mutate();
      
      toast({
        title: "Quote created",
        description: "The quote has been created and sent to the client.",
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Failed to create quote",
        description: error.message || "An error occurred while creating the quote.",
        variant: "destructive",
      });
    },
  });

  // Update quote request status mutation
  const updateQuoteRequestStatus = useMutation({
    mutationFn: async () => {
      return apiRequest("PATCH", `/api/quote-requests/${quoteRequest.id}`, {
        status: "quoted"
      });
    }
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    createQuote.mutate(values);
  }

  function getServiceTypeLabel(type: string) {
    switch(type) {
      case "web-development":
        return "Web Development";
      case "mobile-app":
        return "Mobile App Development";
      case "software-development":
        return "Software Development";
      case "web-hosting":
        return "Web Hosting";
      case "domain-registration":
        return "Domain Registration";
      case "bulk-sms":
        return "Bulk SMS";
      case "digital-marketing":
        return "Digital Marketing";
      default:
        return type;
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Quote Request Details */}
      <Card>
        <CardHeader>
          <CardTitle>Request Details</CardTitle>
          <CardDescription>
            Original request information
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium mb-1">Client</h3>
            <p>{quoteRequest.name}</p>
            <p className="text-sm text-muted-foreground">{quoteRequest.email}</p>
            {quoteRequest.phone && <p className="text-sm text-muted-foreground">{quoteRequest.phone}</p>}
          </div>
          
          <div>
            <h3 className="font-medium mb-1">Service Type</h3>
            <p>{getServiceTypeLabel(quoteRequest.serviceType)}</p>
          </div>
          
          <div>
            <h3 className="font-medium mb-1">Request Message</h3>
            <p className="text-sm whitespace-pre-wrap">{quoteRequest.message}</p>
          </div>
          
          <div>
            <h3 className="font-medium mb-1">Request Date</h3>
            <p className="text-sm">{format(new Date(quoteRequest.createdAt), 'MMMM d, yyyy, h:mm a')}</p>
          </div>
        </CardContent>
      </Card>

      {/* Quote Form */}
      <Card>
        <CardHeader>
          <CardTitle>Create Quote</CardTitle>
          <CardDescription>
            Send a quote to the client
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {!matchingUser && (
                <div className="bg-yellow-50 text-yellow-800 p-3 rounded-md mb-4 text-sm">
                  <strong>Note:</strong> This client is not registered in the system. The quote will be sent via email and they will need to register to view it.
                </div>
              )}
              
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quote Title</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea rows={5} {...field} />
                    </FormControl>
                    <FormDescription>
                      Detailed description of services included in the quote
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (KES)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0" 
                        step="0.01" 
                        placeholder="0.00"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="validUntil"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Valid Until</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormDescription>
                      The date until which this quote is valid
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-end pt-4">
                <Button 
                  type="submit"
                  disabled={createQuote.isPending}
                >
                  {createQuote.isPending ? "Creating Quote..." : "Create Quote"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
