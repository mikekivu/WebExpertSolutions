import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { toast } from "@/hooks/use-toast";
import { 
  FaFacebook, 
  FaLinkedin, 
  FaTwitter, 
  FaTiktok, 
  FaInstagram 
} from "react-icons/fa";
import logoSvg from "@/assets/logo.svg";

export function Footer() {
  const [email, setEmail] = useState("");

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!email) return;
    
    // In a real application, this would send the email to a newsletter service
    toast({
      title: "Success!",
      description: "You've been subscribed to our newsletter.",
    });
    
    setEmail("");
  };

  return (
    <footer className="bg-gray-900 text-white pt-16 pb-6">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <img src={logoSvg} alt="Web Expert Solutions Logo" className="h-12 mr-2" />
            </div>
            <p className="text-gray-400 mb-4">
              Providing comprehensive digital solutions to help businesses grow and succeed in the digital age.
            </p>
            <div className="flex space-x-4">
              <a href="https://www.facebook.com/webexpertsolutionskenya" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <FaFacebook size={20} />
              </a>
              <a href="https://www.linkedin.com/in/mike-kivu-paul-769547ba" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <FaLinkedin size={20} />
              </a>
              <a href="https://x.com/WebExpertke" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <FaTwitter size={20} />
              </a>
              <a href="https://www.tiktok.com/@web.expert.soluti?lang=en" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <FaTiktok size={20} />
              </a>
              <a href="https://www.instagram.com/webexpertsolutions" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <FaInstagram size={20} />
              </a>
            </div>
          </div>
          
          {/* Services */}
          <div>
            <h3 className="text-xl font-bold mb-4 font-inter">Our Services</h3>
            <ul className="space-y-2">
              <li><Link href="/website-packages" className="text-gray-400 hover:text-white transition-colors">Web Development</Link></li>
              <li><Link href="/mobile-app-development" className="text-gray-400 hover:text-white transition-colors">Mobile App Development</Link></li>
              <li><Link href="/software-development" className="text-gray-400 hover:text-white transition-colors">Software Development</Link></li>
              <li><Link href="/hosting-packages" className="text-gray-400 hover:text-white transition-colors">Web Hosting</Link></li>
              <li><Link href="/domain-registration" className="text-gray-400 hover:text-white transition-colors">Domain Registration</Link></li>
              <li><Link href="/bulk-sms" className="text-gray-400 hover:text-white transition-colors">Bulk SMS Services</Link></li>
              <li><Link href="/digital-marketing" className="text-gray-400 hover:text-white transition-colors">Digital Marketing</Link></li>
            </ul>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4 font-inter">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-gray-400 hover:text-white transition-colors">Home</Link></li>
              <li><Link href="/about-us" className="text-gray-400 hover:text-white transition-colors">About Us</Link></li>
              <li><Link href="/portfolio" className="text-gray-400 hover:text-white transition-colors">Portfolio</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors">Contact</Link></li>
              <li><Link href="/contact/quote" className="text-gray-400 hover:text-white transition-colors">Get Free Quote</Link></li>
              <li><Link href="/login" className="text-gray-400 hover:text-white transition-colors">Client Portal</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>
          
          {/* Newsletter */}
          <div>
            <h3 className="text-xl font-bold mb-4 font-inter">Newsletter</h3>
            <p className="text-gray-400 mb-4">
              Subscribe to our newsletter to receive updates on our services and tech tips.
            </p>
            <form className="mb-4" onSubmit={handleSubmit}>
              <div className="flex">
                <Input
                  type="email"
                  placeholder="Your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-l-md rounded-r-none"
                />
                <Button 
                  type="submit" 
                  className="bg-primary hover:bg-blue-700 text-white px-4 py-2 rounded-r-md rounded-l-none transition-colors"
                >
                  <i className="fas fa-paper-plane"></i>
                </Button>
              </div>
            </form>
            <h4 className="text-base font-medium mb-2 mt-4 text-gray-300">Payment Methods Accepted</h4>
            <div className="flex items-center space-x-4">
              <div className="bg-white rounded p-1.5 h-8 w-16 flex items-center justify-center">
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/M-PESA_LOGO-01.svg/2560px-M-PESA_LOGO-01.svg.png" 
                  alt="M-Pesa" 
                  className="h-5 object-contain" 
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://seeklogo.com/images/M/m-pesa-logo-4D38C13EB5-seeklogo.com.png";
                  }}
                />
              </div>
              <div className="bg-white rounded p-1.5 h-8 w-16 flex items-center justify-center">
                <img 
                  src="https://www.paypalobjects.com/webstatic/mktg/logo/pp_cc_mark_37x23.jpg" 
                  alt="PayPal" 
                  className="h-5 object-contain" 
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://www.paypalobjects.com/digitalassets/c/website/logo/full-text/pp_fc_hl.svg";
                  }}
                />
              </div>
              <div className="bg-white rounded p-1.5 h-8 w-16 flex items-center justify-center">
                <img 
                  src="https://usa.visa.com/dam/VCOM/regional/ve/romania/blogs/hero-image/visa-logo-800x450.jpg" 
                  alt="Visa" 
                  className="h-5 object-contain" 
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/1200px-Visa_Inc._logo.svg.png";
                  }}
                />
              </div>
              <div className="bg-white rounded p-1.5 h-8 w-16 flex items-center justify-center">
                <img 
                  src="https://brand.mastercard.com/content/dam/mccom/brandcenter/brand-history/brandhistory_mc_vrt_120_2x.png" 
                  alt="Mastercard" 
                  className="h-5 object-contain" 
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/1200px-Mastercard-logo.svg.png";
                  }}
                />
              </div>
            </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Web Expert Solutions Kenya. All rights reserved. Developed by Web Expert Solutions</p>
        </div>
      </div>
    </footer>
  );
}
