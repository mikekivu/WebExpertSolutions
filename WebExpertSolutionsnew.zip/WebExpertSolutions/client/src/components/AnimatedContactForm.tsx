import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { apiRequest } from "@/lib/queryClient";
import { trackEvent } from "@/lib/analytics";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormSuccess,
} from "@/components/ui/form-with-animations";
import { AnimatedInput } from "@/components/ui/animated-input";
import { AnimatedTextarea } from "@/components/ui/animated-textarea";
import { Button } from "@/components/ui/button";
import { Loader2, Send, Mail, User, Phone, Building } from "lucide-react";

// Form validation schema
const contactFormSchema = z.object({
  name: z
    .string()
    .min(3, { message: "Name must be at least 3 characters" })
    .max(50, { message: "Name cannot exceed 50 characters" }),
  email: z
    .string()
    .email({ message: "Please enter a valid email address" }),
  phone: z
    .string()
    .regex(/^(\+\d{1,3}\s?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/, { 
      message: "Please enter a valid phone number" 
    }),
  company: z
    .string()
    .optional(),
  message: z
    .string()
    .min(10, { message: "Message must be at least 10 characters" })
    .max(500, { message: "Message cannot exceed 500 characters" }),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

// Field animation variants
const fieldVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.1,
      duration: 0.4,
      ease: "easeOut"
    }
  })
};

export function AnimatedContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formSuccess, setFormSuccess] = useState("");
  
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      company: "",
      message: "",
    },
    mode: "onChange", // Validate on change for immediate feedback
  });

  async function onSubmit(data: ContactFormValues) {
    setIsSubmitting(true);
    setFormSuccess("");
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // This would be a real API call in production
      // await apiRequest("POST", "/api/contact", data);
      
      console.log("Form submitted successfully:", data);
      
      // Track the successful contact form submission
      trackEvent(
        'form_submission', 
        'contact', 
        'contact_form_success', 
      );
      
      // Show success message
      setFormSuccess("Your message has been sent! We'll get back to you soon.");
      
      // Reset form
      form.reset();
    } catch (error) {
      console.error("Error submitting form:", error);
      
      // Track form submission errors
      trackEvent(
        'form_error',
        'contact',
        'contact_form_error',
      );
      
      form.setError("root", { 
        message: "There was an error sending your message. Please try again."
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="max-w-xl mx-auto p-6 bg-white/50 backdrop-blur-sm rounded-lg shadow-lg">
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-gray-800">Contact Us</h2>
        <p className="text-gray-600">Fill out the form below to get in touch with our team</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <motion.div
            initial="hidden"
            animate="visible"
            custom={0}
            variants={fieldVariants}
          >
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    <User className="h-4 w-4 mr-2 inline-block" /> 
                    Name
                  </FormLabel>
                  <FormControl>
                    <AnimatedInput 
                      placeholder="Enter your full name" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </motion.div>

          <motion.div
            initial="hidden"
            animate="visible"
            custom={1}
            variants={fieldVariants}
          >
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    <Mail className="h-4 w-4 mr-2 inline-block" /> 
                    Email
                  </FormLabel>
                  <FormControl>
                    <AnimatedInput 
                      type="email" 
                      placeholder="Enter your email address" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </motion.div>

          <motion.div
            initial="hidden"
            animate="visible"
            custom={2}
            variants={fieldVariants}
          >
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    <Phone className="h-4 w-4 mr-2 inline-block" /> 
                    Phone Number
                  </FormLabel>
                  <FormControl>
                    <AnimatedInput 
                      type="tel" 
                      placeholder="Enter your phone number" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </motion.div>

          <motion.div
            initial="hidden"
            animate="visible"
            custom={3}
            variants={fieldVariants}
          >
            <FormField
              control={form.control}
              name="company"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    <Building className="h-4 w-4 mr-2 inline-block" /> 
                    Company (Optional)
                  </FormLabel>
                  <FormControl>
                    <AnimatedInput 
                      placeholder="Enter your company name" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </motion.div>

          <motion.div
            initial="hidden"
            animate="visible"
            custom={4}
            variants={fieldVariants}
          >
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message</FormLabel>
                  <FormControl>
                    <AnimatedTextarea 
                      placeholder="How can we help you?" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </motion.div>

          {formSuccess && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-green-50 p-4 rounded-md border border-green-200"
            >
              <FormSuccess>{formSuccess}</FormSuccess>
            </motion.div>
          )}

          <motion.div
            initial="hidden"
            animate="visible"
            custom={5}
            variants={fieldVariants}
            className="flex justify-end"
          >
            <Button 
              type="submit" 
              disabled={isSubmitting}
              className="relative group overflow-hidden"
            >
              <span className="relative z-10 flex items-center">
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    Send Message
                  </>
                )}
              </span>
              <span className="absolute inset-0 bg-primary-dark scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-300 ease-out" />
            </Button>
          </motion.div>
        </form>
      </Form>
    </div>
  );
}