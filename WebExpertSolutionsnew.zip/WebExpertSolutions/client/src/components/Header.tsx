import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Menu, X, Mail, Phone } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import logoSvg from "@/assets/logo.svg";
import { 
  FaFacebook, 
  FaTwitter, 
  FaLinkedin, 
  FaInstagram, 
  FaTiktok 
} from "react-icons/fa";

export interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: string;
}

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  
  // Get current session
  const { data: session } = useQuery({
    queryKey: ["/api/auth/session"],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  const isAuthenticated = session?.authenticated;
  const user = session?.user as User | undefined;

  // Close mobile menu when location changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout");
      window.location.href = "/";
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      {/* Top Bar with Contact Info and Social Media */}
      <div className="bg-primary text-white py-1 text-sm">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <span className="inline-flex items-center">
              <Phone className="h-4 w-4 mr-1" />
              <span>+254112345366</span>
            </span>
            <span className="inline-flex items-center">
              <Mail className="h-4 w-4 mr-1" />
              <span>info@webexpertsolutions.co.ke</span>
            </span>
          </div>
          
          <div className="hidden sm:flex items-center space-x-3">
            <a href="https://www.facebook.com/webexpertsolutionskenya" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-200 transition-colors">
              <FaFacebook size={16} />
            </a>
            <a href="https://www.linkedin.com/in/mike-kivu-paul-769547ba" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-200 transition-colors">
              <FaLinkedin size={16} />
            </a>
            <a href="https://x.com/WebExpertke" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-200 transition-colors">
              <FaTwitter size={16} />
            </a>
            <a href="https://www.tiktok.com/@web.expert.soluti?lang=en" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-200 transition-colors">
              <FaTiktok size={16} />
            </a>
            <a href="https://www.instagram.com/webexpertsolutions" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-200 transition-colors">
              <FaInstagram size={16} />
            </a>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <img src={logoSvg} alt="Web Expert Solutions Logo" className="h-12 mr-2" />
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-gray-700 hover:text-primary font-medium transition-colors">Home</Link>
            <DropdownMenu>
              <DropdownMenuTrigger className="text-gray-700 hover:text-primary font-medium transition-colors flex items-center">
                Services <i className="fas fa-chevron-down ml-1 text-xs"></i>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem asChild>
                  <Link href="/website-packages" className="block w-full">Web Development</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/mobile-app-development" className="block w-full">Mobile Apps</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/software-development" className="block w-full">Software Development</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/hosting-packages" className="block w-full">Web Hosting</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/domain-registration" className="block w-full">Domain Registration</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/bulk-sms" className="block w-full">Bulk SMS</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/digital-marketing" className="block w-full">Digital Marketing</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Link href="/portfolio" className="text-gray-700 hover:text-primary font-medium transition-colors">Portfolio</Link>
            <Link href="/contact" className="text-gray-700 hover:text-primary font-medium transition-colors">Contact</Link>
            <Link href="/about-us" className="text-gray-700 hover:text-primary font-medium transition-colors">About Us</Link>
            <Link href="/contact/quote" className="text-gray-700 hover:text-primary font-medium transition-colors">Get Free Quote</Link>
          </nav>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
          
          {/* Login/Register Buttons or User Menu */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">
                    {user?.fullName || user?.username}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {user?.role === "admin" ? (
                    <DropdownMenuItem asChild>
                      <Link href="/admin/dashboard" className="block w-full">Admin Dashboard</Link>
                    </DropdownMenuItem>
                  ) : (
                    <DropdownMenuItem asChild>
                      <Link href="/client/dashboard" className="block w-full">My Dashboard</Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem asChild>
                    <button 
                      className="block w-full text-left" 
                      onClick={handleLogout}
                    >
                      Logout
                    </button>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Link href="/login" className="font-medium text-primary hover:text-primary-dark transition-colors">
                  Login
                </Link>
                <Link href="/register">
                  <Button>Register</Button>
                </Link>
              </>
            )}
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <Link href="/" className="block px-3 py-2 rounded-md text-base font-medium text-primary bg-gray-50">Home</Link>
              <Link href="/#services" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Services</Link>
              <Link href="/website-packages" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Website Packages</Link>
              <Link href="/hosting-packages" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Hosting Packages</Link>
              <Link href="/mobile-app-development" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Mobile App Development</Link>
              <Link href="/software-development" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Software Development</Link>
              <Link href="/domain-registration" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Domain Registration</Link>
              <Link href="/bulk-sms" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Bulk SMS</Link>
              <Link href="/digital-marketing" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Digital Marketing</Link>
              <Link href="/portfolio" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Portfolio</Link>
              <Link href="/contact" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Contact</Link>
              <Link href="/about-us" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">About Us</Link>
              <Link href="/contact/quote" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50 bg-gray-100">Get Free Quote</Link>
              
              {isAuthenticated ? (
                <>
                  {user?.role === "admin" ? (
                    <Link 
                      href="/admin/dashboard" 
                      className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50"
                    >
                      Admin Dashboard
                    </Link>
                  ) : (
                    <Link 
                      href="/client/dashboard" 
                      className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50"
                    >
                      My Dashboard
                    </Link>
                  )}
                  <button 
                    onClick={handleLogout}
                    className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <div className="mt-3 flex space-x-2">
                  <Link href="/login" className="w-1/2 text-center font-medium text-primary border border-primary py-2 px-4 rounded-md hover:bg-blue-50 transition-colors">Login</Link>
                  <Link href="/register" className="w-1/2 text-center bg-primary hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors">Register</Link>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
