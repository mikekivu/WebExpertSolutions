import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useState, useEffect } from "react";
import techInteractiveGlobeSvg from "@/assets/tech-interactive-globe.svg";

export function HeroSection() {
  const [isHovered, setIsHovered] = useState(false);
  const [textColor, setTextColor] = useState("text-white");
  
  // Effect for color transition when hovered
  useEffect(() => {
    if (isHovered) {
      setTextColor("text-yellow-300");
    } else {
      setTextColor("text-white");
    }
  }, [isHovered]);

  return (
    <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16 md:py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 items-center gap-12">
          <div>
            <h1 
              className={`text-3xl md:text-4xl lg:text-5xl font-bold mb-4 font-inter leading-tight transition-colors duration-300 ${textColor} cursor-pointer transform hover:scale-105`}
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={() => setIsHovered(false)}
            >
              Complete Digital Solutions for Your Business
            </h1>
            <p className="text-lg md:text-xl mb-8 text-blue-100 leading-relaxed">
              Web development, mobile apps, custom software, hosting, and digital marketing services to help your business grow.
            </p>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <Link href="/contact/quote">
                <Button 
                  className="px-6 py-3 bg-[#fd7e14] hover:bg-orange-600 text-white font-medium rounded-md text-center transition-colors w-full sm:w-auto"
                >
                  Get a Free Quote
                </Button>
              </Link>
              <Link href="/website-packages">
                <Button 
                  variant="outline"
                  className="px-6 py-3 bg-white bg-opacity-20 hover:bg-opacity-30 text-white border border-white border-opacity-40 font-medium rounded-md text-center transition-colors w-full sm:w-auto"
                >
                  Explore Services
                </Button>
              </Link>
            </div>
          </div>
          {/* Interactive Tech Graphics with Globe, Servers and Websites */}
          <div className="hidden md:block relative">
            <div className="rounded-lg shadow-xl overflow-hidden transform transition-all duration-300 hover:scale-105">
              <div className="w-full aspect-square max-h-[400px] relative">
                <img 
                  src={techInteractiveGlobeSvg} 
                  alt="Interactive Digital Solutions" 
                  className="w-full h-full object-cover rounded-lg" 
                />
                <div className="absolute inset-0 bg-gradient-to-br from-blue-600/0 to-blue-900/30 rounded-lg"></div>
              </div>
              <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center">
                <div className="w-24 h-24 rounded-full bg-blue-500/20 animate-pulse"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
