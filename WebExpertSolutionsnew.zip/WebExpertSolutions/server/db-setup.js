const { Pool } = require('pg');
const bcrypt = require('bcryptjs');

// Create a PostgreSQL client
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// SQL to create the tables
const createTablesSql = `
-- Create sessions table
CREATE TABLE IF NOT EXISTS "sessions" (
  "sid" VARCHAR(255) PRIMARY KEY,
  "sess" JSONB NOT NULL,
  "expire" TIMESTAMP NOT NULL
);
CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "sessions" ("expire");

-- Create users table
CREATE TABLE IF NOT EXISTS "users" (
  "id" SERIAL PRIMARY KEY,
  "username" VARCHAR(255) NOT NULL UNIQUE,
  "email" VARCHAR(255) NOT NULL UNIQUE,
  "password" VARCHAR(255) NOT NULL,
  "full_name" VARCHAR(255),
  "phone" VARCHAR(255),
  "company" VARCHAR(255),
  "role" VARCHAR(50) DEFAULT 'client',
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "verification_token" VARCHAR(255),
  "verified" BOOLEAN DEFAULT false,
  "reset_token" VARCHAR(255),
  "reset_token_expiry" TIMESTAMP,
  "stripe_customer_id" VARCHAR(255),
  "stripe_subscription_id" VARCHAR(255)
);

-- Create services table
CREATE TABLE IF NOT EXISTS "services" (
  "id" SERIAL PRIMARY KEY,
  "name" VARCHAR(255) NOT NULL,
  "description" TEXT NOT NULL,
  "category" VARCHAR(100) NOT NULL,
  "price" DECIMAL(10, 2),
  "price_type" VARCHAR(50) DEFAULT 'fixed',
  "price_range" VARCHAR(100),
  "duration" INTEGER,
  "duration_type" VARCHAR(50) DEFAULT 'days',
  "features" TEXT[],
  "is_active" BOOLEAN DEFAULT true,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create client_services table
CREATE TABLE IF NOT EXISTS "client_services" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "service_id" INTEGER NOT NULL REFERENCES "services"("id"),
  "status" VARCHAR(50) DEFAULT 'pending',
  "purchase_date" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "expiry_date" TIMESTAMP,
  "renewal_date" TIMESTAMP,
  "notes" TEXT,
  "price" DECIMAL(10, 2) NOT NULL,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create quote_requests table
CREATE TABLE IF NOT EXISTS "quote_requests" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER REFERENCES "users"("id"),
  "name" VARCHAR(255) NOT NULL,
  "email" VARCHAR(255) NOT NULL,
  "phone" VARCHAR(255) NOT NULL,
  "company" VARCHAR(255),
  "service_type" VARCHAR(100) NOT NULL,
  "message" TEXT NOT NULL,
  "status" VARCHAR(50) DEFAULT 'pending',
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create quotes table
CREATE TABLE IF NOT EXISTS "quotes" (
  "id" SERIAL PRIMARY KEY,
  "quote_request_id" INTEGER REFERENCES "quote_requests"("id"),
  "user_id" INTEGER REFERENCES "users"("id"),
  "title" VARCHAR(255) NOT NULL,
  "description" TEXT NOT NULL,
  "total_price" DECIMAL(10, 2) NOT NULL,
  "valid_until" TIMESTAMP NOT NULL,
  "status" VARCHAR(50) DEFAULT 'sent',
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create invoices table
CREATE TABLE IF NOT EXISTS "invoices" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "quote_id" INTEGER REFERENCES "quotes"("id"),
  "client_service_id" INTEGER REFERENCES "client_services"("id"),
  "invoice_number" VARCHAR(100) NOT NULL UNIQUE,
  "title" VARCHAR(255) NOT NULL,
  "description" TEXT,
  "total_amount" DECIMAL(10, 2) NOT NULL,
  "tax_amount" DECIMAL(10, 2),
  "due_date" TIMESTAMP NOT NULL,
  "status" VARCHAR(50) DEFAULT 'unpaid',
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create payments table
CREATE TABLE IF NOT EXISTS "payments" (
  "id" SERIAL PRIMARY KEY,
  "invoice_id" INTEGER NOT NULL REFERENCES "invoices"("id"),
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "amount" DECIMAL(10, 2) NOT NULL,
  "payment_method" VARCHAR(50) NOT NULL,
  "transaction_id" VARCHAR(255),
  "status" VARCHAR(50) DEFAULT 'completed',
  "payment_date" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "notes" TEXT,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create portfolio_items table
CREATE TABLE IF NOT EXISTS "portfolio_items" (
  "id" SERIAL PRIMARY KEY,
  "title" VARCHAR(255) NOT NULL,
  "description" TEXT NOT NULL,
  "category" VARCHAR(100) NOT NULL,
  "image_url" VARCHAR(255) NOT NULL,
  "website_url" VARCHAR(255),
  "client_name" VARCHAR(255),
  "completion_date" DATE,
  "featured" BOOLEAN DEFAULT false,
  "technologies" TEXT[],
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create testimonials table
CREATE TABLE IF NOT EXISTS "testimonials" (
  "id" SERIAL PRIMARY KEY,
  "client_name" VARCHAR(255) NOT NULL,
  "client_company" VARCHAR(255),
  "client_title" VARCHAR(255),
  "profile_image" VARCHAR(255),
  "content" TEXT NOT NULL,
  "rating" INTEGER DEFAULT 5,
  "project_type" VARCHAR(100),
  "is_active" BOOLEAN DEFAULT true,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create emails table
CREATE TABLE IF NOT EXISTS "emails" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER REFERENCES "users"("id"),
  "to" VARCHAR(255) NOT NULL,
  "subject" VARCHAR(255) NOT NULL,
  "content" TEXT NOT NULL,
  "sent_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "status" VARCHAR(50) DEFAULT 'sent',
  "type" VARCHAR(50),
  "metadata" JSONB,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create web_packages table
CREATE TABLE IF NOT EXISTS "web_packages" (
  "id" SERIAL PRIMARY KEY,
  "name" VARCHAR(255) NOT NULL,
  "description" TEXT NOT NULL,
  "price_range" VARCHAR(100) NOT NULL,
  "features" TEXT[],
  "pages_included" INTEGER DEFAULT 1,
  "revisions" INTEGER DEFAULT 1,
  "delivery_time" VARCHAR(100),
  "support_period" VARCHAR(100),
  "featured" BOOLEAN DEFAULT false,
  "popular" BOOLEAN DEFAULT false,
  "is_active" BOOLEAN DEFAULT true,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create hosting_packages table
CREATE TABLE IF NOT EXISTS "hosting_packages" (
  "id" SERIAL PRIMARY KEY,
  "name" VARCHAR(255) NOT NULL,
  "description" TEXT NOT NULL,
  "price_range" VARCHAR(100) NOT NULL,
  "storage_space" VARCHAR(100) NOT NULL,
  "bandwidth" VARCHAR(100) NOT NULL,
  "email_accounts" INTEGER DEFAULT 0,
  "features" TEXT[],
  "support_period" VARCHAR(100),
  "featured" BOOLEAN DEFAULT false,
  "popular" BOOLEAN DEFAULT false,
  "is_active" BOOLEAN DEFAULT true,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create billing_plans table
CREATE TABLE IF NOT EXISTS "billing_plans" (
  "id" SERIAL PRIMARY KEY,
  "name" VARCHAR(255) NOT NULL,
  "description" TEXT,
  "frequency" VARCHAR(50) NOT NULL,
  "days_in_cycle" INTEGER NOT NULL,
  "is_active" BOOLEAN DEFAULT true,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create reminder_templates table
CREATE TABLE IF NOT EXISTS "reminder_templates" (
  "id" SERIAL PRIMARY KEY,
  "name" VARCHAR(255) NOT NULL,
  "type" VARCHAR(50) NOT NULL,
  "subject" VARCHAR(255) NOT NULL,
  "content" TEXT NOT NULL,
  "days_offset" INTEGER DEFAULT 0,
  "is_active" BOOLEAN DEFAULT true,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create recurring_invoices table
CREATE TABLE IF NOT EXISTS "recurring_invoices" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "billing_plan_id" INTEGER NOT NULL REFERENCES "billing_plans"("id"),
  "title" VARCHAR(255) NOT NULL,
  "description" TEXT,
  "amount" DECIMAL(10, 2) NOT NULL,
  "last_billed_date" TIMESTAMP,
  "next_billing_date" TIMESTAMP NOT NULL,
  "status" VARCHAR(50) DEFAULT 'active',
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create reminder_logs table
CREATE TABLE IF NOT EXISTS "reminder_logs" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "invoice_id" INTEGER REFERENCES "invoices"("id"),
  "recurring_invoice_id" INTEGER REFERENCES "recurring_invoices"("id"),
  "reminder_template_id" INTEGER REFERENCES "reminder_templates"("id"),
  "email_id" INTEGER REFERENCES "emails"("id"),
  "sent_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "status" VARCHAR(50) DEFAULT 'sent',
  "type" VARCHAR(50) NOT NULL,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create contact_info table
CREATE TABLE IF NOT EXISTS "contact_info" (
  "id" SERIAL PRIMARY KEY,
  "phone_number1" VARCHAR(255) NOT NULL,
  "phone_number2" VARCHAR(255),
  "email" VARCHAR(255) NOT NULL,
  "location" VARCHAR(255) NOT NULL,
  "google_map_link" VARCHAR(255),
  "updated_at" TIMESTAMP
);

-- Create about_us table
CREATE TABLE IF NOT EXISTS "about_us" (
  "id" SERIAL PRIMARY KEY,
  "title" VARCHAR(255) NOT NULL,
  "subtitle" VARCHAR(255),
  "content" TEXT NOT NULL,
  "mission" TEXT,
  "vision" TEXT,
  "values" TEXT,
  "updated_at" TIMESTAMP
);

-- Create team_members table
CREATE TABLE IF NOT EXISTS "team_members" (
  "id" SERIAL PRIMARY KEY,
  "name" VARCHAR(255) NOT NULL,
  "position" VARCHAR(255) NOT NULL,
  "bio" TEXT,
  "image_url" VARCHAR(255),
  "email" VARCHAR(255),
  "social_links" JSONB,
  "is_active" BOOLEAN DEFAULT true,
  "display_order" INTEGER DEFAULT 0,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create analytics_data table
CREATE TABLE IF NOT EXISTS "analytics_data" (
  "id" SERIAL PRIMARY KEY,
  "date" DATE NOT NULL,
  "page_views" INTEGER DEFAULT 0,
  "unique_visitors" INTEGER DEFAULT 0,
  "conversion_rate" DECIMAL(5, 2) DEFAULT 0,
  "bounce_rate" DECIMAL(5, 2) DEFAULT 0,
  "top_sources_data" JSONB,
  "visitors_by_location" JSONB,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
`;

// Insert default data
const insertDataSql = `
-- Insert default admin user
INSERT INTO "users" ("username", "email", "password", "full_name", "role", "verified")
VALUES 
  ('admin', 'admin@webexpertsolutions.co.ke', '$2a$10$eDJ3SZe.U9yAkJ5eRcN/C.PXsUEgEjhNLTFAr1Unl9b69RtGTuYHO', 'System Administrator', 'admin', true)
ON CONFLICT (username) DO NOTHING;

-- Insert contact information
INSERT INTO "contact_info" ("phone_number1", "phone_number2", "email", "location", "updated_at")
VALUES 
  ('+254112345366', '+254715026405', 'info@webexpertsolutions.co.ke', 'CBD, Nairobi, Kenya', CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;

-- Insert about us information
INSERT INTO "about_us" ("title", "subtitle", "content", "mission", "vision", "values", "updated_at")
VALUES 
  (
    'About Web Expert Solutions', 
    'Your Trusted Technology Partner', 
    'Web Expert Solutions is a leading web development and digital solutions provider based in Nairobi, Kenya. We specialize in creating custom web applications, mobile apps, and business management systems that help businesses grow and succeed in the digital age.', 
    'Our mission is to empower businesses with innovative, reliable, and cost-effective digital solutions that drive growth and efficiency.', 
    'To be the most trusted technology partner for businesses in East Africa, known for our exceptional quality, reliability, and customer service.', 
    'Innovation, Integrity, Excellence, Customer Focus, Continuous Improvement', 
    CURRENT_TIMESTAMP
  )
ON CONFLICT DO NOTHING;

-- Insert web packages
INSERT INTO "web_packages" ("name", "description", "price_range", "features", "pages_included", "revisions", "delivery_time", "support_period", "popular", "featured")
VALUES 
  (
    'Basic Website', 
    'Perfect for small businesses and startups looking to establish their online presence.', 
    'Ksh 15,000-25,000', 
    ARRAY['Responsive design', 'Contact form', 'Social media integration', 'Google Maps integration', 'SEO optimization'], 
    5, 
    2, 
    '7-14 days', 
    '30 days', 
    false, 
    false
  ),
  (
    'Standard Website', 
    'Ideal for growing businesses that need additional features and functionality.', 
    'Ksh 25,000-45,000', 
    ARRAY['All Basic features', 'Content Management System', 'Blog/News section', 'Photo gallery', 'Newsletter signup', 'Google Analytics integration', 'Speed optimization'], 
    10, 
    3, 
    '14-21 days', 
    '60 days', 
    true, 
    true
  ),
  (
    'Premium Website', 
    'Comprehensive solution for established businesses requiring advanced features.', 
    'Ksh 45,000-85,000', 
    ARRAY['All Standard features', 'E-commerce integration', 'Custom database', 'User accounts', 'Advanced security', 'Payment gateway integration', 'Custom animations', 'Multilingual support'], 
    15, 
    5, 
    '21-30 days', 
    '90 days', 
    false, 
    true
  )
ON CONFLICT DO NOTHING;

-- Insert hosting packages
INSERT INTO "hosting_packages" ("name", "description", "price_range", "storage_space", "bandwidth", "email_accounts", "features", "support_period", "popular", "featured")
VALUES 
  (
    'Basic Hosting', 
    'Affordable hosting solution for small websites and blogs.', 
    'Ksh 500-1,000/month', 
    '5 GB', 
    '50 GB/month', 
    5, 
    ARRAY['99.9% uptime guarantee', 'cPanel access', 'Free SSL certificate', 'Daily backups', '24/7 monitoring'], 
    'Email support', 
    false, 
    false
  ),
  (
    'Business Hosting', 
    'Reliable hosting for business websites with moderate traffic.', 
    'Ksh 1,500-3,000/month', 
    '20 GB', 
    '200 GB/month', 
    10, 
    ARRAY['99.9% uptime guarantee', 'cPanel access', 'Free SSL certificate', 'Daily backups', '24/7 monitoring', 'CDN integration', 'Priority support', 'Malware scanning'], 
    'Email and chat support', 
    true, 
    true
  ),
  (
    'Premium Hosting', 
    'High-performance hosting for high-traffic websites and e-commerce stores.', 
    'Ksh 5,000-10,000/month', 
    '50 GB', 
    'Unlimited', 
    20, 
    ARRAY['99.9% uptime guarantee', 'cPanel access', 'Free SSL certificate', 'Daily backups', '24/7 monitoring', 'CDN integration', 'Priority support', 'Malware scanning', 'Dedicated resources', 'DDoS protection', 'Performance optimization', 'Advanced security features'], 
    '24/7 phone, email, and chat support', 
    false, 
    true
  )
ON CONFLICT DO NOTHING;

-- Insert billing plans
INSERT INTO "billing_plans" ("name", "description", "frequency", "days_in_cycle")
VALUES 
  ('Monthly', 'Bill clients on a monthly basis', 'monthly', 30),
  ('Quarterly', 'Bill clients every three months', 'quarterly', 90),
  ('Biannually', 'Bill clients every six months', 'biannually', 180),
  ('Annually', 'Bill clients once a year', 'annually', 365)
ON CONFLICT DO NOTHING;

-- Insert reminder templates
INSERT INTO "reminder_templates" ("name", "type", "subject", "content", "days_offset")
VALUES 
  (
    'Upcoming Invoice Reminder - 7 Days', 
    'upcoming', 
    'Upcoming Invoice Reminder', 
    'Dear [Client Name],\n\nThis is a friendly reminder that invoice #[Invoice Number] for [Service] is due in 7 days. Please ensure timely payment to avoid any service interruptions.\n\nIf you have any questions, please don''t hesitate to contact us.\n\nBest regards,\nWeb Expert Solutions Team', 
    7
  ),
  (
    'Upcoming Invoice Reminder - 3 Days', 
    'upcoming', 
    'Upcoming Invoice Reminder', 
    'Dear [Client Name],\n\nThis is a friendly reminder that invoice #[Invoice Number] for [Service] is due in 3 days. Please ensure timely payment to avoid any service interruptions.\n\nIf you have any questions, please don''t hesitate to contact us.\n\nBest regards,\nWeb Expert Solutions Team', 
    3
  ),
  (
    'Upcoming Invoice Reminder - 1 Day', 
    'upcoming', 
    'Upcoming Invoice Reminder', 
    'Dear [Client Name],\n\nThis is a friendly reminder that invoice #[Invoice Number] for [Service] is due tomorrow. Please ensure timely payment to avoid any service interruptions.\n\nIf you have any questions, please don''t hesitate to contact us.\n\nBest regards,\nWeb Expert Solutions Team', 
    1
  ),
  (
    'Overdue Invoice Reminder - 1 Day', 
    'overdue', 
    'Overdue Invoice Reminder', 
    'Dear [Client Name],\n\nThis is a friendly reminder that invoice #[Invoice Number] for [Service] is now 1 day overdue. Please make your payment as soon as possible to avoid any service interruptions.\n\nIf you have any questions or need assistance with payment, please don''t hesitate to contact us.\n\nBest regards,\nWeb Expert Solutions Team', 
    1
  ),
  (
    'Overdue Invoice Reminder - 7 Days', 
    'overdue', 
    'Urgent: Overdue Invoice Reminder', 
    'Dear [Client Name],\n\nThis is an urgent reminder that invoice #[Invoice Number] for [Service] is now 7 days overdue. Please make your payment immediately to avoid service suspension.\n\nIf you have any questions or need assistance with payment, please don''t hesitate to contact us.\n\nBest regards,\nWeb Expert Solutions Team', 
    7
  ),
  (
    'Service Renewal Reminder - 30 Days', 
    'renewal', 
    'Service Renewal Reminder', 
    'Dear [Client Name],\n\nYour [Service] is due for renewal in 30 days. We hope you have been enjoying our services and would like to continue our partnership.\n\nA renewal invoice will be generated shortly. Please let us know if you have any questions or if there are any changes you''d like to make to your service.\n\nBest regards,\nWeb Expert Solutions Team', 
    30
  ),
  (
    'Service Renewal Reminder - 7 Days', 
    'renewal', 
    'Important: Service Renewal Reminder', 
    'Dear [Client Name],\n\nYour [Service] is due for renewal in 7 days. To ensure uninterrupted service, please make your payment before the expiration date.\n\nIf you have any questions or need assistance, please don''t hesitate to contact us.\n\nBest regards,\nWeb Expert Solutions Team', 
    7
  )
ON CONFLICT DO NOTHING;
`;

// Main function to run the migration
async function runMigration() {
  const client = await pool.connect();
  
  try {
    console.log('Starting database migration...');
    
    // Create tables
    console.log('Creating database tables...');
    await client.query(createTablesSql);
    console.log('Database tables created successfully.');
    
    // Insert default data
    console.log('Inserting default data...');
    await client.query(insertDataSql);
    console.log('Default data inserted successfully.');
    
    console.log('Migration completed successfully!');
  } catch (error) {
    console.error('Migration failed:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

// Run the migration
runMigration();