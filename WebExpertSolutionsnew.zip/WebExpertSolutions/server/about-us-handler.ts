import { db } from './db';
import { aboutUs, teamMembers } from '@shared/schema';
import { desc, eq } from 'drizzle-orm';

// Get the most recent About Us entry
export async function getAboutUsInfo() {
  try {
    const aboutUsData = await db.select().from(aboutUs).orderBy(desc(aboutUs.id)).limit(1);
    
    if (aboutUsData && aboutUsData.length > 0) {
      console.log("Successfully retrieved About Us data:", aboutUsData[0]);
      return aboutUsData[0];
    }
    
    console.log("No About Us data found");
    return {};
  } catch (error) {
    console.error("Error retrieving About Us data:", error);
    return {};
  }
}

// Get active team members
export async function getActiveTeamMembers() {
  try {
    const teamData = await db.select().from(teamMembers)
      .where(eq(teamMembers.isActive, true))
      .orderBy(teamMembers.order);
      
    return teamData;
  } catch (error) {
    console.error("Error retrieving team members:", error);
    return [];
  }
}