import { Router } from 'express';
import { IStorage } from '../storage';
import { BillingSystem } from '../billing-system';
import { 
  insertBillingPlanSchema, 
  insertReminderTemplateSchema, 
  insertRecurringInvoiceSchema 
} from '@shared/schema';
import { z } from 'zod';

export function createBillingRoutes(storage: IStorage) {
  const billingSystem = new BillingSystem(storage);
  const router = Router();

  // Middleware to check admin authorization
  const isAdmin = (req: any, res: any, next: any) => {
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    next();
  };

  // Billing Plans Routes
  router.get('/billing-plans', async (req, res) => {
    try {
      const billingPlans = await storage.getAllBillingPlans();
      res.status(200).json(billingPlans);
    } catch (error) {
      console.error('Error fetching billing plans:', error);
      res.status(500).json({ message: 'Error fetching billing plans' });
    }
  });

  router.post('/billing-plans', isAdmin, async (req, res) => {
    try {
      const billingPlanData = insertBillingPlanSchema.parse(req.body);
      const billingPlan = await storage.createBillingPlan(billingPlanData);
      res.status(201).json(billingPlan);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid data', errors: error.errors });
      }
      console.error('Error creating billing plan:', error);
      res.status(500).json({ message: 'Error creating billing plan' });
    }
  });

  router.put('/billing-plans/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const billingPlanData = insertBillingPlanSchema.parse(req.body);
      const updatedBillingPlan = await storage.updateBillingPlan(id, billingPlanData);
      
      if (!updatedBillingPlan) {
        return res.status(404).json({ message: 'Billing plan not found' });
      }
      
      res.status(200).json(updatedBillingPlan);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid data', errors: error.errors });
      }
      console.error('Error updating billing plan:', error);
      res.status(500).json({ message: 'Error updating billing plan' });
    }
  });

  router.delete('/billing-plans/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteBillingPlan(id);
      
      if (!deleted) {
        return res.status(404).json({ message: 'Billing plan not found' });
      }
      
      res.status(200).json({ message: 'Billing plan deleted successfully' });
    } catch (error) {
      console.error('Error deleting billing plan:', error);
      res.status(500).json({ message: 'Error deleting billing plan' });
    }
  });

  // Reminder Templates Routes
  router.get('/reminder-templates', isAdmin, async (req, res) => {
    try {
      const reminderTemplates = await storage.getAllReminderTemplates();
      res.status(200).json(reminderTemplates);
    } catch (error) {
      console.error('Error fetching reminder templates:', error);
      res.status(500).json({ message: 'Error fetching reminder templates' });
    }
  });

  router.get('/reminder-templates/:type', isAdmin, async (req, res) => {
    try {
      const type = req.params.type;
      const reminderTemplates = await storage.getReminderTemplatesByType(type);
      res.status(200).json(reminderTemplates);
    } catch (error) {
      console.error(`Error fetching reminder templates of type ${req.params.type}:`, error);
      res.status(500).json({ message: 'Error fetching reminder templates' });
    }
  });

  router.post('/reminder-templates', isAdmin, async (req, res) => {
    try {
      const reminderTemplateData = insertReminderTemplateSchema.parse(req.body);
      const reminderTemplate = await storage.createReminderTemplate(reminderTemplateData);
      res.status(201).json(reminderTemplate);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid data', errors: error.errors });
      }
      console.error('Error creating reminder template:', error);
      res.status(500).json({ message: 'Error creating reminder template' });
    }
  });

  router.put('/reminder-templates/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const reminderTemplateData = insertReminderTemplateSchema.parse(req.body);
      const updatedReminderTemplate = await storage.updateReminderTemplate(id, reminderTemplateData);
      
      if (!updatedReminderTemplate) {
        return res.status(404).json({ message: 'Reminder template not found' });
      }
      
      res.status(200).json(updatedReminderTemplate);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid data', errors: error.errors });
      }
      console.error('Error updating reminder template:', error);
      res.status(500).json({ message: 'Error updating reminder template' });
    }
  });

  router.delete('/reminder-templates/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteReminderTemplate(id);
      
      if (!deleted) {
        return res.status(404).json({ message: 'Reminder template not found' });
      }
      
      res.status(200).json({ message: 'Reminder template deleted successfully' });
    } catch (error) {
      console.error('Error deleting reminder template:', error);
      res.status(500).json({ message: 'Error deleting reminder template' });
    }
  });

  // Recurring Invoices Routes
  router.get('/recurring-invoices', isAdmin, async (req, res) => {
    try {
      const recurringInvoices = await storage.getActiveRecurringInvoices();
      res.status(200).json(recurringInvoices);
    } catch (error) {
      console.error('Error fetching recurring invoices:', error);
      res.status(500).json({ message: 'Error fetching recurring invoices' });
    }
  });

  router.get('/recurring-invoices/user/:userId', async (req, res) => {
    try {
      // Check if user is requesting their own invoices or if admin
      const requestedUserId = parseInt(req.params.userId);
      
      if (!req.session || !req.session.userId || 
          (req.session.role !== "admin" && req.session.userId !== requestedUserId)) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const recurringInvoices = await storage.getRecurringInvoicesByUserId(requestedUserId);
      res.status(200).json(recurringInvoices);
    } catch (error) {
      console.error('Error fetching user recurring invoices:', error);
      res.status(500).json({ message: 'Error fetching recurring invoices' });
    }
  });

  router.post('/recurring-invoices', isAdmin, async (req, res) => {
    try {
      const recurringInvoiceData = insertRecurringInvoiceSchema.parse(req.body);
      const recurringInvoice = await storage.createRecurringInvoice(recurringInvoiceData);
      res.status(201).json(recurringInvoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid data', errors: error.errors });
      }
      console.error('Error creating recurring invoice:', error);
      res.status(500).json({ message: 'Error creating recurring invoice' });
    }
  });

  router.put('/recurring-invoices/:id/status', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !['active', 'paused', 'cancelled'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status value' });
      }
      
      const updatedRecurringInvoice = await storage.updateRecurringInvoiceStatus(id, status);
      
      if (!updatedRecurringInvoice) {
        return res.status(404).json({ message: 'Recurring invoice not found' });
      }
      
      res.status(200).json(updatedRecurringInvoice);
    } catch (error) {
      console.error('Error updating recurring invoice status:', error);
      res.status(500).json({ message: 'Error updating recurring invoice status' });
    }
  });

  router.put('/recurring-invoices/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const recurringInvoiceData = insertRecurringInvoiceSchema.partial().parse(req.body);
      const updatedRecurringInvoice = await storage.updateRecurringInvoice(id, recurringInvoiceData);
      
      if (!updatedRecurringInvoice) {
        return res.status(404).json({ message: 'Recurring invoice not found' });
      }
      
      res.status(200).json(updatedRecurringInvoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid data', errors: error.errors });
      }
      console.error('Error updating recurring invoice:', error);
      res.status(500).json({ message: 'Error updating recurring invoice' });
    }
  });

  // Billing System Process Routes (admin only)
  router.post('/process/generate-invoices', isAdmin, async (req, res) => {
    try {
      const generatedInvoices = await billingSystem.generatePendingInvoices();
      res.status(200).json({ 
        success: true, 
        message: `Generated ${generatedInvoices.length} invoices from recurring billing plans`, 
        invoices: generatedInvoices 
      });
    } catch (error) {
      console.error('Error generating invoices:', error);
      res.status(500).json({ message: 'Error generating invoices from recurring billing plans' });
    }
  });

  router.post('/process/send-reminders', isAdmin, async (req, res) => {
    try {
      const result = await billingSystem.processReminders();
      res.status(200).json({ 
        success: true, 
        message: `Processed reminders: ${result.sent} sent, ${result.failed} failed`,
        ...result
      });
    } catch (error) {
      console.error('Error processing reminders:', error);
      res.status(500).json({ message: 'Error processing reminders' });
    }
  });

  // Analytics and Reporting Routes
  router.get('/analytics/overdue-invoices', isAdmin, async (req, res) => {
    try {
      const overdueInvoices = await billingSystem.getOverdueInvoices();
      res.status(200).json(overdueInvoices);
    } catch (error) {
      console.error('Error fetching overdue invoices:', error);
      res.status(500).json({ message: 'Error fetching overdue invoices' });
    }
  });

  router.get('/analytics/upcoming-invoices', isAdmin, async (req, res) => {
    try {
      const daysThreshold = req.query.days ? parseInt(req.query.days as string) : 7;
      const upcomingInvoices = await billingSystem.getUpcomingInvoices(daysThreshold);
      res.status(200).json(upcomingInvoices);
    } catch (error) {
      console.error('Error fetching upcoming invoices:', error);
      res.status(500).json({ message: 'Error fetching upcoming invoices' });
    }
  });

  router.get('/analytics/upcoming-renewals', isAdmin, async (req, res) => {
    try {
      const daysThreshold = req.query.days ? parseInt(req.query.days as string) : 7;
      const upcomingRenewals = await billingSystem.getRecurringInvoicesDueForRenewal(daysThreshold);
      res.status(200).json(upcomingRenewals);
    } catch (error) {
      console.error('Error fetching upcoming renewals:', error);
      res.status(500).json({ message: 'Error fetching upcoming renewals' });
    }
  });

  // Reminder Logs Routes
  router.get('/reminder-logs/invoice/:invoiceId', isAdmin, async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.invoiceId);
      const reminderLogs = await storage.getReminderLogsByInvoiceId(invoiceId);
      res.status(200).json(reminderLogs);
    } catch (error) {
      console.error('Error fetching reminder logs:', error);
      res.status(500).json({ message: 'Error fetching reminder logs' });
    }
  });

  router.get('/reminder-logs/user/:userId', async (req, res) => {
    try {
      // Check if user is requesting their own logs or if admin
      const requestedUserId = parseInt(req.params.userId);
      
      if (!req.session || !req.session.userId || 
          (req.session.role !== "admin" && req.session.userId !== requestedUserId)) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const reminderLogs = await storage.getReminderLogsByUserId(requestedUserId);
      res.status(200).json(reminderLogs);
    } catch (error) {
      console.error('Error fetching user reminder logs:', error);
      res.status(500).json({ message: 'Error fetching reminder logs' });
    }
  });

  return router;
}