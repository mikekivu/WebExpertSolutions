import { Router } from 'express';
import { db } from '../db';
import { desc, eq } from 'drizzle-orm';
import { aboutUs, teamMembers, insertAboutUsSchema } from '../../shared/schema';

export const aboutUsRoutes = Router();

// Get the About Us data from the database directly
aboutUsRoutes.get('/', async (req, res) => {
  try {
    const aboutUsData = await db.select().from(aboutUs).orderBy(desc(aboutUs.id)).limit(1);
    
    if (aboutUsData && aboutUsData.length > 0) {
      console.log("Direct fetch result for About Us:", aboutUsData[0]);
      return res.json(aboutUsData[0]);
    }
    
    console.log("No About Us data found");
    return res.json({});
  } catch (error) {
    console.error("Error fetching About Us data:", error);
    return res.status(500).json({ message: "Failed to fetch About Us data" });
  }
});

// Get active team members
aboutUsRoutes.get('/team-members', async (req, res) => {
  try {
    const teamMembersData = await db.select().from(teamMembers)
      .where(eq(teamMembers.isActive, true))
      .orderBy(teamMembers.order);
      
    return res.json(teamMembersData);
  } catch (error) {
    console.error("Error fetching team members:", error);
    return res.status(500).json({ message: "Failed to fetch team members" });
  }
});

// Admin: Create or update About Us data
aboutUsRoutes.post('/admin', async (req, res) => {
  if (!req.session || !req.session.userId || req.session.role !== "admin") {
    return res.status(403).json({ message: "Unauthorized" });
  }
  
  try {
    // First, let's delete any existing records
    await db.delete(aboutUs);
    
    // Then create a new record with the provided data
    const aboutUsData = insertAboutUsSchema.parse(req.body);
    const [newAboutUs] = await db.insert(aboutUs)
      .values({
        ...aboutUsData,
        updatedAt: new Date()
      })
      .returning();
      
    console.log("Successfully created new About Us record:", newAboutUs);
    return res.status(201).json(newAboutUs);
  } catch (error) {
    console.error("Error creating/updating About Us information:", error);
    return res.status(500).json({ message: "Failed to create/update About Us information" });
  }
});

// Admin: Get all team members
aboutUsRoutes.get('/admin/team-members', async (req, res) => {
  if (!req.session || !req.session.userId || req.session.role !== "admin") {
    return res.status(403).json({ message: "Unauthorized" });
  }
  
  try {
    const teamMembersData = await db.select().from(teamMembers)
      .orderBy(teamMembers.order);
      
    return res.json(teamMembersData);
  } catch (error) {
    console.error("Error fetching team members:", error);
    return res.status(500).json({ message: "Failed to fetch team members" });
  }
});