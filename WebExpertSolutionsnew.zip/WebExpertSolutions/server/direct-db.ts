import { db } from './db';
import { aboutUs, teamMembers } from '@shared/schema';
import { desc, eq } from 'drizzle-orm';

/**
 * Direct database access functions to bypass problematic storage implementation
 */

// Get About Us data from database
export async function getAboutUsData() {
  try {
    const result = await db.select().from(aboutUs).orderBy(desc(aboutUs.id)).limit(1);
    
    if (result && result.length > 0) {
      console.log("Direct DB: Successfully retrieved About Us data:", result[0]);
      return result[0];
    }
    
    console.log("Direct DB: No About Us data found");
    return null;
  } catch (error) {
    console.error("Direct DB: Error retrieving About Us data:", error);
    return null;
  }
}

// Get team members from database
export async function getTeamMembersData() {
  try {
    const result = await db.select().from(teamMembers)
      .where(eq(teamMembers.isActive, true))
      .orderBy(teamMembers.order);
    
    console.log(`Direct DB: Retrieved ${result.length} team members`);
    return result;
  } catch (error) {
    console.error("Direct DB: Error retrieving team members data:", error);
    return [];
  }
}