import { IStorage } from "./storage";
import { billingPlans, recurringInvoices, quotes, invoices, services, payments } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function initializeAnalyticsData(storage: IStorage) {
  try {
    console.log("Initializing sample analytics data...");
    
    // Add sample billing plans if none exist
    const existingPlans = await storage.getAllBillingPlans();
    let createdPlans = existingPlans;
    
    if (existingPlans.length === 0) {
      console.log("Creating sample billing plans...");
      
      const samplePlans = [
        {
          name: "Monthly Website Plan",
          description: "Monthly billing cycle for website hosting services",
          billingCycle: "monthly",
          daysUntilDue: 15,
          autoRenew: true
        },
        {
          name: "Quarterly Website Plan",
          description: "Quarterly billing cycle for website hosting services",
          billingCycle: "quarterly",
          daysUntilDue: 30,
          autoRenew: true
        },
        {
          name: "Annual Website Plan",
          description: "Annual billing cycle for website hosting services",
          billingCycle: "annual",
          daysUntilDue: 30,
          autoRenew: true
        }
      ];
      
      createdPlans = [];
      
      for (const plan of samplePlans) {
        const createdPlan = await storage.createBillingPlan(plan);
        createdPlans.push(createdPlan);
        console.log(`Created billing plan: ${plan.name}`);
      }
    } else {
      console.log(`Found ${existingPlans.length} existing billing plans, skipping creation`);
    }
    
    // Add sample recurring invoices if none exist
    const existingRecurringInvoices = await storage.getActiveRecurringInvoices();
    
    if (existingRecurringInvoices.length === 0) {
      console.log("Creating sample recurring invoices...");
      
      // Get users
      const users = await storage.getAllUsers();
      const adminUser = users.find(u => u.role === "admin") || users[0];
      const clientUsers = users.filter(u => u.role === "client" || u.id !== adminUser.id);
      
      // Get services
      const allServices = await storage.getAllServices();
      
      if (createdPlans.length > 0 && users.length > 0) {
        const sampleRecurringInvoices = [
          {
            userId: clientUsers[0]?.id || adminUser.id,
            serviceId: allServices[0]?.id,
            billingPlanId: createdPlans[0].id,
            amount: "1500.00",
            status: "active",
            items: [
              {
                name: "Website Hosting - Monthly",
                amount: "1500.00",
                quantity: 1
              }
            ],
            tax: "240.00",
            startDate: new Date(2023, 0, 1),
            nextBillingDate: new Date(2023, 5, 1)
          },
          {
            userId: clientUsers[1]?.id || clientUsers[0]?.id || adminUser.id,
            serviceId: allServices[0]?.id,
            billingPlanId: createdPlans[1].id, 
            amount: "4500.00",
            status: "active",
            items: [
              {
                name: "Website Hosting - Quarterly",
                amount: "4500.00",
                quantity: 1
              }
            ],
            tax: "720.00",
            startDate: new Date(2023, 0, 1),
            nextBillingDate: new Date(2023, 3, 1)
          },
          {
            userId: clientUsers[2]?.id || clientUsers[1]?.id || clientUsers[0]?.id || adminUser.id,
            serviceId: allServices[1]?.id || allServices[0]?.id,
            billingPlanId: createdPlans[2].id,
            amount: "15000.00",
            status: "active",
            items: [
              {
                name: "Website Hosting - Annual",
                amount: "15000.00",
                quantity: 1
              }
            ],
            tax: "2400.00",
            startDate: new Date(2023, 0, 1),
            nextBillingDate: new Date(2024, 0, 1)
          }
        ];
        
        for (const invoice of sampleRecurringInvoices) {
          if (invoice.serviceId) {
            await storage.createRecurringInvoice(invoice);
            console.log(`Created recurring invoice for billing plan: ${invoice.billingPlanId}`);
          }
        }
      }
    } else {
      console.log(`Found ${existingRecurringInvoices.length} existing recurring invoices, skipping creation`);
    }
    
    // Add some sample payment data for analytics
    const existingPayments = await storage.getAllPayments();
    
    if (existingPayments.length === 0) {
      console.log("Creating sample payments...");
      
      const allInvoices = await storage.getAllInvoices();
      
      if (allInvoices.length > 0) {
        // Create a few sample payments with different payment methods
        const paymentMethods = ["mpesa", "paypal", "bank_transfer", "cash"];
        const statuses = ["completed", "pending", "failed"];
        
        for (let i = 0; i < Math.min(allInvoices.length, 10); i++) {
          const invoice = allInvoices[i];
          const method = paymentMethods[i % paymentMethods.length];
          const status = statuses[Math.floor(Math.random() * statuses.length)];
          
          const payment = {
            invoiceId: invoice.id,
            amount: invoice.amount,
            method: method,
            transactionId: `TRANS${Date.now()}${i}`,
            status: status
          };
          
          await storage.createPayment(payment);
          console.log(`Created payment for invoice: ${invoice.id} with method: ${method}`);
          
          // Update invoice status for completed payments
          if (status === "completed") {
            await storage.updateInvoiceStatus(invoice.id, "paid");
          }
        }
      }
    } else {
      console.log(`Found ${existingPayments.length} existing payments, skipping creation`);
    }
    
    console.log("Sample analytics data initialization complete!");
    return { success: true, message: "Analytics data initialized successfully" };
  } catch (error) {
    console.error("Error initializing sample analytics data:", error);
    return { success: false, message: `Error initializing analytics data: ${error}` };
  }
}