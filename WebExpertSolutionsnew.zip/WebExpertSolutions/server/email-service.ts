import nodemailer from 'nodemailer';
import { ClientService, User, Service } from '@shared/schema';

// Create reusable transporter
let transporter: nodemailer.Transporter;

export const initializeEmailService = async () => {
  // First check if we have Gmail credentials
  if (process.env.GMAIL_USER && process.env.GMAIL_APP_PASSWORD) {
    // Use Gmail SMTP
    transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD,
      },
    });
    
    console.log('Email notification system initialized with Gmail');
  } else {
    // Fallback to Ethereal test account for development
    const testAccount = await nodemailer.createTestAccount();
    
    transporter = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: {
        user: testAccount.user,
        pass: testAccount.pass,
      },
    });
    
    console.log('Email service initialized with Ethereal test account (development only)');
    console.log(`Preview URL: https://ethereal.email/login (username: ${testAccount.user}, password: ${testAccount.pass})`);
  }
};

// Generic send email function
export const sendEmail = async (to: string, subject: string, html: string) => {
  if (!transporter) {
    await initializeEmailService();
  }
  
  const mailOptions = {
    from: `"Web Expert Solutions" <${process.env.GMAIL_USER || 'info@webexpertsolutions.co.ke'}>`,
    to,
    subject,
    html,
  };
  
  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`Email sent to ${to}: ${info.messageId}`);
    
    // Only show preview URL for Ethereal email service
    if (process.env.NODE_ENV !== 'production' && nodemailer.getTestMessageUrl) {
      const previewUrl = nodemailer.getTestMessageUrl(info);
      if (previewUrl) {
        console.log(`Preview URL: ${previewUrl}`);
        return { success: true, messageId: info.messageId, previewUrl };
      }
    }
    
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('Error sending email:', error);
    return { success: false, error };
  }
};

// Email templates
const getServiceOrderConfirmation = (clientName: string, service: Service) => {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #1a56db; color: white; padding: 20px; text-align: center;">
        <h1>Order Confirmation</h1>
      </div>
      <div style="padding: 20px; border: 1px solid #e2e8f0; border-top: none;">
        <p>Hello ${clientName},</p>
        <p>Thank you for ordering our <strong>${service.name}</strong> service.</p>
        
        <div style="background-color: #f7fafc; padding: 15px; margin: 20px 0; border-radius: 5px;">
          <h3 style="margin-top: 0;">Service Details</h3>
          <p><strong>Service:</strong> ${service.name}</p>
          <p><strong>Category:</strong> ${service.category}</p>
          <p><strong>Description:</strong> ${service.description}</p>
          <p><strong>Price:</strong> KSh ${service.price}</p>
        </div>
        
        <p>Our team will review your order and activate your service shortly. You will receive a notification once your service is active.</p>
        
        <p>If you have any questions, please contact our support team at support@webexpertsolutions.co.ke or call +254 112 345 366.</p>
        
        <p>Thank you for choosing Web Expert Solutions!</p>
        
        <p>Best regards,<br>Web Expert Solutions Team</p>
      </div>
      <div style="background-color: #f7fafc; padding: 10px; text-align: center; font-size: 12px; color: #718096;">
        <p>© 2025 Web Expert Solutions. All rights reserved.</p>
        <p>CBD, Nairobi, Kenya</p>
      </div>
    </div>
  `;
};

const getAdminOrderNotification = (clientName: string, clientEmail: string, service: Service) => {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #1a56db; color: white; padding: 20px; text-align: center;">
        <h1>New Service Order</h1>
      </div>
      <div style="padding: 20px; border: 1px solid #e2e8f0; border-top: none;">
        <p>Hello Admin,</p>
        <p>A new service has been ordered.</p>
        
        <div style="background-color: #f7fafc; padding: 15px; margin: 20px 0; border-radius: 5px;">
          <h3 style="margin-top: 0;">Order Details</h3>
          <p><strong>Client:</strong> ${clientName}</p>
          <p><strong>Email:</strong> ${clientEmail}</p>
          <p><strong>Service:</strong> ${service.name}</p>
          <p><strong>Category:</strong> ${service.category}</p>
          <p><strong>Price:</strong> KSh ${service.price}</p>
        </div>
        
        <p>Please review this order and activate the service in the admin dashboard.</p>
        
        <p>Best regards,<br>Web Expert Solutions System</p>
      </div>
      <div style="background-color: #f7fafc; padding: 10px; text-align: center; font-size: 12px; color: #718096;">
        <p>© 2025 Web Expert Solutions. All rights reserved.</p>
        <p>CBD, Nairobi, Kenya</p>
      </div>
    </div>
  `;
};

// Service activation notification
const getServiceActivationNotification = (clientName: string, service: Service) => {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #1a56db; color: white; padding: 20px; text-align: center;">
        <h1>Service Activated</h1>
      </div>
      <div style="padding: 20px; border: 1px solid #e2e8f0; border-top: none;">
        <p>Hello ${clientName},</p>
        <p>Great news! Your <strong>${service.name}</strong> service has been activated and is now ready to use.</p>
        
        <div style="background-color: #f7fafc; padding: 15px; margin: 20px 0; border-radius: 5px;">
          <h3 style="margin-top: 0;">Service Details</h3>
          <p><strong>Service:</strong> ${service.name}</p>
          <p><strong>Category:</strong> ${service.category}</p>
          <p><strong>Status:</strong> <span style="color: #0e9f6e; font-weight: bold;">Active</span></p>
        </div>
        
        <p>You can manage your service through your client dashboard. Log in to your account to access all features.</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="https://webexpertsolutions.co.ke/client/dashboard" style="background-color: #1a56db; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">Go to Dashboard</a>
        </div>
        
        <p>If you have any questions or need assistance, please contact our support team at support@webexpertsolutions.co.ke or call +254 112 345 366.</p>
        
        <p>Thank you for choosing Web Expert Solutions!</p>
        
        <p>Best regards,<br>Web Expert Solutions Team</p>
      </div>
      <div style="background-color: #f7fafc; padding: 10px; text-align: center; font-size: 12px; color: #718096;">
        <p>© 2025 Web Expert Solutions. All rights reserved.</p>
        <p>CBD, Nairobi, Kenya</p>
      </div>
    </div>
  `;
};

// Email notification functions
export const sendClientOrderConfirmation = async (user: User, service: Service) => {
  const clientName = user.fullName || user.username;
  const html = getServiceOrderConfirmation(clientName, service);
  
  console.log(`Attempting to send client notification to: ${user.email}`);
  const result = await sendEmail(user.email, `Order Confirmation: ${service.name}`, html);
  
  if (result.success) {
    console.log(`✅ Client notification successfully sent to: ${user.email}`);
  } else {
    console.error(`❌ Failed to send client notification to: ${user.email}`, result.error);
  }
  
  return result;
};

export const sendAdminOrderNotification = async (user: User, service: Service, adminEmail: string = 'webexpertkenya@gmail.com') => {
  const clientName = user.fullName || user.username;
  const html = getAdminOrderNotification(clientName, user.email, service);
  
  console.log(`Attempting to send admin notification to: ${adminEmail}`);
  const result = await sendEmail(adminEmail, `New Service Order: ${service.name}`, html);
  
  if (result.success) {
    console.log(`✅ Admin notification successfully sent to: ${adminEmail}`);
  } else {
    console.error(`❌ Failed to send admin notification to: ${adminEmail}`, result.error);
  }
  
  return result;
};

export const sendServiceActivationNotification = async (user: User, service: Service) => {
  const clientName = user.fullName || user.username;
  const html = getServiceActivationNotification(clientName, service);
  
  return await sendEmail(user.email, `Service Activated: ${service.name}`, html);
};