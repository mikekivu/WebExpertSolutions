import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";
import { initializeAnalyticsData } from "./init-analytics-data";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { BillingSystem } from "./billing-system";
import { createBillingRoutes } from "./routes/billing";
import { 
  initializeEmailService, 
  sendClientOrderConfirmation, 
  sendAdminOrderNotification,
  sendServiceActivationNotification
} from "./email-service";
import { 
  insertUserSchema, 
  insertQuoteRequestSchema, 
  insertServiceSchema, 
  insertQuoteSchema, 
  insertInvoiceSchema, 
  insertPaymentSchema, 
  insertPortfolioItemSchema, 
  insertTestimonialSchema, 
  insertEmailSchema, 
  insertClientServiceSchema,
  insertWebPackageSchema,
  insertHostingPackageSchema,
  insertBillingPlanSchema,
  insertReminderTemplateSchema,
  insertRecurringInvoiceSchema,
  insertReminderLogSchema,
  insertContactInfoSchema,
  insertAboutUsSchema,
  insertTeamMemberSchema,
  users,
  aboutUs,
  teamMembers
} from "@shared/schema";
import bcrypt from "bcryptjs";

// Mock M-Pesa transaction for now - in a real app this would use an actual API
const processMpesaPayment = async (phone: string, amount: number) => {
  return {
    success: true,
    transactionId: `MPESA${Date.now()}`,
    message: "Payment successful"
  };
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      // Get the data from the request
      const { username, email, password, fullName, phone, company } = req.body;
      
      console.log('Registration attempt for:', username, email);
      
      // Basic validation
      if (!username || !email || !password || !fullName) {
        return res.status(400).json({ message: "Username, email, password and full name are required" });
      }
      
      // Check if username or email already exists using direct database query
      const existingUsers = await db.select().from(users)
        .where(eq(users.username, username));
        
      const existingEmails = await db.select().from(users)
        .where(eq(users.email, email));
        
      if (existingUsers.length > 0 || existingEmails.length > 0) {
        return res.status(400).json({ message: "Username or email already exists" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Insert the user directly to the database
      const [user] = await db.insert(users)
        .values({
          username,
          email,
          password: hashedPassword,
          fullName,
          role: 'client', // Default role is client
          phone: phone || null,
          company: company || null
        })
        .returning();
      
      // Log successful registration
      console.log('User registered successfully:', username, email, 'with ID:', user.id);
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      // Auto-login after registration
      if (req.session) {
        req.session.userId = user.id;
        req.session.role = user.role;
      }
      
      res.status(201).json({ 
        message: "User registered successfully",
        user: userWithoutPassword
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ message: "Server error during registration" });
    }
  });
  
  app.post("/api/auth/login", async (req, res) => {
    try {
      // Get login info from request
      const { username, password } = req.body;
      
      console.log(`Login attempt with username: ${username}`);
      
      // Validate input
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      // First, check if the user is trying to log in with email as username
      let user = null;
      
      // Check if username is actually an email
      if (username.includes('@')) {
        console.log(`Login attempt using email: ${username}`);
        // Query by email
        const results = await db.select().from(users).where(eq(users.email, username));
        if (results.length > 0) {
          user = results[0];
        }
      } else {
        // Try to get user by username
        const results = await db.select().from(users).where(eq(users.username, username));
        if (results.length > 0) {
          user = results[0];
        }
      }
      
      // If no user found
      if (!user) {
        console.log(`No user found with username/email: ${username}`);
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      console.log(`User found: ${user.username}, attempting password verification`);
      
      // Verify password
      const isPasswordValid = await bcrypt.compare(password, user.password);
      
      if (!isPasswordValid) {
        console.log(`Password validation failed for: ${username}`);
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Create session
      if (!req.session) {
        return res.status(500).json({ message: "Session not available" });
      }
      
      // Save session data - this is critical for login
      req.session.userId = user.id;
      req.session.role = user.role;
      req.session.authenticated = true;
      
      // This ensures the session is saved to the database immediately
      await new Promise((resolve) => {
        req.session.save((err) => {
          if (err) {
            console.error("Session save error:", err);
          }
          resolve(true);
        });
      });
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      console.log(`Login successful for: ${username}, role: ${user.role}, session ID: ${req.sessionID}`);
      
      res.status(200).json({
        message: "Login successful",
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Server error during login" });
    }
  });
  
  app.get("/api/auth/session", async (req, res) => {
    if (!req.session || !req.session.userId) {
      console.log("Session check: No userId in session");
      return res.status(401).json({ authenticated: false });
    }
    
    try {
      console.log("Session check: Fetching user with ID:", req.session.userId);
      
      // Direct DB query to ensure we're getting the right data
      const [user] = await db.select().from(users).where(eq(users.id, req.session.userId));
      
      if (!user) {
        console.log("Session check: User not found in database");
        req.session.destroy(() => {});
        return res.status(401).json({ authenticated: false });
      }
      
      console.log("Session check: User found, authenticated:", user.username);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.status(200).json({
        authenticated: true,
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Session check error:", error);
      res.status(500).json({ message: "Server error checking session" });
    }
  });
  
  app.post("/api/auth/logout", (req, res) => {
    if (req.session) {
      req.session.destroy(() => {
        res.status(200).json({ message: "Logged out successfully" });
      });
    } else {
      res.status(200).json({ message: "Already logged out" });
    }
  });
  
  // Quote Request routes
  app.post("/api/quote-requests", async (req, res) => {
    try {
      // Extract account creation fields from the request
      const { 
        createAccount, 
        password,
        company,
        ...quoteRequestFields 
      } = req.body;
      
      // Parse the basic quote request data
      const quoteRequestData = insertQuoteRequestSchema.parse(quoteRequestFields);
      
      // Create the quote request
      const quoteRequest = await storage.createQuoteRequest(quoteRequestData);
      
      let userId = null;
      
      // If createAccount is true, create a new user account
      if (createAccount && password) {
        try {
          // Generate a username from the email (before the @ symbol)
          const emailUsername = quoteRequestData.email.split('@')[0];
          const username = emailUsername.replace(/[^a-zA-Z0-9]/g, '') + 
                          Math.floor(Math.random() * 1000).toString();
          
          // Hash password
          const hashedPassword = await bcrypt.hash(password, 10);
          
          // Create new user
          const newUser = await storage.createUser({
            username,
            email: quoteRequestData.email,
            password: hashedPassword,
            fullName: quoteRequestData.name,
            role: 'client',
            phone: quoteRequestData.phone || null,
            company: company || null
          });
          
          userId = newUser.id;
          
          // Auto-login the new user
          if (req.session) {
            req.session.userId = newUser.id;
            req.session.role = newUser.role;
          }
          
          console.log(`New user created from quote request: ${username} (ID: ${newUser.id})`);
        } catch (userError) {
          console.error("Error creating user from quote request:", userError);
          // Continue with the quote request even if user creation fails
        }
      }
      
      res.status(201).json({
        ...quoteRequest,
        userCreated: !!userId,
        userId
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating quote request:", error);
      res.status(500).json({ message: "Server error creating quote request" });
    }
  });
  
  app.get("/api/quote-requests", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const quoteRequests = await storage.getAllQuoteRequests();
      res.status(200).json(quoteRequests);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching quote requests" });
    }
  });
  
  app.get("/api/quote-requests/:id", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const quoteRequest = await storage.getQuoteRequest(id);
      
      if (!quoteRequest) {
        return res.status(404).json({ message: "Quote request not found" });
      }
      
      res.status(200).json(quoteRequest);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching quote request" });
    }
  });
  
  app.patch("/api/quote-requests/:id", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !["pending", "reviewed", "quoted", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const updatedQuoteRequest = await storage.updateQuoteRequestStatus(id, status);
      
      if (!updatedQuoteRequest) {
        return res.status(404).json({ message: "Quote request not found" });
      }
      
      res.status(200).json(updatedQuoteRequest);
    } catch (error) {
      res.status(500).json({ message: "Server error updating quote request" });
    }
  });
  
  // Service routes
  app.post("/api/services", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const serviceData = insertServiceSchema.parse(req.body);
      const service = await storage.createService(serviceData);
      res.status(201).json(service);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error creating service" });
    }
  });
  
  app.get("/api/services", async (req, res) => {
    try {
      const services = await storage.getAllServices();
      res.status(200).json(services);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching services" });
    }
  });
  
  app.get("/api/services/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const service = await storage.getService(id);
      
      if (!service) {
        return res.status(404).json({ message: "Service not found" });
      }
      
      res.status(200).json(service);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching service" });
    }
  });
  
  app.get("/api/services/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const services = await storage.getServicesByCategory(category);
      res.status(200).json(services);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching services by category" });
    }
  });
  
  // Client Services routes
  app.post("/api/client-services", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const clientServiceData = insertClientServiceSchema.parse(req.body);
      
      // If admin, allow setting userId, otherwise use the session userId
      if (req.session.role !== "admin" && clientServiceData.userId !== req.session.userId) {
        return res.status(403).json({ message: "Cannot create services for other users" });
      }
      
      // Create the client service
      const clientService = await storage.createClientService(clientServiceData);
      
      // Get the user and service details for email notifications
      const user = await storage.getUser(clientServiceData.userId);
      const service = await storage.getService(clientServiceData.serviceId);
      
      if (user && service) {
        // Send email notifications
        try {
          // Initialize email service if not already initialized
          await initializeEmailService();
          
          // Send confirmation to client
          const clientResult = await sendClientOrderConfirmation(user, service);
          
          // Send notification to admin (explicitly set the admin email)
          const adminResult = await sendAdminOrderNotification(user, service, 'webexpertkenya@gmail.com');
          
          console.log(`Order notification summary for ${service.name}:`);
          console.log(`- Client email (${user.email}): ${clientResult.success ? 'Sent ✓' : 'Failed ✗'}`);
          console.log(`- Admin email (webexpertkenya@gmail.com): ${adminResult.success ? 'Sent ✓' : 'Failed ✗'}`);
          
          if (!adminResult.success) {
            console.error('Admin notification error details:', adminResult.error);
          }
        } catch (emailError) {
          console.error("Failed to send service order email notifications:", emailError);
          console.error(emailError);
        }
      }
      
      // Return the created client service
      res.status(201).json(clientService);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Server error creating client service:", error);
      res.status(500).json({ message: "Server error creating client service" });
    }
  });
  
  app.get("/api/client-services/user/:userId", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const userId = parseInt(req.params.userId);
      
      // If not admin, can only view own services
      if (req.session.role !== "admin" && userId !== req.session.userId) {
        return res.status(403).json({ message: "Cannot view services for other users" });
      }
      
      // Get client services for this user
      const clientServices = await storage.getClientServicesByUserId(userId);
      
      // Return client services only (temporarily disabled quote requests due to schema issue)
      res.status(200).json(clientServices);
    } catch (error) {
      console.error("Server error fetching client services and quotes:", error);
      res.status(500).json({ message: "Server error fetching client services" });
    }
  });
  
  app.get("/api/client-services", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      // For analytics, we need all client services
      const clientServices = await storage.getAllClientServices();
      res.status(200).json(clientServices);
    } catch (error) {
      console.error("Error fetching all client services:", error);
      res.status(500).json({ message: "Error fetching all client services" });
    }
  });
  
  // Update client service status
  app.patch("/api/client-services/:id/status", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !["active", "inactive", "suspended", "expired", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      // Get the client service before updating to check if status is changing to active
      const clientService = await storage.getClientService(id);
      
      if (!clientService) {
        return res.status(404).json({ message: "Client service not found" });
      }
      
      // Update the client service status
      const updatedClientService = await storage.updateClientServiceStatus(id, status);
      
      // If status is changing to "active", send an activation notification to the client
      if (status === "active" && clientService.status !== "active") {
        try {
          // Get the user and service information for the email
          const user = await storage.getUser(clientService.userId);
          const service = await storage.getService(clientService.serviceId);
          
          if (user && service) {
            // Initialize email service if not already initialized
            await initializeEmailService();
            
            // Send activation notification to the client
            await sendServiceActivationNotification(user, service);
            
            console.log(`Service activation notification sent for ${service.name} to ${user.email}`);
          }
        } catch (emailError) {
          console.error("Failed to send service activation email notification:", emailError);
          // Continue processing even if email fails
        }
      }
      
      res.status(200).json(updatedClientService);
    } catch (error) {
      console.error("Server error updating client service status:", error);
      res.status(500).json({ message: "Server error updating client service status" });
    }
  });
  
  // Payment routes
  app.get("/api/payments", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const payments = await storage.getAllPayments();
      res.status(200).json(payments);
    } catch (error) {
      console.error("Error fetching payments:", error);
      res.status(500).json({ message: "Error fetching payments" });
    }
  });
  
  app.get("/api/payments/:id", async (req, res) => {
    try {
      const payment = await storage.getPayment(parseInt(req.params.id));
      if (!payment) {
        return res.status(404).json({ message: "Payment not found" });
      }
      
      // Fetch related invoice to check permission
      const invoice = await storage.getInvoice(payment.invoiceId);
      if (!invoice) {
        return res.status(404).json({ message: "Related invoice not found" });
      }
      
      // Only admin or invoice owner can view payment
      if (req.session?.role !== "admin" && req.session?.userId !== invoice.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      res.status(200).json(payment);
    } catch (error) {
      console.error("Error fetching payment:", error);
      res.status(500).json({ message: "Error fetching payment" });
    }
  });
  
  app.get("/api/invoices/:invoiceId/payments", async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.invoiceId);
      
      // Fetch invoice to check permission
      const invoice = await storage.getInvoice(invoiceId);
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      // Only admin or invoice owner can view payments
      if (req.session?.role !== "admin" && req.session?.userId !== invoice.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const payments = await storage.getPaymentsByInvoiceId(invoiceId);
      res.status(200).json(payments);
    } catch (error) {
      console.error("Error fetching invoice payments:", error);
      res.status(500).json({ message: "Error fetching invoice payments" });
    }
  });
  
  // Quote routes
  app.post("/api/quotes", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const quoteData = insertQuoteSchema.parse(req.body);
      const quote = await storage.createQuote(quoteData);
      res.status(201).json(quote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error creating quote" });
    }
  });
  
  app.get("/api/quotes/user/:userId", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const userId = parseInt(req.params.userId);
      
      // If not admin, can only view own quotes
      if (req.session.role !== "admin" && userId !== req.session.userId) {
        return res.status(403).json({ message: "Cannot view quotes for other users" });
      }
      
      const quotes = await storage.getQuotesByUserId(userId);
      res.status(200).json(quotes);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching quotes" });
    }
  });
  
  // Invoice routes
  app.post("/api/invoices", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const invoiceData = insertInvoiceSchema.parse(req.body);
      
      // Generate invoice number (INV-YYYYMMDD-XXXX)
      const date = new Date();
      const dateString = date.toISOString().slice(0, 10).replace(/-/g, "");
      const randomString = Math.floor(1000 + Math.random() * 9000).toString();
      const invoiceNumber = `INV-${dateString}-${randomString}`;
      
      const invoice = await storage.createInvoice({
        ...invoiceData,
        invoiceNumber
      });
      
      res.status(201).json(invoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error creating invoice" });
    }
  });
  
  app.get("/api/invoices/user/:userId", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const userId = parseInt(req.params.userId);
      
      // If not admin, can only view own invoices
      if (req.session.role !== "admin" && userId !== req.session.userId) {
        return res.status(403).json({ message: "Cannot view invoices for other users" });
      }
      
      const invoices = await storage.getInvoicesByUserId(userId);
      res.status(200).json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching invoices" });
    }
  });
  
  app.get("/api/invoices/:id", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const invoice = await storage.getInvoice(id);
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      // If not admin, can only view own invoices
      if (req.session.role !== "admin" && invoice.userId !== req.session.userId) {
        return res.status(403).json({ message: "Cannot view invoices for other users" });
      }
      
      res.status(200).json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching invoice" });
    }
  });
  
  // Payment routes
  app.post("/api/payments/mpesa", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const { invoiceId, phone, amount } = req.body;
      
      if (!invoiceId || !phone || !amount) {
        return res.status(400).json({ message: "Invoice ID, phone number, and amount are required" });
      }
      
      // Get invoice
      const invoice = await storage.getInvoice(parseInt(invoiceId));
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      // If not admin, can only pay own invoices
      if (req.session.role !== "admin" && invoice.userId !== req.session.userId) {
        return res.status(403).json({ message: "Cannot pay invoices for other users" });
      }
      
      // Process M-Pesa payment (mock for now)
      const paymentResult = await processMpesaPayment(phone, parseFloat(amount));
      
      if (!paymentResult.success) {
        return res.status(400).json({ message: paymentResult.message });
      }
      
      // Record payment
      const payment = await storage.createPayment({
        invoiceId: parseInt(invoiceId),
        amount: amount,
        method: "mpesa",
        transactionId: paymentResult.transactionId
      });
      
      // Update invoice status
      await storage.updateInvoiceStatus(parseInt(invoiceId), "paid");
      
      res.status(201).json({
        payment,
        message: "Payment successful"
      });
    } catch (error) {
      res.status(500).json({ message: "Server error processing payment" });
    }
  });
  
  // Portfolio routes
  app.post("/api/portfolio", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const portfolioItemData = insertPortfolioItemSchema.parse(req.body);
      const portfolioItem = await storage.createPortfolioItem(portfolioItemData);
      res.status(201).json(portfolioItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error creating portfolio item" });
    }
  });
  
  app.get("/api/portfolio", async (req, res) => {
    try {
      const portfolioItems = await storage.getAllPortfolioItems();
      res.status(200).json(portfolioItems);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching portfolio items" });
    }
  });
  
  app.get("/api/portfolio/featured", async (req, res) => {
    try {
      const featuredItems = await storage.getFeaturedPortfolioItems();
      res.status(200).json(featuredItems);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching featured portfolio items" });
    }
  });
  
  // Testimonial routes
  app.post("/api/testimonials", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const testimonialData = insertTestimonialSchema.parse(req.body);
      const testimonial = await storage.createTestimonial(testimonialData);
      res.status(201).json(testimonial);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error creating testimonial" });
    }
  });
  
  app.get("/api/testimonials", async (req, res) => {
    try {
      const testimonials = await storage.getActiveTestimonials();
      res.status(200).json(testimonials);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching testimonials" });
    }
  });
  
  // Email clients routes
  app.post("/api/emails", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const emailData = insertEmailSchema.parse({
        ...req.body,
        sentBy: req.session.userId
      });
      
      const email = await storage.createEmail(emailData);
      
      // Here you would implement actual email sending functionality
      // For now, we just record the email in the database
      
      res.status(201).json({
        email,
        message: "Email sent successfully"
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error sending email" });
    }
  });
  
  // User routes
  app.get("/api/users", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const users = await storage.getAllUsers();
      
      // Remove passwords from response
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.status(200).json(usersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching users" });
    }
  });
  
  app.get("/api/users/:id", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = parseInt(req.params.id);
      
      // If not admin, can only view own user
      if (req.session.role !== "admin" && id !== req.session.userId) {
        return res.status(403).json({ message: "Cannot view other users" });
      }
      
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Server error fetching user" });
    }
  });
  
  // PayPal integration routes
  app.get("/paypal/setup", async (req, res) => {
    await loadPaypalDefault(req, res);
  });

  app.post("/paypal/order", async (req, res) => {
    await createPaypalOrder(req, res);
  });

  app.post("/paypal/order/:orderID/capture", async (req, res) => {
    await capturePaypalOrder(req, res);
  });

  // Web Packages routes
  app.get("/api/web-packages", async (req, res) => {
    try {
      const packages = await storage.getAllWebPackages();
      res.status(200).json(packages);
    } catch (error) {
      console.error("Error fetching web packages:", error);
      res.status(500).json({ message: "Server error fetching web packages" });
    }
  });
  
  // Hosting Packages routes
  app.get("/api/hosting-packages", async (req, res) => {
    try {
      const packages = await storage.getAllHostingPackages();
      res.status(200).json(packages);
    } catch (error) {
      console.error("Error fetching hosting packages:", error);
      res.status(500).json({ message: "Server error fetching hosting packages" });
    }
  });
  
  app.get("/api/web-packages/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const webPackage = await storage.getWebPackage(id);
      
      if (!webPackage) {
        return res.status(404).json({ message: "Web package not found" });
      }
      
      res.status(200).json(webPackage);
    } catch (error) {
      console.error("Error fetching web package:", error);
      res.status(500).json({ message: "Server error fetching web package" });
    }
  });
  
  app.get("/api/hosting-packages/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const hostingPackage = await storage.getHostingPackage(id);
      
      if (!hostingPackage) {
        return res.status(404).json({ message: "Hosting package not found" });
      }
      
      res.status(200).json(hostingPackage);
    } catch (error) {
      console.error("Error fetching hosting package:", error);
      res.status(500).json({ message: "Server error fetching hosting package" });
    }
  });
  
  app.post("/api/web-packages", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const packageData = insertWebPackageSchema.parse(req.body);
      const webPackage = await storage.createWebPackage(packageData);
      res.status(201).json(webPackage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating web package:", error);
      res.status(500).json({ message: "Server error creating web package" });
    }
  });
  
  app.put("/api/web-packages/:id", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const packageData = insertWebPackageSchema.parse(req.body);
      
      const updatedPackage = await storage.updateWebPackage(id, packageData);
      
      if (!updatedPackage) {
        return res.status(404).json({ message: "Web package not found" });
      }
      
      res.status(200).json(updatedPackage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error updating web package:", error);
      res.status(500).json({ message: "Server error updating web package" });
    }
  });
  
  app.delete("/api/web-packages/:id", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteWebPackage(id);
      
      if (!success) {
        return res.status(404).json({ message: "Web package not found" });
      }
      
      res.status(200).json({ message: "Web package deleted successfully" });
    } catch (error) {
      console.error("Error deleting web package:", error);
      res.status(500).json({ message: "Server error deleting web package" });
    }
  });
  
  // Hosting Packages routes
  app.get("/api/hosting-packages", async (req, res) => {
    try {
      const packages = await storage.getAllHostingPackages();
      res.status(200).json(packages);
    } catch (error) {
      console.error("Error fetching hosting packages:", error);
      res.status(500).json({ message: "Server error fetching hosting packages" });
    }
  });
  
  app.get("/api/hosting-packages/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const hostingPackage = await storage.getHostingPackage(id);
      
      if (!hostingPackage) {
        return res.status(404).json({ message: "Hosting package not found" });
      }
      
      res.status(200).json(hostingPackage);
    } catch (error) {
      console.error("Error fetching hosting package:", error);
      res.status(500).json({ message: "Server error fetching hosting package" });
    }
  });
  
  app.post("/api/hosting-packages", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const packageData = insertHostingPackageSchema.parse(req.body);
      const hostingPackage = await storage.createHostingPackage(packageData);
      res.status(201).json(hostingPackage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating hosting package:", error);
      res.status(500).json({ message: "Server error creating hosting package" });
    }
  });
  
  app.put("/api/hosting-packages/:id", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const packageData = insertHostingPackageSchema.parse(req.body);
      
      const updatedPackage = await storage.updateHostingPackage(id, packageData);
      
      if (!updatedPackage) {
        return res.status(404).json({ message: "Hosting package not found" });
      }
      
      res.status(200).json(updatedPackage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error updating hosting package:", error);
      res.status(500).json({ message: "Server error updating hosting package" });
    }
  });
  
  app.delete("/api/hosting-packages/:id", async (req, res) => {
    // Check authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteHostingPackage(id);
      
      if (!success) {
        return res.status(404).json({ message: "Hosting package not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting hosting package:", error);
      res.status(500).json({ message: "Server error deleting hosting package" });
    }
  });
  
  // Automated Billing and Reminder System routes
  
  // Billing Plans
  app.get("/api/billing-plans", async (req, res) => {
    try {
      const billingPlans = await storage.getAllBillingPlans();
      res.status(200).json(billingPlans);
    } catch (error) {
      console.error("Error fetching billing plans:", error);
      res.status(500).json({ message: "Error fetching billing plans" });
    }
  });
  
  app.get("/api/billing-plans/:id", async (req, res) => {
    try {
      const billingPlan = await storage.getBillingPlan(parseInt(req.params.id));
      if (!billingPlan) {
        return res.status(404).json({ message: "Billing plan not found" });
      }
      res.status(200).json(billingPlan);
    } catch (error) {
      console.error("Error fetching billing plan:", error);
      res.status(500).json({ message: "Error fetching billing plan" });
    }
  });
  
  app.post("/api/billing-plans", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const billingPlanData = insertBillingPlanSchema.parse(req.body);
      const billingPlan = await storage.createBillingPlan(billingPlanData);
      res.status(201).json(billingPlan);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating billing plan:", error);
      res.status(500).json({ message: "Error creating billing plan" });
    }
  });
  
  app.put("/api/billing-plans/:id", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const billingPlanData = insertBillingPlanSchema.parse(req.body);
      const billingPlan = await storage.updateBillingPlan(parseInt(req.params.id), billingPlanData);
      if (!billingPlan) {
        return res.status(404).json({ message: "Billing plan not found" });
      }
      res.status(200).json(billingPlan);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error updating billing plan:", error);
      res.status(500).json({ message: "Error updating billing plan" });
    }
  });
  
  app.delete("/api/billing-plans/:id", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const success = await storage.deleteBillingPlan(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ message: "Billing plan not found" });
      }
      res.status(200).json({ message: "Billing plan deleted successfully" });
    } catch (error) {
      console.error("Error deleting billing plan:", error);
      res.status(500).json({ message: "Error deleting billing plan" });
    }
  });
  
  // Reminder Templates
  app.get("/api/reminder-templates", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const reminderTemplates = await storage.getAllReminderTemplates();
      res.status(200).json(reminderTemplates);
    } catch (error) {
      console.error("Error fetching reminder templates:", error);
      res.status(500).json({ message: "Error fetching reminder templates" });
    }
  });
  
  app.get("/api/reminder-templates/:id", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const reminderTemplate = await storage.getReminderTemplate(parseInt(req.params.id));
      if (!reminderTemplate) {
        return res.status(404).json({ message: "Reminder template not found" });
      }
      res.status(200).json(reminderTemplate);
    } catch (error) {
      console.error("Error fetching reminder template:", error);
      res.status(500).json({ message: "Error fetching reminder template" });
    }
  });
  
  app.post("/api/reminder-templates", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const reminderTemplateData = insertReminderTemplateSchema.parse(req.body);
      const reminderTemplate = await storage.createReminderTemplate(reminderTemplateData);
      res.status(201).json(reminderTemplate);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating reminder template:", error);
      res.status(500).json({ message: "Error creating reminder template" });
    }
  });
  
  app.put("/api/reminder-templates/:id", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const reminderTemplateData = insertReminderTemplateSchema.parse(req.body);
      const reminderTemplate = await storage.updateReminderTemplate(parseInt(req.params.id), reminderTemplateData);
      if (!reminderTemplate) {
        return res.status(404).json({ message: "Reminder template not found" });
      }
      res.status(200).json(reminderTemplate);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error updating reminder template:", error);
      res.status(500).json({ message: "Error updating reminder template" });
    }
  });
  
  app.delete("/api/reminder-templates/:id", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const success = await storage.deleteReminderTemplate(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ message: "Reminder template not found" });
      }
      res.status(200).json({ message: "Reminder template deleted successfully" });
    } catch (error) {
      console.error("Error deleting reminder template:", error);
      res.status(500).json({ message: "Error deleting reminder template" });
    }
  });
  
  // Recurring Invoices
  app.get("/api/recurring-invoices", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const recurringInvoices = await storage.getActiveRecurringInvoices();
      res.status(200).json(recurringInvoices);
    } catch (error) {
      console.error("Error fetching recurring invoices:", error);
      res.status(500).json({ message: "Error fetching recurring invoices" });
    }
  });
  
  app.get("/api/recurring-invoices/user", async (req, res) => {
    // Check authentication
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const recurringInvoices = await storage.getRecurringInvoicesByUserId(req.session.userId);
      res.status(200).json(recurringInvoices);
    } catch (error) {
      console.error("Error fetching user's recurring invoices:", error);
      res.status(500).json({ message: "Error fetching recurring invoices" });
    }
  });
  
  app.get("/api/recurring-invoices/:id", async (req, res) => {
    try {
      const recurringInvoice = await storage.getRecurringInvoice(parseInt(req.params.id));
      if (!recurringInvoice) {
        return res.status(404).json({ message: "Recurring invoice not found" });
      }
      
      // Check authorization - only admin or invoice owner can view
      if (!req.session || !req.session.userId || 
          (req.session.role !== "admin" && req.session.userId !== recurringInvoice.userId)) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      res.status(200).json(recurringInvoice);
    } catch (error) {
      console.error("Error fetching recurring invoice:", error);
      res.status(500).json({ message: "Error fetching recurring invoice" });
    }
  });
  
  app.post("/api/recurring-invoices", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const recurringInvoiceData = insertRecurringInvoiceSchema.parse(req.body);
      const recurringInvoice = await storage.createRecurringInvoice(recurringInvoiceData);
      res.status(201).json(recurringInvoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating recurring invoice:", error);
      res.status(500).json({ message: "Error creating recurring invoice" });
    }
  });
  
  app.put("/api/recurring-invoices/:id", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      // Only allow partial updates
      const recurringInvoiceData = req.body;
      const recurringInvoice = await storage.updateRecurringInvoice(parseInt(req.params.id), recurringInvoiceData);
      if (!recurringInvoice) {
        return res.status(404).json({ message: "Recurring invoice not found" });
      }
      res.status(200).json(recurringInvoice);
    } catch (error) {
      console.error("Error updating recurring invoice:", error);
      res.status(500).json({ message: "Error updating recurring invoice" });
    }
  });
  
  app.put("/api/recurring-invoices/:id/status", async (req, res) => {
    // Check admin authorization or owner
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const recurringInvoice = await storage.getRecurringInvoice(parseInt(req.params.id));
      if (!recurringInvoice) {
        return res.status(404).json({ message: "Recurring invoice not found" });
      }
      
      // Only admin or invoice owner can update status
      if (req.session.role !== "admin" && req.session.userId !== recurringInvoice.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const { status } = req.body;
      if (!status || !["active", "paused", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const updatedInvoice = await storage.updateRecurringInvoiceStatus(parseInt(req.params.id), status);
      res.status(200).json(updatedInvoice);
    } catch (error) {
      console.error("Error updating recurring invoice status:", error);
      res.status(500).json({ message: "Error updating recurring invoice status" });
    }
  });
  
  // Overdue and upcoming invoices
  app.get("/api/invoices/overdue", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const overdueInvoices = await storage.getOverdueInvoices();
      res.status(200).json(overdueInvoices);
    } catch (error) {
      console.error("Error fetching overdue invoices:", error);
      res.status(500).json({ message: "Error fetching overdue invoices" });
    }
  });
  
  app.get("/api/invoices/upcoming", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const daysThreshold = req.query.days ? parseInt(req.query.days as string) : 7;
      const upcomingInvoices = await storage.getUpcomingInvoices(daysThreshold);
      res.status(200).json(upcomingInvoices);
    } catch (error) {
      console.error("Error fetching upcoming invoices:", error);
      res.status(500).json({ message: "Error fetching upcoming invoices" });
    }
  });
  
  // Service for scheduling and sending automated reminders
  app.post("/api/reminders/send", async (req, res) => {
    // This endpoint should be triggered by a cron job or similar mechanism
    // to send automated reminders for overdue and upcoming invoices
    
    // Check for special API key for automation (separate from admin login)
    const apiKey = req.headers['x-api-key'];
    if (!apiKey || apiKey !== process.env.AUTOMATION_API_KEY) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      // Process overdue invoices
      const overdueInvoices = await storage.getOverdueInvoices();
      
      // Process upcoming invoices (7 days in advance)
      const upcomingInvoices = await storage.getUpcomingInvoices(7);
      
      // Process recurring invoices due for renewal (14 days in advance)
      const renewalInvoices = await storage.getRecurringInvoicesDueForRenewal(14);
      
      // For each invoice, find appropriate reminder template and send email (simulate for now)
      let remindersSent = 0;
      
      // Get templates
      const overdueTemplates = await storage.getReminderTemplatesByType('overdue');
      const upcomingTemplates = await storage.getReminderTemplatesByType('upcoming');
      const renewalTemplates = await storage.getReminderTemplatesByType('renewal');
      
      // Process overdue reminders
      if (overdueTemplates.length > 0 && overdueInvoices.length > 0) {
        const template = overdueTemplates[0]; // Use first available template
        
        for (const invoice of overdueInvoices) {
          // Create reminder log
          await storage.createReminderLog({
            userId: invoice.userId,
            invoiceId: invoice.id,
            templateId: template.id,
            status: 'sent'
          });
          
          remindersSent++;
          
          // In a real implementation, would send an actual email here
          console.log(`Sent overdue reminder for invoice #${invoice.invoiceNumber} to user ${invoice.userId}`);
        }
      }
      
      // Process upcoming reminders
      if (upcomingTemplates.length > 0 && upcomingInvoices.length > 0) {
        const template = upcomingTemplates[0]; // Use first available template
        
        for (const invoice of upcomingInvoices) {
          // Create reminder log
          await storage.createReminderLog({
            userId: invoice.userId,
            invoiceId: invoice.id,
            templateId: template.id,
            status: 'sent'
          });
          
          remindersSent++;
          
          // In a real implementation, would send an actual email here
          console.log(`Sent upcoming reminder for invoice #${invoice.invoiceNumber} to user ${invoice.userId}`);
        }
      }
      
      // Process renewal reminders
      if (renewalTemplates.length > 0 && renewalInvoices.length > 0) {
        const template = renewalTemplates[0]; // Use first available template
        
        for (const recurringInvoice of renewalInvoices) {
          // Create reminder log
          await storage.createReminderLog({
            userId: recurringInvoice.userId,
            recurringInvoiceId: recurringInvoice.id,
            templateId: template.id,
            status: 'sent'
          });
          
          remindersSent++;
          
          // In a real implementation, would send an actual email here
          console.log(`Sent renewal reminder for recurring invoice #${recurringInvoice.id} to user ${recurringInvoice.userId}`);
        }
      }
      
      res.status(200).json({ 
        message: "Reminders processed successfully",
        remindersSent,
        overdueCount: overdueInvoices.length,
        upcomingCount: upcomingInvoices.length,
        renewalCount: renewalInvoices.length
      });
    } catch (error) {
      console.error("Error processing reminders:", error);
      res.status(500).json({ message: "Error processing reminders" });
    }
  });

  // Analytics data initialization route - admin only
  app.post("/api/analytics/init-data", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized. Admin access required." });
    }
    
    try {
      const result = await initializeAnalyticsData(storage);
      res.json(result);
    } catch (error) {
      console.error("Error initializing analytics data:", error);
      res.status(500).json({ message: "Error initializing analytics data" });
    }
  });
  // Contact Information routes
  app.get("/api/contact", async (req, res) => {
    try {
      const contactInfo = await storage.getContactInfo();
      res.json(contactInfo || {});
    } catch (error) {
      console.error("Error fetching contact information:", error);
      res.status(500).json({ message: "Error fetching contact information" });
    }
  });

  app.post("/api/contact", async (req, res) => {
    try {
      // Only admin can update contact information
      if (!req.session.userId || req.session.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const contactData = insertContactInfoSchema.parse(req.body);
      const updatedContact = await storage.createOrUpdateContactInfo(contactData);
      res.json(updatedContact);
    } catch (error) {
      console.error("Error updating contact information:", error);
      res.status(500).json({ message: "Error updating contact information" });
    }
  });

  // About Us routes
  // This route is now removed to avoid duplication.
  // The new /api/about-us route is defined below near the other admin routes
  
  // Team Member routes
  app.get("/api/team-members", async (req, res) => {
    try {
      // If query param 'active' is true, only return active team members
      const activeOnly = req.query.active === 'true';
      const teamMembers = activeOnly 
        ? await storage.getActiveTeamMembers()
        : await storage.getAllTeamMembers();
      res.json(teamMembers);
    } catch (error) {
      console.error("Error fetching team members:", error);
      res.status(500).json({ message: "Error fetching team members" });
    }
  });
  
  app.get("/api/team-members/:id", async (req, res) => {
    try {
      const teamMember = await storage.getTeamMember(parseInt(req.params.id));
      if (!teamMember) {
        return res.status(404).json({ message: "Team member not found" });
      }
      res.json(teamMember);
    } catch (error) {
      console.error("Error fetching team member:", error);
      res.status(500).json({ message: "Error fetching team member" });
    }
  });
  
  app.post("/api/team-members", async (req, res) => {
    try {
      // Only admin can create team members
      if (!req.session.authenticated || req.session.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const teamMemberData = insertTeamMemberSchema.parse(req.body);
      const newTeamMember = await storage.createTeamMember(teamMemberData);
      res.status(201).json(newTeamMember);
    } catch (error) {
      console.error("Error creating team member:", error);
      res.status(500).json({ message: "Error creating team member" });
    }
  });
  
  app.put("/api/team-members/:id", async (req, res) => {
    try {
      // Only admin can update team members
      if (!req.session.authenticated || req.session.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const id = parseInt(req.params.id);
      const teamMemberData = insertTeamMemberSchema.parse(req.body);
      const updatedTeamMember = await storage.updateTeamMember(id, teamMemberData);
      
      if (!updatedTeamMember) {
        return res.status(404).json({ message: "Team member not found" });
      }
      
      res.json(updatedTeamMember);
    } catch (error) {
      console.error("Error updating team member:", error);
      res.status(500).json({ message: "Error updating team member" });
    }
  });
  
  app.patch("/api/team-members/:id/status", async (req, res) => {
    try {
      // Only admin can update team member status
      if (!req.session.authenticated || req.session.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const id = parseInt(req.params.id);
      const { isActive } = req.body;
      
      if (typeof isActive !== 'boolean') {
        return res.status(400).json({ message: "isActive must be a boolean value" });
      }
      
      const updatedTeamMember = await storage.updateTeamMemberStatus(id, isActive);
      
      if (!updatedTeamMember) {
        return res.status(404).json({ message: "Team member not found" });
      }
      
      res.json(updatedTeamMember);
    } catch (error) {
      console.error("Error updating team member status:", error);
      res.status(500).json({ message: "Error updating team member status" });
    }
  });
  
  app.delete("/api/team-members/:id", async (req, res) => {
    try {
      // Only admin can delete team members
      if (!req.session.authenticated || req.session.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const id = parseInt(req.params.id);
      const deleted = await storage.deleteTeamMember(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Team member not found" });
      }
      
      res.json({ message: "Team member deleted successfully" });
    } catch (error) {
      console.error("Error deleting team member:", error);
      res.status(500).json({ message: "Error deleting team member" });
    }
  });

  // Register billing system routes
  const billingRoutes = createBillingRoutes(storage);
  app.use('/api/billing', billingRoutes);
  
  // About Us routes
  app.get("/api/about-us", async (req, res) => {
    try {
      const aboutUsInfo = await storage.getAboutUs();
      console.log("Fetched About Us info:", aboutUsInfo);
      res.json(aboutUsInfo || {});
    } catch (error) {
      console.error("Error fetching About Us information:", error);
      res.status(500).json({ message: "Failed to fetch About Us information" });
    }
  });
  
  // Team Members routes
  app.get("/api/team-members", async (req, res) => {
    try {
      const teamMembers = await storage.getActiveTeamMembers();
      res.json(teamMembers);
    } catch (error) {
      console.error("Error fetching team members:", error);
      res.status(500).json({ message: "Failed to fetch team members" });
    }
  });
  
  // Admin About Us routes
  app.post("/api/admin/about-us", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      // First, let's remove the existing data completely
      await db.delete(aboutUs);
      
      // Then create a new record with the provided data
      const aboutUsData = insertAboutUsSchema.parse(req.body);
      const newAboutUs = await storage.createOrUpdateAboutUs(aboutUsData);
      
      console.log("Successfully updated About Us in admin panel:", newAboutUs);
      
      res.status(201).json(newAboutUs);
    } catch (error) {
      console.error("Error creating/updating About Us information:", error);
      res.status(500).json({ message: "Failed to create/update About Us information" });
    }
  });
  
  // Admin Team Members routes
  app.get("/api/admin/team-members", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const teamMembers = await storage.getAllTeamMembers();
      res.json(teamMembers);
    } catch (error) {
      console.error("Error fetching team members:", error);
      res.status(500).json({ message: "Failed to fetch team members" });
    }
  });
  
  app.post("/api/admin/team-members", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const teamMemberData = insertTeamMemberSchema.parse(req.body);
      const teamMember = await storage.createTeamMember(teamMemberData);
      res.status(201).json(teamMember);
    } catch (error) {
      console.error("Error creating team member:", error);
      res.status(500).json({ message: "Failed to create team member" });
    }
  });
  
  app.put("/api/admin/team-members/:id", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const teamMemberData = insertTeamMemberSchema.parse(req.body);
      const teamMember = await storage.updateTeamMember(parseInt(req.params.id), teamMemberData);
      if (!teamMember) {
        return res.status(404).json({ message: "Team member not found" });
      }
      res.json(teamMember);
    } catch (error) {
      console.error("Error updating team member:", error);
      res.status(500).json({ message: "Failed to update team member" });
    }
  });
  
  app.put("/api/admin/team-members/:id/status", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const { isActive } = req.body;
      if (typeof isActive !== 'boolean') {
        return res.status(400).json({ message: "isActive must be a boolean" });
      }
      
      const teamMember = await storage.updateTeamMemberStatus(parseInt(req.params.id), isActive);
      if (!teamMember) {
        return res.status(404).json({ message: "Team member not found" });
      }
      res.json(teamMember);
    } catch (error) {
      console.error("Error updating team member status:", error);
      res.status(500).json({ message: "Failed to update team member status" });
    }
  });
  
  app.delete("/api/admin/team-members/:id", async (req, res) => {
    // Check admin authorization
    if (!req.session || !req.session.userId || req.session.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const success = await storage.deleteTeamMember(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ message: "Team member not found" });
      }
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting team member:", error);
      res.status(500).json({ message: "Failed to delete team member" });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
