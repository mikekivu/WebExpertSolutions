import { db } from './db.js';
import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { migrate } from 'drizzle-orm/neon-serverless/migrator';
import ws from 'ws';
import { config } from 'dotenv';

// Load environment variables
config();

// Configure WebSocket for Neon DB connection
globalThis.WebSocket = ws;

// Main migration function
async function main() {
  console.log('Starting database migration...');
  
  try {
    // Migrate schema to the database
    console.log('Applying migrations...');
    await migrate(db, { migrationsFolder: 'drizzle/migrations' });
    console.log('Migrations completed successfully.');
    
    // Initialize default data if needed
    await initializeDefaultData();
    
    console.log('Database setup completed successfully.');
  } catch (error) {
    console.error('Error during migration:', error);
    process.exit(1);
  } finally {
    // Close the connection
    process.exit(0);
  }
}

// Function to initialize default data
async function initializeDefaultData() {
  const { users, contactInfo, aboutUs } = await import('../shared/schema.js');
  
  // Check if admin user exists
  const adminUserExists = await db.select().from(users).where({ role: 'admin' }).limit(1);
  
  if (adminUserExists.length === 0) {
    console.log('Creating admin user...');
    
    // Create admin user with bcryptjs
    const bcrypt = (await import('bcryptjs')).default;
    const hashedPassword = await bcrypt.hash('admin123', 10);
    
    await db.insert(users).values({
      username: 'admin',
      email: 'admin@webexpertsolutions.co.ke',
      password: hashedPassword,
      fullName: 'System Administrator',
      role: 'admin',
      verified: true,
    });
    
    console.log('Admin user created.');
  }
  
  // Add contact information if it doesn't exist
  const contactInfoExists = await db.select().from(contactInfo).limit(1);
  
  if (contactInfoExists.length === 0) {
    console.log('Adding contact information...');
    
    await db.insert(contactInfo).values({
      phoneNumber1: '+254112345366',
      phoneNumber2: '+254715026405',
      email: 'info@webexpertsolutions.co.ke',
      location: 'CBD, Nairobi, Kenya',
    });
    
    console.log('Contact information added.');
  }
  
  // Add about us information if it doesn't exist
  const aboutUsExists = await db.select().from(aboutUs).limit(1);
  
  if (aboutUsExists.length === 0) {
    console.log('Adding about us information...');
    
    await db.insert(aboutUs).values({
      title: 'About Web Expert Solutions',
      subtitle: 'Your Trusted Technology Partner',
      content: 'Web Expert Solutions is a leading web development and digital solutions provider based in Nairobi, Kenya. We specialize in creating custom web applications, mobile apps, and business management systems that help businesses grow and succeed in the digital age.',
      mission: 'Our mission is to empower businesses with innovative, reliable, and cost-effective digital solutions that drive growth and efficiency.',
      vision: 'To be the most trusted technology partner for businesses in East Africa, known for our exceptional quality, reliability, and customer service.',
      values: 'Innovation, Integrity, Excellence, Customer Focus, Continuous Improvement',
    });
    
    console.log('About us information added.');
  }
}

main();