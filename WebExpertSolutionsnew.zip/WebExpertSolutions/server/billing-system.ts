import { IStorage } from './storage';
import { ReminderTemplate, RecurringInvoice, Invoice } from '@shared/schema';
import { format, parseISO, addDays, isAfter, isBefore } from 'date-fns';

// Class to handle the automated billing and reminder system
export class BillingSystem {
  private storage: IStorage;

  constructor(storage: IStorage) {
    this.storage = storage;
  }

  // Generate invoices from recurring invoices that are due
  async generatePendingInvoices(): Promise<Invoice[]> {
    try {
      // Get all active recurring invoices
      const activeRecurringInvoices = await this.storage.getActiveRecurringInvoices();
      const today = new Date();
      const generatedInvoices: Invoice[] = [];

      // Check each recurring invoice
      for (const recurringInvoice of activeRecurringInvoices) {
        const nextBillingDate = parseISO(recurringInvoice.nextBillingDate.toString());
        
        // If the next billing date is today or in the past
        if (isAfter(today, nextBillingDate) || format(today, 'yyyy-MM-dd') === format(nextBillingDate, 'yyyy-MM-dd')) {
          // Get the billing plan to determine the next billing date
          const billingPlan = await this.storage.getBillingPlan(recurringInvoice.billingPlanId);
          
          if (!billingPlan) {
            console.error(`Billing plan ${recurringInvoice.billingPlanId} not found for recurring invoice ${recurringInvoice.id}`);
            continue;
          }

          // Create a new invoice for this recurring invoice
          const invoiceNumber = `INV-${Date.now()}-${recurringInvoice.userId}`;
          
          // Calculate the due date based on the billing plan's daysUntilDue
          const dueDate = addDays(new Date(), billingPlan.daysUntilDue);
          
          // Create the invoice
          const newInvoice = await this.storage.createInvoice({
            userId: recurringInvoice.userId,
            invoiceNumber,
            items: recurringInvoice.items,
            amount: recurringInvoice.amount,
            tax: recurringInvoice.tax,
            dueDate,
            quoteId: null // No quote for recurring invoices
          });
          
          generatedInvoices.push(newInvoice);
          
          // Update the next billing date for the recurring invoice
          let nextDate = new Date();
          
          // Calculate next billing date based on billing cycle
          switch (billingPlan.billingCycle) {
            case 'monthly':
              nextDate = new Date(nextBillingDate);
              nextDate.setMonth(nextDate.getMonth() + 1);
              break;
            case 'quarterly':
              nextDate = new Date(nextBillingDate);
              nextDate.setMonth(nextDate.getMonth() + 3);
              break;
            case 'annual':
              nextDate = new Date(nextBillingDate);
              nextDate.setFullYear(nextDate.getFullYear() + 1);
              break;
            default:
              nextDate = new Date(nextBillingDate);
              nextDate.setMonth(nextDate.getMonth() + 1);
          }
          
          // Update the recurring invoice with the new next billing date
          await this.storage.updateRecurringInvoice(recurringInvoice.id, {
            nextBillingDate: nextDate
          });
        }
      }
      
      return generatedInvoices;
    } catch (error) {
      console.error('Error generating pending invoices:', error);
      return [];
    }
  }

  // Get invoices that are overdue
  async getOverdueInvoices(): Promise<Invoice[]> {
    try {
      const overdueInvoices = await this.storage.getOverdueInvoices();
      return overdueInvoices;
    } catch (error) {
      console.error('Error getting overdue invoices:', error);
      return [];
    }
  }

  // Get invoices that are due soon
  async getUpcomingInvoices(daysThreshold: number = 7): Promise<Invoice[]> {
    try {
      const upcomingInvoices = await this.storage.getUpcomingInvoices(daysThreshold);
      return upcomingInvoices;
    } catch (error) {
      console.error('Error getting upcoming invoices:', error);
      return [];
    }
  }

  // Get recurring invoices that need renewal soon
  async getRecurringInvoicesDueForRenewal(daysThreshold: number = 7): Promise<RecurringInvoice[]> {
    try {
      const renewalDueInvoices = await this.storage.getRecurringInvoicesDueForRenewal(daysThreshold);
      return renewalDueInvoices;
    } catch (error) {
      console.error('Error getting recurring invoices due for renewal:', error);
      return [];
    }
  }

  // Process reminders for all types of invoices
  async processReminders(): Promise<{ sent: number, failed: number }> {
    let sentCount = 0;
    let failedCount = 0;
    
    try {
      // Get all reminder templates
      const templates = await this.storage.getAllReminderTemplates();
      const activeTemplates = templates.filter(t => t.active);
      
      // Process each type of reminder
      for (const template of activeTemplates) {
        switch (template.type) {
          case 'upcoming':
            await this.processUpcomingReminders(template, sentCount, failedCount);
            break;
          case 'overdue':
            await this.processOverdueReminders(template, sentCount, failedCount);
            break;
          case 'renewal':
            await this.processRenewalReminders(template, sentCount, failedCount);
            break;
        }
      }
      
      return { sent: sentCount, failed: failedCount };
    } catch (error) {
      console.error('Error processing reminders:', error);
      return { sent: sentCount, failed: failedCount };
    }
  }

  // Process reminders for upcoming invoices
  private async processUpcomingReminders(
    template: ReminderTemplate, 
    sentCount: number, 
    failedCount: number
  ): Promise<void> {
    // Get invoices due within days matching the template's offset
    const upcomingInvoices = await this.storage.getUpcomingInvoices(template.daysOffset);
    
    for (const invoice of upcomingInvoices) {
      try {
        // Check if a reminder has already been sent for this invoice and template
        const existingReminders = await this.storage.getReminderLogsByInvoiceId(invoice.id);
        const alreadySent = existingReminders.some(r => r.templateId === template.id);
        
        if (!alreadySent) {
          // Prepare the reminder email (in a real system, this would call an email service)
          await this.sendReminderEmail(
            invoice.userId,
            template.subject,
            template.body,
            { invoice }
          );
          
          // Log the reminder
          await this.storage.createReminderLog({
            userId: invoice.userId,
            invoiceId: invoice.id,
            recurringInvoiceId: null,
            templateId: template.id,
            status: 'sent'
          });
          
          sentCount++;
        }
      } catch (error) {
        console.error(`Failed to send upcoming reminder for invoice ${invoice.id}:`, error);
        failedCount++;
      }
    }
  }

  // Process reminders for overdue invoices
  private async processOverdueReminders(
    template: ReminderTemplate, 
    sentCount: number, 
    failedCount: number
  ): Promise<void> {
    // Get all overdue invoices
    const overdueInvoices = await this.storage.getOverdueInvoices();
    
    for (const invoice of overdueInvoices) {
      try {
        const dueDate = parseISO(invoice.dueDate.toString());
        const today = new Date();
        
        // Calculate days overdue
        const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
        
        // Check if this matches the template's days offset
        if (daysOverdue === template.daysOffset) {
          // Check if a reminder has already been sent for this invoice and template
          const existingReminders = await this.storage.getReminderLogsByInvoiceId(invoice.id);
          const alreadySent = existingReminders.some(r => r.templateId === template.id);
          
          if (!alreadySent) {
            // Prepare the reminder email (in a real system, this would call an email service)
            await this.sendReminderEmail(
              invoice.userId,
              template.subject,
              template.body,
              { invoice, daysOverdue }
            );
            
            // Log the reminder
            await this.storage.createReminderLog({
              userId: invoice.userId,
              invoiceId: invoice.id,
              recurringInvoiceId: null,
              templateId: template.id,
              status: 'sent'
            });
            
            sentCount++;
          }
        }
      } catch (error) {
        console.error(`Failed to send overdue reminder for invoice ${invoice.id}:`, error);
        failedCount++;
      }
    }
  }

  // Process reminders for recurring invoices due for renewal
  private async processRenewalReminders(
    template: ReminderTemplate, 
    sentCount: number, 
    failedCount: number
  ): Promise<void> {
    // Get recurring invoices due for renewal within the template's offset days
    const renewalDueInvoices = await this.storage.getRecurringInvoicesDueForRenewal(template.daysOffset);
    
    for (const recurringInvoice of renewalDueInvoices) {
      try {
        // Check if a reminder has already been sent for this recurring invoice and template
        const existingReminders = await this.storage.getReminderLogsByInvoiceId(recurringInvoice.id);
        const alreadySent = existingReminders.some(r => r.templateId === template.id);
        
        if (!alreadySent) {
          // Prepare the renewal reminder email (in a real system, this would call an email service)
          await this.sendReminderEmail(
            recurringInvoice.userId,
            template.subject,
            template.body,
            { recurringInvoice }
          );
          
          // Log the reminder
          await this.storage.createReminderLog({
            userId: recurringInvoice.userId,
            invoiceId: null,
            recurringInvoiceId: recurringInvoice.id,
            templateId: template.id,
            status: 'sent'
          });
          
          sentCount++;
        }
      } catch (error) {
        console.error(`Failed to send renewal reminder for recurring invoice ${recurringInvoice.id}:`, error);
        failedCount++;
      }
    }
  }

  // Helper method to send reminder emails (placeholder for actual email sending)
  private async sendReminderEmail(
    userId: number, 
    subject: string, 
    body: string, 
    data: any
  ): Promise<boolean> {
    try {
      // Get the user information
      const user = await this.storage.getUser(userId);
      
      if (!user) {
        console.error(`User ${userId} not found for sending reminder`);
        return false;
      }
      
      // In a real system, this would integrate with an email service like SendGrid or Nodemailer
      console.log(`REMINDER EMAIL to ${user.email}`);
      console.log(`Subject: ${subject}`);
      
      // Replace placeholders in the body with actual data
      let processedBody = body;
      
      if (data.invoice) {
        processedBody = processedBody
          .replace(/\{invoice_number\}/g, data.invoice.invoiceNumber)
          .replace(/\{invoice_amount\}/g, `${data.invoice.amount}`)
          .replace(/\{due_date\}/g, format(parseISO(data.invoice.dueDate.toString()), 'MMMM dd, yyyy'));
      }
      
      if (data.recurringInvoice) {
        processedBody = processedBody
          .replace(/\{next_billing_date\}/g, format(parseISO(data.recurringInvoice.nextBillingDate.toString()), 'MMMM dd, yyyy'))
          .replace(/\{amount\}/g, `${data.recurringInvoice.amount}`);
      }
      
      processedBody = processedBody
        .replace(/\{client_name\}/g, user.fullName)
        .replace(/\{company\}/g, user.company || '')
        .replace(/\{days_overdue\}/g, data.daysOverdue ? `${data.daysOverdue}` : '');
      
      console.log(`Body: ${processedBody}`);
      console.log('-------------------------------------');
      
      return true;
    } catch (error) {
      console.error('Error sending reminder email:', error);
      return false;
    }
  }
}