import {
  User,
  InsertUser,
  Service,
  InsertService,
  ClientService,
  InsertClientService,
  QuoteRequest,
  InsertQuoteRequest,
  Quote,
  InsertQuote,
  Invoice,
  InsertInvoice,
  Payment,
  InsertPayment,
  PortfolioItem,
  InsertPortfolioItem,
  Testimonial,
  InsertTestimonial,
  Email,
  InsertEmail,
  WebPackage,
  InsertWebPackage,
  HostingPackage,
  InsertHostingPackage,
  BillingPlan,
  InsertBillingPlan,
  ReminderTemplate,
  InsertReminderTemplate,
  RecurringInvoice,
  InsertRecurringInvoice,
  ReminderLog,
  InsertReminderLog,
  ContactInfo,
  InsertContactInfo,
  AboutUs,
  InsertAboutUs,
  TeamMember,
  InsertTeamMember,
  users,
  services,
  clientServices,
  quoteRequests,
  quotes,
  invoices,
  payments,
  portfolioItems,
  testimonials,
  emails,
  webPackages,
  hostingPackages,
  billingPlans,
  reminderTemplates,
  recurringInvoices,
  reminderLogs,
  contactInfo,
  aboutUs,
  teamMembers,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, sql } from "drizzle-orm";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByUsernameOrEmail(username: string, email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users)
      .where(
        sql`${users.username} = ${username} OR ${users.email} = ${email}`
      );
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async verifyUser(username: string, password: string): Promise<User | undefined> {
    const user = await this.getUserByUsername(username);
    // Password verification would be done in the route handler
    return user;
  }
  
  // Service operations
  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service;
  }

  async getAllServices(): Promise<Service[]> {
    return await db.select().from(services);
  }
  
  async getServicesByCategory(category: string): Promise<Service[]> {
    return await db.select().from(services).where(eq(services.category, category));
  }

  async createService(serviceData: InsertService): Promise<Service> {
    const [service] = await db.insert(services).values(serviceData).returning();
    return service;
  }
  
  // Client Service operations
  async getClientService(id: number): Promise<ClientService | undefined> {
    const [clientService] = await db.select().from(clientServices).where(eq(clientServices.id, id));
    return clientService;
  }
  
  async getClientServicesByUserId(userId: number): Promise<ClientService[]> {
    return await db.select().from(clientServices).where(eq(clientServices.userId, userId));
  }
  
  async getAllClientServices(): Promise<ClientService[]> {
    return await db.select().from(clientServices);
  }
  
  async createClientService(clientServiceData: InsertClientService): Promise<ClientService> {
    const [clientService] = await db.insert(clientServices).values(clientServiceData).returning();
    return clientService;
  }
  
  async updateClientServiceStatus(id: number, status: string): Promise<ClientService | undefined> {
    const [clientService] = await db.update(clientServices)
      .set({ status })
      .where(eq(clientServices.id, id))
      .returning();
    return clientService;
  }
  
  // Quote Request operations
  async getQuoteRequest(id: number): Promise<QuoteRequest | undefined> {
    const [quoteRequest] = await db.select().from(quoteRequests).where(eq(quoteRequests.id, id));
    return quoteRequest;
  }
  
  async getAllQuoteRequests(): Promise<QuoteRequest[]> {
    return await db.select().from(quoteRequests).orderBy(desc(quoteRequests.createdAt));
  }
  
  async getQuoteRequestsByUserId(userId: number): Promise<QuoteRequest[]> {
    return await db.select().from(quoteRequests)
      .where(eq(quoteRequests.userId, userId))
      .orderBy(desc(quoteRequests.createdAt));
  }
  
  async createQuoteRequest(quoteRequestData: InsertQuoteRequest): Promise<QuoteRequest> {
    const [quoteRequest] = await db.insert(quoteRequests).values(quoteRequestData).returning();
    return quoteRequest;
  }
  
  async updateQuoteRequestStatus(id: number, status: string): Promise<QuoteRequest | undefined> {
    const [quoteRequest] = await db.update(quoteRequests)
      .set({ status })
      .where(eq(quoteRequests.id, id))
      .returning();
    return quoteRequest;
  }
  
  // Quote operations
  async getQuote(id: number): Promise<Quote | undefined> {
    const [quote] = await db.select().from(quotes).where(eq(quotes.id, id));
    return quote;
  }
  
  async getQuotesByUserId(userId: number): Promise<Quote[]> {
    return await db.select().from(quotes).where(eq(quotes.userId, userId));
  }
  
  async createQuote(quoteData: InsertQuote): Promise<Quote> {
    const [quote] = await db.insert(quotes).values(quoteData).returning();
    return quote;
  }
  
  async updateQuoteStatus(id: number, status: string): Promise<Quote | undefined> {
    const [quote] = await db.update(quotes)
      .set({ status })
      .where(eq(quotes.id, id))
      .returning();
    return quote;
  }
  
  // Invoice operations
  async getInvoice(id: number): Promise<Invoice | undefined> {
    const [invoice] = await db.select().from(invoices).where(eq(invoices.id, id));
    return invoice;
  }
  
  async getAllInvoices(): Promise<Invoice[]> {
    return await db.select().from(invoices).orderBy(desc(invoices.createdAt));
  }
  
  async getInvoicesByUserId(userId: number): Promise<Invoice[]> {
    return await db.select().from(invoices).where(eq(invoices.userId, userId));
  }
  
  async createInvoice(invoiceData: InsertInvoice): Promise<Invoice> {
    const [invoice] = await db.insert(invoices).values(invoiceData).returning();
    return invoice;
  }
  
  async updateInvoiceStatus(id: number, status: string): Promise<Invoice | undefined> {
    const [invoice] = await db.update(invoices)
      .set({ status })
      .where(eq(invoices.id, id))
      .returning();
    return invoice;
  }
  
  // Payment operations
  async getPayment(id: number): Promise<Payment | undefined> {
    const [payment] = await db.select().from(payments).where(eq(payments.id, id));
    return payment;
  }
  
  async getAllPayments(): Promise<Payment[]> {
    return await db.select().from(payments).orderBy(desc(payments.paymentDate));
  }
  
  async getPaymentsByInvoiceId(invoiceId: number): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.invoiceId, invoiceId));
  }
  
  async createPayment(paymentData: InsertPayment): Promise<Payment> {
    const [payment] = await db.insert(payments).values(paymentData).returning();
    return payment;
  }
  
  // Portfolio operations
  async getPortfolioItem(id: number): Promise<PortfolioItem | undefined> {
    const [item] = await db.select().from(portfolioItems).where(eq(portfolioItems.id, id));
    return item;
  }
  
  async getAllPortfolioItems(): Promise<PortfolioItem[]> {
    return await db.select().from(portfolioItems);
  }
  
  async getFeaturedPortfolioItems(): Promise<PortfolioItem[]> {
    return await db.select().from(portfolioItems).where(eq(portfolioItems.featured, true));
  }
  
  async createPortfolioItem(portfolioItemData: InsertPortfolioItem): Promise<PortfolioItem> {
    const [item] = await db.insert(portfolioItems).values(portfolioItemData).returning();
    return item;
  }
  
  // Testimonial operations
  async getTestimonial(id: number): Promise<Testimonial | undefined> {
    const [testimonial] = await db.select().from(testimonials).where(eq(testimonials.id, id));
    return testimonial;
  }
  
  async getActiveTestimonials(): Promise<Testimonial[]> {
    return await db.select().from(testimonials).where(eq(testimonials.isActive, true));
  }
  
  async createTestimonial(testimonialData: InsertTestimonial): Promise<Testimonial> {
    const [testimonial] = await db.insert(testimonials).values(testimonialData).returning();
    return testimonial;
  }
  
  // Email operations
  async getEmail(id: number): Promise<Email | undefined> {
    const [email] = await db.select().from(emails).where(eq(emails.id, id));
    return email;
  }
  
  async createEmail(emailData: InsertEmail): Promise<Email> {
    const [email] = await db.insert(emails).values(emailData).returning();
    return email;
  }
  
  // Web Package operations
  async getWebPackage(id: number): Promise<WebPackage | undefined> {
    const [pkg] = await db.select().from(webPackages).where(eq(webPackages.id, id));
    return pkg;
  }
  
  async getAllWebPackages(): Promise<WebPackage[]> {
    return await db.select().from(webPackages);
  }
  
  async createWebPackage(webPackageData: InsertWebPackage): Promise<WebPackage> {
    const [pkg] = await db.insert(webPackages).values(webPackageData).returning();
    return pkg;
  }
  
  async updateWebPackage(id: number, webPackageData: InsertWebPackage): Promise<WebPackage | undefined> {
    const [pkg] = await db.update(webPackages)
      .set(webPackageData)
      .where(eq(webPackages.id, id))
      .returning();
    return pkg;
  }
  
  async deleteWebPackage(id: number): Promise<boolean> {
    const result = await db.delete(webPackages).where(eq(webPackages.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }
  
  // Hosting Package operations
  async getHostingPackage(id: number): Promise<HostingPackage | undefined> {
    const [pkg] = await db.select().from(hostingPackages).where(eq(hostingPackages.id, id));
    return pkg;
  }
  
  async getAllHostingPackages(): Promise<HostingPackage[]> {
    return await db.select().from(hostingPackages);
  }
  
  async createHostingPackage(hostingPackageData: InsertHostingPackage): Promise<HostingPackage> {
    const [pkg] = await db.insert(hostingPackages).values(hostingPackageData).returning();
    return pkg;
  }
  
  async updateHostingPackage(id: number, hostingPackageData: InsertHostingPackage): Promise<HostingPackage | undefined> {
    const [pkg] = await db.update(hostingPackages)
      .set(hostingPackageData)
      .where(eq(hostingPackages.id, id))
      .returning();
    return pkg;
  }
  
  async deleteHostingPackage(id: number): Promise<boolean> {
    const result = await db.delete(hostingPackages).where(eq(hostingPackages.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }
  
  // Billing system operations
  async getOverdueInvoices(): Promise<Invoice[]> {
    const today = new Date();
    return await db.select().from(invoices)
      .where(
        and(
          eq(invoices.status, 'pending'),
          sql`${invoices.dueDate} < ${today}`
        )
      );
  }
  
  async getUpcomingInvoices(daysThreshold: number): Promise<Invoice[]> {
    const today = new Date();
    const future = new Date();
    future.setDate(today.getDate() + daysThreshold);
    
    return await db.select().from(invoices)
      .where(
        and(
          eq(invoices.status, 'pending'),
          sql`${invoices.dueDate} >= ${today}`,
          sql`${invoices.dueDate} <= ${future}`
        )
      );
  }
  
  // Billing Plan operations
  async getBillingPlan(id: number): Promise<BillingPlan | undefined> {
    const [plan] = await db.select().from(billingPlans).where(eq(billingPlans.id, id));
    return plan;
  }
  
  async getAllBillingPlans(): Promise<BillingPlan[]> {
    return await db.select().from(billingPlans);
  }
  
  async createBillingPlan(billingPlanData: InsertBillingPlan): Promise<BillingPlan> {
    const [plan] = await db.insert(billingPlans).values(billingPlanData).returning();
    return plan;
  }
  
  async updateBillingPlan(id: number, billingPlanData: InsertBillingPlan): Promise<BillingPlan | undefined> {
    const [plan] = await db.update(billingPlans)
      .set(billingPlanData)
      .where(eq(billingPlans.id, id))
      .returning();
    return plan;
  }
  
  async deleteBillingPlan(id: number): Promise<boolean> {
    const result = await db.delete(billingPlans).where(eq(billingPlans.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }
  
  // Reminder Template operations
  async getReminderTemplate(id: number): Promise<ReminderTemplate | undefined> {
    const [template] = await db.select().from(reminderTemplates).where(eq(reminderTemplates.id, id));
    return template;
  }
  
  async getReminderTemplatesByType(type: string): Promise<ReminderTemplate[]> {
    return await db.select().from(reminderTemplates).where(eq(reminderTemplates.type, type));
  }
  
  async getAllReminderTemplates(): Promise<ReminderTemplate[]> {
    return await db.select().from(reminderTemplates);
  }
  
  async createReminderTemplate(reminderTemplateData: InsertReminderTemplate): Promise<ReminderTemplate> {
    const [template] = await db.insert(reminderTemplates).values(reminderTemplateData).returning();
    return template;
  }
  
  async updateReminderTemplate(id: number, reminderTemplateData: InsertReminderTemplate): Promise<ReminderTemplate | undefined> {
    const [template] = await db.update(reminderTemplates)
      .set(reminderTemplateData)
      .where(eq(reminderTemplates.id, id))
      .returning();
    return template;
  }
  
  async deleteReminderTemplate(id: number): Promise<boolean> {
    const result = await db.delete(reminderTemplates).where(eq(reminderTemplates.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }
  
  // Recurring Invoice operations
  async getRecurringInvoice(id: number): Promise<RecurringInvoice | undefined> {
    const [recurringInvoice] = await db.select().from(recurringInvoices).where(eq(recurringInvoices.id, id));
    return recurringInvoice;
  }
  
  async getRecurringInvoicesByUserId(userId: number): Promise<RecurringInvoice[]> {
    return await db.select().from(recurringInvoices).where(eq(recurringInvoices.userId, userId));
  }
  
  async getActiveRecurringInvoices(): Promise<RecurringInvoice[]> {
    return await db.select().from(recurringInvoices).where(eq(recurringInvoices.status, 'active'));
  }
  
  async getRecurringInvoicesDueForRenewal(daysThreshold: number): Promise<RecurringInvoice[]> {
    const today = new Date();
    const future = new Date();
    future.setDate(today.getDate() + daysThreshold);
    
    return await db.select().from(recurringInvoices)
      .where(
        and(
          eq(recurringInvoices.status, 'active'),
          sql`${recurringInvoices.nextBillingDate} >= ${today}`,
          sql`${recurringInvoices.nextBillingDate} <= ${future}`
        )
      );
  }
  
  async createRecurringInvoice(recurringInvoiceData: InsertRecurringInvoice): Promise<RecurringInvoice> {
    const [recurringInvoice] = await db.insert(recurringInvoices).values(recurringInvoiceData).returning();
    return recurringInvoice;
  }
  
  async updateRecurringInvoice(id: number, recurringInvoiceData: Partial<InsertRecurringInvoice>): Promise<RecurringInvoice | undefined> {
    const [recurringInvoice] = await db.update(recurringInvoices)
      .set(recurringInvoiceData)
      .where(eq(recurringInvoices.id, id))
      .returning();
    return recurringInvoice;
  }
  
  async updateRecurringInvoiceStatus(id: number, status: string): Promise<RecurringInvoice | undefined> {
    const [recurringInvoice] = await db.update(recurringInvoices)
      .set({ status })
      .where(eq(recurringInvoices.id, id))
      .returning();
    return recurringInvoice;
  }
  
  // Reminder Log operations
  async getReminderLog(id: number): Promise<ReminderLog | undefined> {
    const [log] = await db.select().from(reminderLogs).where(eq(reminderLogs.id, id));
    return log;
  }
  
  async getReminderLogsByUserId(userId: number): Promise<ReminderLog[]> {
    return await db.select().from(reminderLogs).where(eq(reminderLogs.userId, userId));
  }
  
  async getReminderLogsByInvoiceId(invoiceId: number): Promise<ReminderLog[]> {
    return await db.select().from(reminderLogs).where(eq(reminderLogs.invoiceId, invoiceId));
  }
  
  async createReminderLog(reminderLogData: InsertReminderLog): Promise<ReminderLog> {
    const [log] = await db.insert(reminderLogs).values(reminderLogData).returning();
    return log;
  }
  
  // Contact Info operations
  async getContactInfo(): Promise<ContactInfo | undefined> {
    const [info] = await db.select().from(contactInfo);
    return info;
  }
  
  async createOrUpdateContactInfo(contactInfoData: InsertContactInfo): Promise<ContactInfo> {
    const [existingInfo] = await db.select().from(contactInfo);
    
    if (existingInfo) {
      const [updatedInfo] = await db
        .update(contactInfo)
        .set({
          ...contactInfoData,
          updatedAt: new Date()
        })
        .where(eq(contactInfo.id, existingInfo.id))
        .returning();
      return updatedInfo;
    } else {
      const [newInfo] = await db
        .insert(contactInfo)
        .values(contactInfoData)
        .returning();
      return newInfo;
    }
  }
  
  // About Us operations
  async getAboutUs(): Promise<AboutUs | undefined> {
    try {
      // Use the correct camelCase column names as in the database
      const result = await db.execute(sql`
        SELECT 
          id, 
          title, 
          mission, 
          vision, 
          history, 
          values, 
          "teamDescription", 
          "metaDescription",
          "updatedAt"
        FROM about_us 
        ORDER BY id DESC 
        LIMIT 1
      `);
      
      if (result && result.rows && result.rows.length > 0) {
        console.log("Successfully retrieved About Us data:", result.rows[0]);
        return result.rows[0] as AboutUs;
      }
      
      console.log("No About Us data found");
      return undefined;
    } catch (error) {
      console.error("Error retrieving About Us data:", error);
      return undefined;
    }
  }
  
  async createOrUpdateAboutUs(aboutUsData: InsertAboutUs): Promise<AboutUs> {
    try {
      // Get existing About Us to determine if we should update or insert
      const existingAboutUs = await this.getAboutUs();
      
      if (existingAboutUs) {
        // Use a raw SQL update that matches the actual column names in the database
        const result = await db.execute(sql`
          UPDATE about_us
          SET 
            title = ${aboutUsData.title || existingAboutUs.title},
            mission = ${aboutUsData.mission || existingAboutUs.mission},
            vision = ${aboutUsData.vision || existingAboutUs.vision},
            history = ${aboutUsData.history || existingAboutUs.history},
            values = ${aboutUsData.values || existingAboutUs.values},
            "teamDescription" = ${aboutUsData.teamDescription || existingAboutUs.teamDescription},
            "metaDescription" = ${aboutUsData.metaDescription || existingAboutUs.metaDescription},
            "updatedAt" = ${new Date()}
          WHERE id = ${existingAboutUs.id}
          RETURNING *
        `);
        
        if (result && result.rows && result.rows.length > 0) {
          console.log("Updated About Us info:", result.rows[0]);
          return result.rows[0] as AboutUs;
        }
        
        throw new Error("Failed to update About Us information");
      } else {
        // Use a raw SQL insert that matches the actual column names in the database
        const result = await db.execute(sql`
          INSERT INTO about_us (
            title, 
            mission, 
            vision, 
            history, 
            values, 
            "teamDescription", 
            "metaDescription", 
            "updatedAt"
          )
          VALUES (
            ${aboutUsData.title || ''},
            ${aboutUsData.mission || ''},
            ${aboutUsData.vision || ''},
            ${aboutUsData.history || ''},
            ${aboutUsData.values || ''},
            ${aboutUsData.teamDescription || ''},
            ${aboutUsData.metaDescription || ''},
            ${new Date()}
          )
          RETURNING *
        `);
        
        if (result && result.rows && result.rows.length > 0) {
          console.log("Created new About Us info:", result.rows[0]);
          return result.rows[0] as AboutUs;
        }
        
        throw new Error("Failed to create About Us information");
      }
    } catch (error) {
      console.error("Error creating/updating About Us:", error);
      throw error;
    }
  }
  
  // Team Member operations
  async getTeamMember(id: number): Promise<TeamMember | undefined> {
    const [member] = await db.select().from(teamMembers).where(eq(teamMembers.id, id));
    return member;
  }
  
  async getAllTeamMembers(): Promise<TeamMember[]> {
    try {
      // Use correct camelCase column names as in the database
      const result = await db.execute(sql`
        SELECT 
          id, 
          name, 
          position, 
          bio, 
          "imageUrl",
          "isActive",
          "order",
          "updatedAt",
          "createdAt",
          "socialLinks"
        FROM team_members
        ORDER BY "order" ASC
      `);
      
      if (result && result.rows && result.rows.length > 0) {
        console.log("Successfully retrieved Team Members data:", result.rows);
        return result.rows as TeamMember[];
      }
      
      console.log("No Team Members found");
      return [];
    } catch (error) {
      console.error("Error retrieving Team Members data:", error);
      return [];
    }
  }
  
  async getActiveTeamMembers(): Promise<TeamMember[]> {
    try {
      // Use correct camelCase column names as in the database
      const result = await db.execute(sql`
        SELECT 
          id, 
          name, 
          position, 
          bio, 
          "imageUrl",
          "isActive",
          "order",
          "updatedAt",
          "createdAt",
          "socialLinks"
        FROM team_members
        WHERE "isActive" = true
        ORDER BY "order" ASC
      `);
      
      if (result && result.rows && result.rows.length > 0) {
        console.log("Successfully retrieved Active Team Members data:", result.rows);
        return result.rows as TeamMember[];
      }
      
      console.log("No Active Team Members found");
      return [];
    } catch (error) {
      console.error("Error retrieving Active Team Members data:", error);
      return [];
    }
  }
  
  async createTeamMember(teamMemberData: InsertTeamMember): Promise<TeamMember> {
    const [member] = await db.insert(teamMembers).values(teamMemberData).returning();
    return member;
  }
  
  async updateTeamMember(id: number, teamMemberData: InsertTeamMember): Promise<TeamMember | undefined> {
    const [member] = await db.update(teamMembers)
      .set(teamMemberData)
      .where(eq(teamMembers.id, id))
      .returning();
    return member;
  }
  
  async updateTeamMemberStatus(id: number, isActive: boolean): Promise<TeamMember | undefined> {
    const [member] = await db.update(teamMembers)
      .set({ isActive })
      .where(eq(teamMembers.id, id))
      .returning();
    return member;
  }
  
  async deleteTeamMember(id: number): Promise<boolean> {
    const result = await db.delete(teamMembers).where(eq(teamMembers.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }
}