import { Router } from 'express';
import { db } from './db';
import { aboutUs, teamMembers } from '@shared/schema';
import { desc, eq } from 'drizzle-orm';

export const aboutUsRouter = Router();

// Get the latest About Us content
aboutUsRouter.get('/', async (req, res) => {
  try {
    // Fetch the most recent About Us record
    const aboutUsData = await db.select().from(aboutUs).orderBy(desc(aboutUs.id)).limit(1);
    
    if (aboutUsData && aboutUsData.length > 0) {
      console.log("About Us API: Successfully retrieved data:", aboutUsData[0]);
      return res.json(aboutUsData[0]);
    }
    
    console.log("About Us API: No data found");
    return res.json({});
  } catch (error) {
    console.error("About Us API: Error fetching data:", error);
    return res.status(500).json({ message: "Failed to fetch About Us data" });
  }
});

// Get active team members
aboutUsRouter.get('/team-members', async (req, res) => {
  try {
    // Fetch active team members
    const teamData = await db.select().from(teamMembers)
      .where(eq(teamMembers.isActive, true))
      .orderBy(teamMembers.order);
    
    console.log(`About Us API: Retrieved ${teamData.length} team members`);
    return res.json(teamData);
  } catch (error) {
    console.error("About Us API: Error fetching team members:", error);
    return res.status(500).json({ message: "Failed to fetch team members" });
  }
});