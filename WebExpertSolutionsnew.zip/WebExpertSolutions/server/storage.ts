import {
  users,
  services,
  clientServices,
  quoteRequests,
  quotes,
  invoices,
  payments,
  portfolioItems,
  testimonials,
  emails,
  webPackages,
  hostingPackages,
  billingPlans,
  reminderTemplates,
  recurringInvoices,
  reminderLogs,
  contactInfo,
  aboutUs,
  teamMembers,
  analyticsData,
  type User,
  type InsertUser,
  type Service,
  type InsertService,
  type ClientService,
  type InsertClientService,
  type QuoteRequest,
  type InsertQuoteRequest,
  type Quote,
  type InsertQuote,
  type Invoice,
  type InsertInvoice,
  type Payment,
  type InsertPayment,
  type PortfolioItem,
  type InsertPortfolioItem,
  type Testimonial,
  type InsertTestimonial,
  type Email,
  type InsertEmail,
  type WebPackage,
  type InsertWebPackage,
  type HostingPackage,
  type InsertHostingPackage,
  type BillingPlan,
  type InsertBillingPlan,
  type ReminderTemplate,
  type InsertReminderTemplate,
  type RecurringInvoice,
  type InsertRecurringInvoice,
  type ReminderLog,
  type InsertReminderLog,
  type ContactInfo,
  type InsertContactInfo,
  type AboutUs,
  type InsertAboutUs,
  type TeamMember,
  type InsertTeamMember,
  type AnalyticsData,
  type InsertAnalyticsData,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, like, sql, or, lt } from "drizzle-orm";
import bcrypt from "bcryptjs";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByUsernameOrEmail(username: string, email: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(userData: InsertUser): Promise<User>;
  verifyUser(username: string, password: string): Promise<User | undefined>;
  
  // Service operations
  getService(id: number): Promise<Service | undefined>;
  getAllServices(): Promise<Service[]>;
  getServicesByCategory(category: string): Promise<Service[]>;
  createService(serviceData: InsertService): Promise<Service>;
  
  // Client service operations
  getClientService(id: number): Promise<ClientService | undefined>;
  getClientServicesByUserId(userId: number): Promise<ClientService[]>;
  getAllClientServices(): Promise<ClientService[]>;
  createClientService(clientServiceData: InsertClientService): Promise<ClientService>;
  updateClientServiceStatus(id: number, status: string): Promise<ClientService | undefined>;
  
  // Quote request operations
  getQuoteRequest(id: number): Promise<QuoteRequest | undefined>;
  getAllQuoteRequests(): Promise<QuoteRequest[]>;
  getQuoteRequestsByUserId(userId: number): Promise<QuoteRequest[]>;
  createQuoteRequest(quoteRequestData: InsertQuoteRequest): Promise<QuoteRequest>;
  updateQuoteRequestStatus(id: number, status: string): Promise<QuoteRequest | undefined>;
  
  // Quote operations
  getQuote(id: number): Promise<Quote | undefined>;
  getQuotesByUserId(userId: number): Promise<Quote[]>;
  createQuote(quoteData: InsertQuote): Promise<Quote>;
  updateQuoteStatus(id: number, status: string): Promise<Quote | undefined>;
  
  // Invoice operations
  getInvoice(id: number): Promise<Invoice | undefined>;
  getAllInvoices(): Promise<Invoice[]>;
  getInvoicesByUserId(userId: number): Promise<Invoice[]>;
  createInvoice(invoiceData: InsertInvoice): Promise<Invoice>;
  updateInvoiceStatus(id: number, status: string): Promise<Invoice | undefined>;
  
  // Payment operations
  getPayment(id: number): Promise<Payment | undefined>;
  getAllPayments(): Promise<Payment[]>;
  getPaymentsByInvoiceId(invoiceId: number): Promise<Payment[]>;
  createPayment(paymentData: InsertPayment): Promise<Payment>;
  
  // Portfolio operations
  getPortfolioItem(id: number): Promise<PortfolioItem | undefined>;
  getAllPortfolioItems(): Promise<PortfolioItem[]>;
  getFeaturedPortfolioItems(): Promise<PortfolioItem[]>;
  createPortfolioItem(portfolioItemData: InsertPortfolioItem): Promise<PortfolioItem>;
  
  // Testimonial operations
  getTestimonial(id: number): Promise<Testimonial | undefined>;
  getActiveTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonialData: InsertTestimonial): Promise<Testimonial>;
  
  // Email operations
  getEmail(id: number): Promise<Email | undefined>;
  createEmail(emailData: InsertEmail): Promise<Email>;
  
  // Web package operations
  getWebPackage(id: number): Promise<WebPackage | undefined>;
  getAllWebPackages(): Promise<WebPackage[]>;
  createWebPackage(webPackageData: InsertWebPackage): Promise<WebPackage>;
  updateWebPackage(id: number, webPackageData: InsertWebPackage): Promise<WebPackage | undefined>;
  deleteWebPackage(id: number): Promise<boolean>;
  
  // Hosting package operations
  getHostingPackage(id: number): Promise<HostingPackage | undefined>;
  getAllHostingPackages(): Promise<HostingPackage[]>;
  createHostingPackage(hostingPackageData: InsertHostingPackage): Promise<HostingPackage>;
  updateHostingPackage(id: number, hostingPackageData: InsertHostingPackage): Promise<HostingPackage | undefined>;
  deleteHostingPackage(id: number): Promise<boolean>;
  
  // Billing operations
  getOverdueInvoices(): Promise<Invoice[]>;
  getUpcomingInvoices(daysThreshold: number): Promise<Invoice[]>;
  getBillingPlan(id: number): Promise<BillingPlan | undefined>;
  getAllBillingPlans(): Promise<BillingPlan[]>;
  createBillingPlan(billingPlanData: InsertBillingPlan): Promise<BillingPlan>;
  updateBillingPlan(id: number, billingPlanData: InsertBillingPlan): Promise<BillingPlan | undefined>;
  deleteBillingPlan(id: number): Promise<boolean>;
  
  // Reminder template operations
  getReminderTemplate(id: number): Promise<ReminderTemplate | undefined>;
  getReminderTemplatesByType(type: string): Promise<ReminderTemplate[]>;
  getAllReminderTemplates(): Promise<ReminderTemplate[]>;
  createReminderTemplate(reminderTemplateData: InsertReminderTemplate): Promise<ReminderTemplate>;
  updateReminderTemplate(id: number, reminderTemplateData: InsertReminderTemplate): Promise<ReminderTemplate | undefined>;
  deleteReminderTemplate(id: number): Promise<boolean>;
  
  // Recurring invoice operations
  getRecurringInvoice(id: number): Promise<RecurringInvoice | undefined>;
  getRecurringInvoicesByUserId(userId: number): Promise<RecurringInvoice[]>;
  getActiveRecurringInvoices(): Promise<RecurringInvoice[]>;
  getRecurringInvoicesDueForRenewal(daysThreshold: number): Promise<RecurringInvoice[]>;
  createRecurringInvoice(recurringInvoiceData: InsertRecurringInvoice): Promise<RecurringInvoice>;
  updateRecurringInvoice(id: number, recurringInvoiceData: Partial<InsertRecurringInvoice>): Promise<RecurringInvoice | undefined>;
  updateRecurringInvoiceStatus(id: number, status: string): Promise<RecurringInvoice | undefined>;
  
  // Reminder log operations
  getReminderLog(id: number): Promise<ReminderLog | undefined>;
  getReminderLogsByUserId(userId: number): Promise<ReminderLog[]>;
  getReminderLogsByInvoiceId(invoiceId: number): Promise<ReminderLog[]>;
  createReminderLog(reminderLogData: InsertReminderLog): Promise<ReminderLog>;
  
  // Contact info operations
  getContactInfo(): Promise<ContactInfo | undefined>;
  createOrUpdateContactInfo(contactInfoData: InsertContactInfo): Promise<ContactInfo>;
  
  // About us operations
  getAboutUs(): Promise<AboutUs | undefined>;
  createOrUpdateAboutUs(aboutUsData: InsertAboutUs): Promise<AboutUs>;
  
  // Team member operations
  getTeamMember(id: number): Promise<TeamMember | undefined>;
  getAllTeamMembers(): Promise<TeamMember[]>;
  getActiveTeamMembers(): Promise<TeamMember[]>;
  createTeamMember(teamMemberData: InsertTeamMember): Promise<TeamMember>;
  updateTeamMember(id: number, teamMemberData: InsertTeamMember): Promise<TeamMember | undefined>;
  updateTeamMemberStatus(id: number, isActive: boolean): Promise<TeamMember | undefined>;
  deleteTeamMember(id: number): Promise<boolean>;
  
  // For Stripe
  updateStripeCustomerId(userId: number, customerId: string): Promise<User>;
  updateUserStripeInfo(userId: number, stripeInfo: { customerId: string, subscriptionId: string }): Promise<User>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByUsernameOrEmail(username: string, email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(
      or(
        eq(users.username, username),
        eq(users.email, email)
      )
    );
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createUser(userData: InsertUser): Promise<User> {
    // Hash password before storing
    if (userData.password) {
      userData.password = await bcrypt.hash(userData.password, 10);
    }

    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async verifyUser(username: string, password: string): Promise<User | undefined> {
    const user = await this.getUserByUsername(username);
    if (!user) {
      return undefined;
    }

    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) {
      return undefined;
    }

    return user;
  }

  // Service operations
  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service;
  }

  async getAllServices(): Promise<Service[]> {
    return await db.select().from(services).where(eq(services.isActive, true));
  }

  async getServicesByCategory(category: string): Promise<Service[]> {
    return await db.select().from(services).where(
      and(
        eq(services.category, category),
        eq(services.isActive, true)
      )
    );
  }

  async createService(serviceData: InsertService): Promise<Service> {
    const [service] = await db
      .insert(services)
      .values(serviceData)
      .returning();
    return service;
  }

  // Client service operations
  async getClientService(id: number): Promise<ClientService | undefined> {
    const [clientService] = await db.select().from(clientServices).where(eq(clientServices.id, id));
    return clientService;
  }

  async getClientServicesByUserId(userId: number): Promise<ClientService[]> {
    return await db.select().from(clientServices).where(eq(clientServices.userId, userId));
  }

  async getAllClientServices(): Promise<ClientService[]> {
    return await db.select().from(clientServices);
  }

  async createClientService(clientServiceData: InsertClientService): Promise<ClientService> {
    const [clientService] = await db
      .insert(clientServices)
      .values(clientServiceData)
      .returning();
    return clientService;
  }

  async updateClientServiceStatus(id: number, status: string): Promise<ClientService | undefined> {
    const [clientService] = await db
      .update(clientServices)
      .set({ status, updatedAt: new Date() })
      .where(eq(clientServices.id, id))
      .returning();
    return clientService;
  }

  // Quote request operations
  async getQuoteRequest(id: number): Promise<QuoteRequest | undefined> {
    const [quoteRequest] = await db.select().from(quoteRequests).where(eq(quoteRequests.id, id));
    return quoteRequest;
  }

  async getAllQuoteRequests(): Promise<QuoteRequest[]> {
    return await db.select().from(quoteRequests).orderBy(desc(quoteRequests.createdAt));
  }

  async getQuoteRequestsByUserId(userId: number): Promise<QuoteRequest[]> {
    return await db
      .select()
      .from(quoteRequests)
      .where(eq(quoteRequests.userId, userId))
      .orderBy(desc(quoteRequests.createdAt));
  }

  async createQuoteRequest(quoteRequestData: InsertQuoteRequest): Promise<QuoteRequest> {
    const [quoteRequest] = await db
      .insert(quoteRequests)
      .values(quoteRequestData)
      .returning();
    return quoteRequest;
  }

  async updateQuoteRequestStatus(id: number, status: string): Promise<QuoteRequest | undefined> {
    const [quoteRequest] = await db
      .update(quoteRequests)
      .set({ status, updatedAt: new Date() })
      .where(eq(quoteRequests.id, id))
      .returning();
    return quoteRequest;
  }

  // Quote operations
  async getQuote(id: number): Promise<Quote | undefined> {
    const [quote] = await db.select().from(quotes).where(eq(quotes.id, id));
    return quote;
  }

  async getQuotesByUserId(userId: number): Promise<Quote[]> {
    return await db
      .select()
      .from(quotes)
      .where(eq(quotes.userId, userId))
      .orderBy(desc(quotes.createdAt));
  }

  async createQuote(quoteData: InsertQuote): Promise<Quote> {
    const [quote] = await db
      .insert(quotes)
      .values(quoteData)
      .returning();
    return quote;
  }

  async updateQuoteStatus(id: number, status: string): Promise<Quote | undefined> {
    const [quote] = await db
      .update(quotes)
      .set({ status, updatedAt: new Date() })
      .where(eq(quotes.id, id))
      .returning();
    return quote;
  }

  // Invoice operations
  async getInvoice(id: number): Promise<Invoice | undefined> {
    const [invoice] = await db.select().from(invoices).where(eq(invoices.id, id));
    return invoice;
  }

  async getAllInvoices(): Promise<Invoice[]> {
    return await db.select().from(invoices).orderBy(desc(invoices.createdAt));
  }

  async getInvoicesByUserId(userId: number): Promise<Invoice[]> {
    return await db
      .select()
      .from(invoices)
      .where(eq(invoices.userId, userId))
      .orderBy(desc(invoices.createdAt));
  }

  async createInvoice(invoiceData: InsertInvoice): Promise<Invoice> {
    const [invoice] = await db
      .insert(invoices)
      .values(invoiceData)
      .returning();
    return invoice;
  }

  async updateInvoiceStatus(id: number, status: string): Promise<Invoice | undefined> {
    const [invoice] = await db
      .update(invoices)
      .set({ status, updatedAt: new Date() })
      .where(eq(invoices.id, id))
      .returning();
    return invoice;
  }

  // Payment operations
  async getPayment(id: number): Promise<Payment | undefined> {
    const [payment] = await db.select().from(payments).where(eq(payments.id, id));
    return payment;
  }

  async getAllPayments(): Promise<Payment[]> {
    return await db.select().from(payments).orderBy(desc(payments.paymentDate));
  }

  async getPaymentsByInvoiceId(invoiceId: number): Promise<Payment[]> {
    return await db
      .select()
      .from(payments)
      .where(eq(payments.invoiceId, invoiceId))
      .orderBy(desc(payments.paymentDate));
  }

  async createPayment(paymentData: InsertPayment): Promise<Payment> {
    const [payment] = await db
      .insert(payments)
      .values(paymentData)
      .returning();
    return payment;
  }

  // Portfolio operations
  async getPortfolioItem(id: number): Promise<PortfolioItem | undefined> {
    const [portfolioItem] = await db.select().from(portfolioItems).where(eq(portfolioItems.id, id));
    return portfolioItem;
  }

  async getAllPortfolioItems(): Promise<PortfolioItem[]> {
    return await db.select().from(portfolioItems).orderBy(desc(portfolioItems.createdAt));
  }

  async getFeaturedPortfolioItems(): Promise<PortfolioItem[]> {
    return await db
      .select()
      .from(portfolioItems)
      .where(eq(portfolioItems.featured, true))
      .orderBy(desc(portfolioItems.createdAt));
  }

  async createPortfolioItem(portfolioItemData: InsertPortfolioItem): Promise<PortfolioItem> {
    const [portfolioItem] = await db
      .insert(portfolioItems)
      .values(portfolioItemData)
      .returning();
    return portfolioItem;
  }

  // Testimonial operations
  async getTestimonial(id: number): Promise<Testimonial | undefined> {
    const [testimonial] = await db.select().from(testimonials).where(eq(testimonials.id, id));
    return testimonial;
  }

  async getActiveTestimonials(): Promise<Testimonial[]> {
    return await db
      .select()
      .from(testimonials)
      .where(eq(testimonials.isActive, true))
      .orderBy(desc(testimonials.createdAt));
  }

  async createTestimonial(testimonialData: InsertTestimonial): Promise<Testimonial> {
    const [testimonial] = await db
      .insert(testimonials)
      .values(testimonialData)
      .returning();
    return testimonial;
  }

  // Email operations
  async getEmail(id: number): Promise<Email | undefined> {
    const [email] = await db.select().from(emails).where(eq(emails.id, id));
    return email;
  }

  async createEmail(emailData: InsertEmail): Promise<Email> {
    const [email] = await db
      .insert(emails)
      .values(emailData)
      .returning();
    return email;
  }

  // Web package operations
  async getWebPackage(id: number): Promise<WebPackage | undefined> {
    const [webPackage] = await db.select().from(webPackages).where(eq(webPackages.id, id));
    return webPackage;
  }

  async getAllWebPackages(): Promise<WebPackage[]> {
    return await db
      .select()
      .from(webPackages)
      .where(eq(webPackages.isActive, true))
      .orderBy(webPackages.name);
  }

  async createWebPackage(webPackageData: InsertWebPackage): Promise<WebPackage> {
    const [webPackage] = await db
      .insert(webPackages)
      .values(webPackageData)
      .returning();
    return webPackage;
  }

  async updateWebPackage(id: number, webPackageData: InsertWebPackage): Promise<WebPackage | undefined> {
    const [webPackage] = await db
      .update(webPackages)
      .set({ ...webPackageData, updatedAt: new Date() })
      .where(eq(webPackages.id, id))
      .returning();
    return webPackage;
  }

  async deleteWebPackage(id: number): Promise<boolean> {
    const result = await db
      .delete(webPackages)
      .where(eq(webPackages.id, id));
    return !!result;
  }

  // Hosting package operations
  async getHostingPackage(id: number): Promise<HostingPackage | undefined> {
    const [hostingPackage] = await db.select().from(hostingPackages).where(eq(hostingPackages.id, id));
    return hostingPackage;
  }

  async getAllHostingPackages(): Promise<HostingPackage[]> {
    return await db
      .select()
      .from(hostingPackages)
      .where(eq(hostingPackages.isActive, true))
      .orderBy(hostingPackages.name);
  }

  async createHostingPackage(hostingPackageData: InsertHostingPackage): Promise<HostingPackage> {
    const [hostingPackage] = await db
      .insert(hostingPackages)
      .values(hostingPackageData)
      .returning();
    return hostingPackage;
  }

  async updateHostingPackage(id: number, hostingPackageData: InsertHostingPackage): Promise<HostingPackage | undefined> {
    const [hostingPackage] = await db
      .update(hostingPackages)
      .set({ ...hostingPackageData, updatedAt: new Date() })
      .where(eq(hostingPackages.id, id))
      .returning();
    return hostingPackage;
  }

  async deleteHostingPackage(id: number): Promise<boolean> {
    const result = await db
      .delete(hostingPackages)
      .where(eq(hostingPackages.id, id));
    return !!result;
  }

  // Billing operations
  async getOverdueInvoices(): Promise<Invoice[]> {
    const today = new Date();
    return await db
      .select()
      .from(invoices)
      .where(
        and(
          lt(invoices.dueDate, today),
          eq(invoices.status, "unpaid")
        )
      )
      .orderBy(invoices.dueDate);
  }

  async getUpcomingInvoices(daysThreshold: number): Promise<Invoice[]> {
    const today = new Date();
    const thresholdDate = new Date(today);
    thresholdDate.setDate(today.getDate() + daysThreshold);
    
    return await db
      .select()
      .from(invoices)
      .where(
        and(
          gte(invoices.dueDate, today),
          lte(invoices.dueDate, thresholdDate),
          eq(invoices.status, "unpaid")
        )
      )
      .orderBy(invoices.dueDate);
  }

  async getBillingPlan(id: number): Promise<BillingPlan | undefined> {
    const [billingPlan] = await db.select().from(billingPlans).where(eq(billingPlans.id, id));
    return billingPlan;
  }

  async getAllBillingPlans(): Promise<BillingPlan[]> {
    return await db
      .select()
      .from(billingPlans)
      .where(eq(billingPlans.isActive, true))
      .orderBy(billingPlans.name);
  }

  async createBillingPlan(billingPlanData: InsertBillingPlan): Promise<BillingPlan> {
    const [billingPlan] = await db
      .insert(billingPlans)
      .values(billingPlanData)
      .returning();
    return billingPlan;
  }

  async updateBillingPlan(id: number, billingPlanData: InsertBillingPlan): Promise<BillingPlan | undefined> {
    const [billingPlan] = await db
      .update(billingPlans)
      .set({ ...billingPlanData, updatedAt: new Date() })
      .where(eq(billingPlans.id, id))
      .returning();
    return billingPlan;
  }

  async deleteBillingPlan(id: number): Promise<boolean> {
    const result = await db
      .delete(billingPlans)
      .where(eq(billingPlans.id, id));
    return !!result;
  }

  // Reminder template operations
  async getReminderTemplate(id: number): Promise<ReminderTemplate | undefined> {
    const [reminderTemplate] = await db.select().from(reminderTemplates).where(eq(reminderTemplates.id, id));
    return reminderTemplate;
  }

  async getReminderTemplatesByType(type: string): Promise<ReminderTemplate[]> {
    return await db
      .select()
      .from(reminderTemplates)
      .where(
        and(
          eq(reminderTemplates.type, type),
          eq(reminderTemplates.isActive, true)
        )
      )
      .orderBy(reminderTemplates.name);
  }

  async getAllReminderTemplates(): Promise<ReminderTemplate[]> {
    return await db
      .select()
      .from(reminderTemplates)
      .orderBy(reminderTemplates.name);
  }

  async createReminderTemplate(reminderTemplateData: InsertReminderTemplate): Promise<ReminderTemplate> {
    const [reminderTemplate] = await db
      .insert(reminderTemplates)
      .values(reminderTemplateData)
      .returning();
    return reminderTemplate;
  }

  async updateReminderTemplate(id: number, reminderTemplateData: InsertReminderTemplate): Promise<ReminderTemplate | undefined> {
    const [reminderTemplate] = await db
      .update(reminderTemplates)
      .set({ ...reminderTemplateData, updatedAt: new Date() })
      .where(eq(reminderTemplates.id, id))
      .returning();
    return reminderTemplate;
  }

  async deleteReminderTemplate(id: number): Promise<boolean> {
    const result = await db
      .delete(reminderTemplates)
      .where(eq(reminderTemplates.id, id));
    return !!result;
  }

  // Recurring invoice operations
  async getRecurringInvoice(id: number): Promise<RecurringInvoice | undefined> {
    const [recurringInvoice] = await db.select().from(recurringInvoices).where(eq(recurringInvoices.id, id));
    return recurringInvoice;
  }

  async getRecurringInvoicesByUserId(userId: number): Promise<RecurringInvoice[]> {
    return await db
      .select()
      .from(recurringInvoices)
      .where(eq(recurringInvoices.userId, userId))
      .orderBy(recurringInvoices.nextBillingDate);
  }

  async getActiveRecurringInvoices(): Promise<RecurringInvoice[]> {
    return await db
      .select()
      .from(recurringInvoices)
      .where(eq(recurringInvoices.status, "active"))
      .orderBy(recurringInvoices.nextBillingDate);
  }

  async getRecurringInvoicesDueForRenewal(daysThreshold: number): Promise<RecurringInvoice[]> {
    const today = new Date();
    const thresholdDate = new Date(today);
    thresholdDate.setDate(today.getDate() + daysThreshold);
    
    return await db
      .select()
      .from(recurringInvoices)
      .where(
        and(
          gte(recurringInvoices.nextBillingDate, today),
          lte(recurringInvoices.nextBillingDate, thresholdDate),
          eq(recurringInvoices.status, "active")
        )
      )
      .orderBy(recurringInvoices.nextBillingDate);
  }

  async createRecurringInvoice(recurringInvoiceData: InsertRecurringInvoice): Promise<RecurringInvoice> {
    const [recurringInvoice] = await db
      .insert(recurringInvoices)
      .values(recurringInvoiceData)
      .returning();
    return recurringInvoice;
  }

  async updateRecurringInvoice(id: number, recurringInvoiceData: Partial<InsertRecurringInvoice>): Promise<RecurringInvoice | undefined> {
    const [recurringInvoice] = await db
      .update(recurringInvoices)
      .set({ ...recurringInvoiceData, updatedAt: new Date() })
      .where(eq(recurringInvoices.id, id))
      .returning();
    return recurringInvoice;
  }

  async updateRecurringInvoiceStatus(id: number, status: string): Promise<RecurringInvoice | undefined> {
    const [recurringInvoice] = await db
      .update(recurringInvoices)
      .set({ status, updatedAt: new Date() })
      .where(eq(recurringInvoices.id, id))
      .returning();
    return recurringInvoice;
  }

  // Reminder log operations
  async getReminderLog(id: number): Promise<ReminderLog | undefined> {
    const [reminderLog] = await db.select().from(reminderLogs).where(eq(reminderLogs.id, id));
    return reminderLog;
  }

  async getReminderLogsByUserId(userId: number): Promise<ReminderLog[]> {
    return await db
      .select()
      .from(reminderLogs)
      .where(eq(reminderLogs.userId, userId))
      .orderBy(desc(reminderLogs.sentAt));
  }

  async getReminderLogsByInvoiceId(invoiceId: number): Promise<ReminderLog[]> {
    return await db
      .select()
      .from(reminderLogs)
      .where(eq(reminderLogs.invoiceId, invoiceId))
      .orderBy(desc(reminderLogs.sentAt));
  }

  async createReminderLog(reminderLogData: InsertReminderLog): Promise<ReminderLog> {
    const [reminderLog] = await db
      .insert(reminderLogs)
      .values(reminderLogData)
      .returning();
    return reminderLog;
  }

  // Contact info operations
  async getContactInfo(): Promise<ContactInfo | undefined> {
    const [info] = await db.select().from(contactInfo);
    return info;
  }

  async createOrUpdateContactInfo(contactInfoData: InsertContactInfo): Promise<ContactInfo> {
    const existingInfo = await this.getContactInfo();
    
    if (existingInfo) {
      const [info] = await db
        .update(contactInfo)
        .set({ ...contactInfoData, updatedAt: new Date() })
        .where(eq(contactInfo.id, existingInfo.id))
        .returning();
      return info;
    } else {
      const [info] = await db
        .insert(contactInfo)
        .values({ ...contactInfoData, updatedAt: new Date() })
        .returning();
      return info;
    }
  }

  // About us operations
  async getAboutUs(): Promise<AboutUs | undefined> {
    const [about] = await db.select().from(aboutUs);
    return about;
  }

  async createOrUpdateAboutUs(aboutUsData: InsertAboutUs): Promise<AboutUs> {
    const existingAbout = await this.getAboutUs();
    
    if (existingAbout) {
      const [about] = await db
        .update(aboutUs)
        .set({ ...aboutUsData, updatedAt: new Date() })
        .where(eq(aboutUs.id, existingAbout.id))
        .returning();
      return about;
    } else {
      const [about] = await db
        .insert(aboutUs)
        .values({ ...aboutUsData, updatedAt: new Date() })
        .returning();
      return about;
    }
  }

  // Team member operations
  async getTeamMember(id: number): Promise<TeamMember | undefined> {
    const [teamMember] = await db.select().from(teamMembers).where(eq(teamMembers.id, id));
    return teamMember;
  }

  async getAllTeamMembers(): Promise<TeamMember[]> {
    return await db
      .select()
      .from(teamMembers)
      .orderBy(teamMembers.displayOrder);
  }

  async getActiveTeamMembers(): Promise<TeamMember[]> {
    return await db
      .select()
      .from(teamMembers)
      .where(eq(teamMembers.isActive, true))
      .orderBy(teamMembers.displayOrder);
  }

  async createTeamMember(teamMemberData: InsertTeamMember): Promise<TeamMember> {
    const [teamMember] = await db
      .insert(teamMembers)
      .values(teamMemberData)
      .returning();
    return teamMember;
  }

  async updateTeamMember(id: number, teamMemberData: InsertTeamMember): Promise<TeamMember | undefined> {
    const [teamMember] = await db
      .update(teamMembers)
      .set({ ...teamMemberData, updatedAt: new Date() })
      .where(eq(teamMembers.id, id))
      .returning();
    return teamMember;
  }

  async updateTeamMemberStatus(id: number, isActive: boolean): Promise<TeamMember | undefined> {
    const [teamMember] = await db
      .update(teamMembers)
      .set({ isActive, updatedAt: new Date() })
      .where(eq(teamMembers.id, id))
      .returning();
    return teamMember;
  }

  async deleteTeamMember(id: number): Promise<boolean> {
    const result = await db
      .delete(teamMembers)
      .where(eq(teamMembers.id, id));
    return !!result;
  }

  // Stripe customer and subscription management
  async updateStripeCustomerId(userId: number, customerId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ stripeCustomerId: customerId, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: number, stripeInfo: { customerId: string, subscriptionId: string }): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        stripeCustomerId: stripeInfo.customerId, 
        stripeSubscriptionId: stripeInfo.subscriptionId,
        updatedAt: new Date() 
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }
}

// Export a single instance of the database storage
export const storage = new DatabaseStorage();