CREATE TABLE IF NOT EXISTS "users" (
  "id" SERIAL PRIMARY KEY,
  "username" TEXT NOT NULL UNIQUE,
  "password" TEXT NOT NULL,
  "email" TEXT NOT NULL UNIQUE,
  "full_name" TEXT NOT NULL,
  "phone" TEXT,
  "company" TEXT,
  "role" TEXT NOT NULL DEFAULT 'client',
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "services" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "price" DECIMAL(10, 2) NOT NULL,
  "category" TEXT NOT NULL,
  "features" JSONB,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "client_services" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "service_id" INTEGER NOT NULL REFERENCES "services"("id"),
  "start_date" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "end_date" TIMESTAMP,
  "status" TEXT NOT NULL DEFAULT 'active',
  "details" JSONB
);

CREATE TABLE IF NOT EXISTS "quote_requests" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "email" TEXT NOT NULL,
  "phone" TEXT,
  "service_type" TEXT NOT NULL,
  "message" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'pending',
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "quotes" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER REFERENCES "users"("id"),
  "quote_request_id" INTEGER REFERENCES "quote_requests"("id"),
  "title" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "amount" DECIMAL(10, 2) NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'sent',
  "valid_until" TIMESTAMP,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "invoices" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "quote_id" INTEGER REFERENCES "quotes"("id"),
  "invoice_number" TEXT NOT NULL UNIQUE,
  "items" JSONB NOT NULL,
  "amount" DECIMAL(10, 2) NOT NULL,
  "tax" DECIMAL(10, 2),
  "status" TEXT NOT NULL DEFAULT 'unpaid',
  "due_date" TIMESTAMP NOT NULL,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "payments" (
  "id" SERIAL PRIMARY KEY,
  "invoice_id" INTEGER NOT NULL REFERENCES "invoices"("id"),
  "amount" DECIMAL(10, 2) NOT NULL,
  "method" TEXT NOT NULL,
  "transaction_id" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'completed',
  "payment_date" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "portfolio_items" (
  "id" SERIAL PRIMARY KEY,
  "title" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "category" TEXT NOT NULL,
  "image_url" TEXT NOT NULL,
  "tags" JSONB,
  "project_url" TEXT,
  "featured" BOOLEAN DEFAULT FALSE,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "testimonials" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "position" TEXT,
  "company" TEXT,
  "content" TEXT NOT NULL,
  "rating" INTEGER NOT NULL,
  "image_url" TEXT,
  "is_active" BOOLEAN DEFAULT TRUE,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "emails" (
  "id" SERIAL PRIMARY KEY,
  "subject" TEXT NOT NULL,
  "content" TEXT NOT NULL,
  "recipients" JSONB NOT NULL,
  "sent_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "sent_by" INTEGER NOT NULL REFERENCES "users"("id")
);

CREATE TABLE IF NOT EXISTS "sessions" (
  "sid" VARCHAR NOT NULL PRIMARY KEY,
  "sess" JSONB NOT NULL,
  "expire" TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "sessions" ("expire");