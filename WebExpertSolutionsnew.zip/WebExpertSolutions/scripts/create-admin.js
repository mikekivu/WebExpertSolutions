import { drizzle } from 'drizzle-orm/neon-serverless';
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from 'ws';
import bcrypt from 'bcryptjs';
import { users } from '../shared/schema.js';
import { eq, or } from 'drizzle-orm';

neonConfig.webSocketConstructor = ws;

async function createAdminUser() {
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL environment variable is not set');
  }

  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const db = drizzle(pool);

  console.log('Creating admin user...');

  const adminUsername = 'admin';
  const adminPassword = 'admin123'; // This is a temporary password, change it after first login
  const adminEmail = 'admin@example.com';
  
  try {
    // Check if admin already exists
    const existingAdmin = await db.select().from(users)
      .where(or(eq(users.username, adminUsername), eq(users.email, adminEmail)));

    if (existingAdmin.length > 0) {
      console.log('Admin user already exists.');
      await pool.end();
      return;
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(adminPassword, 10);

    // Create admin user
    await db.insert(users).values({
      username: adminUsername,
      password: hashedPassword,
      email: adminEmail,
      fullName: 'Admin User',
      role: 'admin'
    });

    console.log('Admin user created successfully.');
    console.log('Username:', adminUsername);
    console.log('Password:', adminPassword);
    console.log('Please change the password after first login.');
    
    await pool.end();
  } catch (error) {
    console.error('Error creating admin user:', error);
    await pool.end();
    process.exit(1);
  }
}

createAdminUser().catch(error => {
  console.error('Failed to create admin user:', error);
  process.exit(1);
});