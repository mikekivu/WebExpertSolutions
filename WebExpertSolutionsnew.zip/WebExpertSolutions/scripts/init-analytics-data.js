// Node.js script to initialize sample analytics data
import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "../shared/schema.js";
import { eq } from 'drizzle-orm';

// Need to set up a connection like in server/db.ts 
neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle({ client: pool, schema });

const { billingPlans, recurringInvoices } = schema;

async function addSampleBillingPlans() {
  console.log('Checking for existing billing plans...');
  
  const existingPlans = await db.select().from(billingPlans);
  
  if (existingPlans.length > 0) {
    console.log(`Found ${existingPlans.length} existing billing plans, skipping creation`);
    return existingPlans;
  }
  
  console.log('Creating sample billing plans...');
  
  const samplePlans = [
    {
      name: "Monthly Website Plan",
      description: "Monthly billing cycle for website hosting services",
      billingCycle: "monthly",
      daysUntilDue: 15,
      autoRenew: true
    },
    {
      name: "Quarterly Website Plan",
      description: "Quarterly billing cycle for website hosting services",
      billingCycle: "quarterly",
      daysUntilDue: 30,
      autoRenew: true
    },
    {
      name: "Annual Website Plan",
      description: "Annual billing cycle for website hosting services",
      billingCycle: "annual",
      daysUntilDue: 30,
      autoRenew: true
    }
  ];
  
  const insertedPlans = [];
  
  for (const plan of samplePlans) {
    const result = await db.insert(billingPlans).values(plan).returning();
    insertedPlans.push(result[0]);
    console.log(`Created billing plan: ${plan.name}`);
  }
  
  return insertedPlans;
}

async function addSampleRecurringInvoices(plans) {
  console.log('Checking for existing recurring invoices...');
  
  const existingInvoices = await db.select().from(recurringInvoices);
  
  if (existingInvoices.length > 0) {
    console.log(`Found ${existingInvoices.length} existing recurring invoices, skipping creation`);
    return;
  }
  
  console.log('Creating sample recurring invoices...');
  
  // Get admin user
  const users = await db.select().from(schema.users);
  if (users.length === 0) {
    console.log('No users found, cannot create recurring invoices');
    return;
  }
  
  const adminUser = users.find(u => u.role === 'admin') || users[0];
  const clientUsers = users.filter(u => u.role === 'client' || u.id !== adminUser.id);
  
  if (clientUsers.length === 0) {
    console.log('No client users found, cannot create recurring invoices');
    return;
  }
  
  // Get services
  const services = await db.select().from(schema.services);
  
  const sampleRecurringInvoices = [
    {
      userId: clientUsers[0]?.id || adminUser.id,
      serviceId: services[0]?.id,
      billingPlanId: plans[0].id,
      amount: 1500.00,
      status: "active",
      items: [
        {
          name: "Website Hosting - Monthly",
          amount: 1500.00,
          quantity: 1
        }
      ],
      tax: 240.00,
      startDate: new Date(2023, 0, 1),
      nextBillingDate: new Date(2023, 5, 1)
    },
    {
      userId: clientUsers[1]?.id || clientUsers[0]?.id || adminUser.id,
      serviceId: services[0]?.id,
      billingPlanId: plans[1].id, 
      amount: 4500.00,
      status: "active",
      items: [
        {
          name: "Website Hosting - Quarterly",
          amount: 4500.00,
          quantity: 1
        }
      ],
      tax: 720.00,
      startDate: new Date(2023, 0, 1),
      nextBillingDate: new Date(2023, 3, 1)
    },
    {
      userId: clientUsers[2]?.id || clientUsers[1]?.id || clientUsers[0]?.id || adminUser.id,
      serviceId: services[1]?.id,
      billingPlanId: plans[2].id,
      amount: 15000.00,
      status: "active",
      items: [
        {
          name: "Website Hosting - Annual",
          amount: 15000.00,
          quantity: 1
        }
      ],
      tax: 2400.00,
      startDate: new Date(2023, 0, 1),
      nextBillingDate: new Date(2024, 0, 1)
    }
  ];
  
  for (const invoice of sampleRecurringInvoices) {
    await db.insert(recurringInvoices).values(invoice);
    console.log(`Created recurring invoice for billing plan: ${invoice.billingPlanId}`);
  }
}

async function main() {
  try {
    console.log('Initializing sample analytics data...');
    
    // Add sample billing plans
    const plans = await addSampleBillingPlans();
    
    // Add sample recurring invoices
    await addSampleRecurringInvoices(plans);
    
    console.log('Sample analytics data initialization complete!');
    process.exit(0);
  } catch (error) {
    console.error('Error initializing sample analytics data:', error);
    process.exit(1);
  }
}

main();