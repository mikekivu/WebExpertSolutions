# Web Expert Solutions - cPanel Migration Guide

This is a duplicate of your Web Expert Solutions project configured for cPanel hosting migration.

## Pre-Migration Checklist

### 1. cPanel Requirements
- Node.js support (check with your hosting provider)
- MySQL database access
- SSH access (recommended) or File Manager access
- Email sending capabilities

### 2. Database Setup

#### Create MySQL Database in cPanel
1. Log into your cPanel
2. Navigate to "MySQL Databases"
3. Create a new database (e.g., `yourusername_webexpert`)
4. Create a database user with full privileges
5. Note down the database credentials

#### Run Database Migration
```bash
# Upload the project files to your server
# Navigate to your project directory
cd /path/to/your/webexpert/project

# Install dependencies
npm install

# Set up environment variables (see .env.example)
cp .env.example .env
# Edit .env with your actual database credentials

# Run database migration
node server/db-mysql.js
```

### 3. Environment Configuration

Create a `.env` file in your project root with these settings:

```env
# Database Configuration
DB_HOST=localhost
DB_USER=yourusername_dbuser
DB_PASSWORD=your_database_password
DB_NAME=yourusername_webexpert
DB_PORT=3306

# Session Secret (generate a secure random string)
SESSION_SECRET=your_very_secure_session_secret_here

# Email Configuration
GMAIL_USER=your_business_email@gmail.com
GMAIL_APP_PASSWORD=your_gmail_app_password

# PayPal Configuration
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret

# Optional: Google Analytics
VITE_GA_MEASUREMENT_ID=G-XXXXXXXXXX

# Application Configuration
NODE_ENV=production
PORT=3000
```

### 4. File Upload Process

#### Option A: Using SSH (Recommended)
```bash
# Compress your project
tar -czf webexpert.tar.gz webexpert/

# Upload to server
scp webexpert.tar.gz user@yourserver.com:/path/to/public_html/

# SSH into server and extract
ssh user@yourserver.com
cd /path/to/public_html/
tar -xzf webexpert.tar.gz
cd webexpert
```

#### Option B: Using cPanel File Manager
1. Create a ZIP file of the webexpert folder
2. Upload ZIP through cPanel File Manager
3. Extract in your desired directory (usually public_html)

### 5. Dependencies Installation

```bash
# Install Node.js dependencies
npm install

# Build the client application
npm run build:client
```

### 6. Server Configuration

#### For Apache (.htaccess)
Create a `.htaccess` file in your public_html directory:

```apache
RewriteEngine On

# Handle client-side routing
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_URI} !^/api/
RewriteRule . /index.html [L]

# Proxy API requests to Node.js server
RewriteCond %{REQUEST_URI} ^/api/
RewriteRule ^api/(.*)$ http://localhost:3000/api/$1 [P,L]
```

#### Start the Application
```bash
# Start the server
npm start

# Or use PM2 for production (if available)
npm install -g pm2
pm2 start server/index.js --name webexpert
pm2 startup
pm2 save
```

### 7. Database Schema Differences

This migration converts from PostgreSQL to MySQL. Key changes made:

- `SERIAL` → `INT AUTO_INCREMENT`
- `TEXT[]` → `JSON` (for array fields)
- `JSONB` → `JSON`
- `TIMESTAMP` handling updated for MySQL
- Foreign key constraints properly defined

### 8. Post-Migration Testing

1. **Database Connection Test**
   ```bash
   node -e "import('./server/db-mysql-connection.js').then(db => db.testConnection())"
   ```

2. **Admin Login Test**
   - Navigate to your website
   - Try logging in with: username `admin`, password `admin123`

3. **Core Features Test**
   - Quote request form
   - Contact information display
   - Portfolio and testimonials
   - Admin dashboard access

### 9. Common Issues and Solutions

#### Database Connection Issues
- Verify database credentials in `.env`
- Check if MySQL service is running
- Ensure database user has proper privileges

#### File Permission Issues
```bash
# Set proper permissions
chmod 755 /path/to/webexpert
chmod 644 /path/to/webexpert/.env
```

#### Node.js Issues
- Verify Node.js version compatibility
- Check if all dependencies installed correctly
- Review server logs for specific error messages

### 10. Security Considerations

1. **Environment Variables**
   - Keep `.env` file secure and never commit to version control
   - Use strong session secrets
   - Configure proper file permissions

2. **Database Security**
   - Use strong database passwords
   - Limit database user privileges
   - Enable SSL connections if available

3. **Application Security**
   - Keep dependencies updated
   - Use HTTPS in production
   - Configure proper CORS settings

### 11. Backup Strategy

1. **Database Backup**
   ```bash
   mysqldump -u username -p database_name > backup.sql
   ```

2. **File Backup**
   ```bash
   tar -czf webexpert-backup-$(date +%Y%m%d).tar.gz webexpert/
   ```

### 12. Monitoring and Maintenance

- Set up log rotation
- Monitor database performance
- Regular security updates
- Backup scheduling

## Support

For technical issues during migration:
1. Check server error logs
2. Verify all environment variables are set correctly
3. Test database connection independently
4. Ensure all dependencies are properly installed

## Default Admin Credentials

- **Username:** admin
- **Password:** admin123

**Important:** Change these credentials immediately after successful deployment.