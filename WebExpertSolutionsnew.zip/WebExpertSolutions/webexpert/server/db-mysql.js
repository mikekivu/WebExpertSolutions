import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';

// MySQL Database configuration for cPanel
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'your_cpanel_username',
  password: process.env.DB_PASSWORD || 'your_database_password',
  database: process.env.DB_NAME || 'your_database_name',
  port: process.env.DB_PORT || 3306
};

// SQL to create tables (MySQL compatible)
const createTablesSql = `
-- Create sessions table
CREATE TABLE IF NOT EXISTS \`sessions\` (
  \`sid\` VARCHAR(255) PRIMARY KEY,
  \`sess\` JSON NOT NULL,
  \`expire\` TIMESTAMP NOT NULL,
  INDEX \`IDX_session_expire\` (\`expire\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create users table
CREATE TABLE IF NOT EXISTS \`users\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`username\` VARCHAR(255) NOT NULL UNIQUE,
  \`email\` VARCHAR(255) NOT NULL UNIQUE,
  \`password\` VARCHAR(255) NOT NULL,
  \`full_name\` VARCHAR(255),
  \`phone\` VARCHAR(255),
  \`company\` VARCHAR(255),
  \`role\` VARCHAR(50) DEFAULT 'client',
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  \`verification_token\` VARCHAR(255),
  \`verified\` BOOLEAN DEFAULT FALSE,
  \`reset_token\` VARCHAR(255),
  \`reset_token_expiry\` TIMESTAMP NULL,
  \`stripe_customer_id\` VARCHAR(255),
  \`stripe_subscription_id\` VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create services table
CREATE TABLE IF NOT EXISTS \`services\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`description\` TEXT NOT NULL,
  \`category\` VARCHAR(100) NOT NULL,
  \`price\` DECIMAL(10, 2),
  \`price_type\` VARCHAR(50) DEFAULT 'fixed',
  \`price_range\` VARCHAR(100),
  \`duration\` INT,
  \`duration_type\` VARCHAR(50) DEFAULT 'days',
  \`features\` JSON,
  \`is_active\` BOOLEAN DEFAULT TRUE,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create client_services table
CREATE TABLE IF NOT EXISTS \`client_services\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`user_id\` INT NOT NULL,
  \`service_id\` INT NOT NULL,
  \`status\` VARCHAR(50) DEFAULT 'pending',
  \`purchase_date\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`expiry_date\` TIMESTAMP NULL,
  \`renewal_date\` TIMESTAMP NULL,
  \`notes\` TEXT,
  \`price\` DECIMAL(10, 2) NOT NULL,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`service_id\`) REFERENCES \`services\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create quote_requests table
CREATE TABLE IF NOT EXISTS \`quote_requests\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`user_id\` INT NULL,
  \`name\` VARCHAR(255) NOT NULL,
  \`email\` VARCHAR(255) NOT NULL,
  \`phone\` VARCHAR(255) NOT NULL,
  \`company\` VARCHAR(255),
  \`service_type\` VARCHAR(100) NOT NULL,
  \`message\` TEXT NOT NULL,
  \`status\` VARCHAR(50) DEFAULT 'pending',
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create quotes table
CREATE TABLE IF NOT EXISTS \`quotes\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`quote_request_id\` INT NULL,
  \`user_id\` INT NULL,
  \`title\` VARCHAR(255) NOT NULL,
  \`description\` TEXT NOT NULL,
  \`total_price\` DECIMAL(10, 2) NOT NULL,
  \`valid_until\` TIMESTAMP NOT NULL,
  \`status\` VARCHAR(50) DEFAULT 'sent',
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (\`quote_request_id\`) REFERENCES \`quote_requests\`(\`id\`) ON DELETE SET NULL,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create invoices table
CREATE TABLE IF NOT EXISTS \`invoices\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`user_id\` INT NOT NULL,
  \`quote_id\` INT NULL,
  \`client_service_id\` INT NULL,
  \`invoice_number\` VARCHAR(100) NOT NULL UNIQUE,
  \`title\` VARCHAR(255) NOT NULL,
  \`description\` TEXT,
  \`total_amount\` DECIMAL(10, 2) NOT NULL,
  \`tax_amount\` DECIMAL(10, 2),
  \`due_date\` TIMESTAMP NOT NULL,
  \`status\` VARCHAR(50) DEFAULT 'unpaid',
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`quote_id\`) REFERENCES \`quotes\`(\`id\`) ON DELETE SET NULL,
  FOREIGN KEY (\`client_service_id\`) REFERENCES \`client_services\`(\`id\`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create payments table
CREATE TABLE IF NOT EXISTS \`payments\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`invoice_id\` INT NOT NULL,
  \`user_id\` INT NOT NULL,
  \`amount\` DECIMAL(10, 2) NOT NULL,
  \`payment_method\` VARCHAR(50) NOT NULL,
  \`transaction_id\` VARCHAR(255),
  \`status\` VARCHAR(50) DEFAULT 'completed',
  \`payment_date\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`notes\` TEXT,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (\`invoice_id\`) REFERENCES \`invoices\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create portfolio_items table
CREATE TABLE IF NOT EXISTS \`portfolio_items\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`title\` VARCHAR(255) NOT NULL,
  \`description\` TEXT NOT NULL,
  \`category\` VARCHAR(100) NOT NULL,
  \`image_url\` VARCHAR(255) NOT NULL,
  \`website_url\` VARCHAR(255),
  \`client_name\` VARCHAR(255),
  \`completion_date\` DATE,
  \`featured\` BOOLEAN DEFAULT FALSE,
  \`technologies\` JSON,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create testimonials table
CREATE TABLE IF NOT EXISTS \`testimonials\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`client_name\` VARCHAR(255) NOT NULL,
  \`client_company\` VARCHAR(255),
  \`client_title\` VARCHAR(255),
  \`profile_image\` VARCHAR(255),
  \`content\` TEXT NOT NULL,
  \`rating\` INT DEFAULT 5,
  \`project_type\` VARCHAR(100),
  \`is_active\` BOOLEAN DEFAULT TRUE,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create emails table
CREATE TABLE IF NOT EXISTS \`emails\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`user_id\` INT NULL,
  \`to\` VARCHAR(255) NOT NULL,
  \`subject\` VARCHAR(255) NOT NULL,
  \`content\` TEXT NOT NULL,
  \`sent_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`status\` VARCHAR(50) DEFAULT 'sent',
  \`type\` VARCHAR(50),
  \`metadata\` JSON,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create web_packages table
CREATE TABLE IF NOT EXISTS \`web_packages\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`description\` TEXT NOT NULL,
  \`price_range\` VARCHAR(100) NOT NULL,
  \`features\` JSON,
  \`pages_included\` INT DEFAULT 1,
  \`revisions\` INT DEFAULT 1,
  \`delivery_time\` VARCHAR(100),
  \`support_period\` VARCHAR(100),
  \`featured\` BOOLEAN DEFAULT FALSE,
  \`popular\` BOOLEAN DEFAULT FALSE,
  \`is_active\` BOOLEAN DEFAULT TRUE,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create hosting_packages table
CREATE TABLE IF NOT EXISTS \`hosting_packages\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`description\` TEXT NOT NULL,
  \`price_range\` VARCHAR(100) NOT NULL,
  \`storage_space\` VARCHAR(100) NOT NULL,
  \`bandwidth\` VARCHAR(100) NOT NULL,
  \`email_accounts\` INT DEFAULT 0,
  \`features\` JSON,
  \`support_period\` VARCHAR(100),
  \`featured\` BOOLEAN DEFAULT FALSE,
  \`popular\` BOOLEAN DEFAULT FALSE,
  \`is_active\` BOOLEAN DEFAULT TRUE,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create billing_plans table
CREATE TABLE IF NOT EXISTS \`billing_plans\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`description\` TEXT,
  \`frequency\` VARCHAR(50) NOT NULL,
  \`days_in_cycle\` INT NOT NULL,
  \`is_active\` BOOLEAN DEFAULT TRUE,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create reminder_templates table
CREATE TABLE IF NOT EXISTS \`reminder_templates\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`type\` VARCHAR(50) NOT NULL,
  \`subject\` VARCHAR(255) NOT NULL,
  \`content\` TEXT NOT NULL,
  \`days_offset\` INT DEFAULT 0,
  \`is_active\` BOOLEAN DEFAULT TRUE,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create recurring_invoices table
CREATE TABLE IF NOT EXISTS \`recurring_invoices\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`user_id\` INT NOT NULL,
  \`billing_plan_id\` INT NOT NULL,
  \`title\` VARCHAR(255) NOT NULL,
  \`description\` TEXT,
  \`amount\` DECIMAL(10, 2) NOT NULL,
  \`last_billed_date\` TIMESTAMP NULL,
  \`next_billing_date\` TIMESTAMP NOT NULL,
  \`status\` VARCHAR(50) DEFAULT 'active',
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`billing_plan_id\`) REFERENCES \`billing_plans\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create reminder_logs table
CREATE TABLE IF NOT EXISTS \`reminder_logs\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`user_id\` INT NOT NULL,
  \`invoice_id\` INT NULL,
  \`recurring_invoice_id\` INT NULL,
  \`reminder_template_id\` INT NULL,
  \`email_id\` INT NULL,
  \`sent_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`status\` VARCHAR(50) DEFAULT 'sent',
  \`type\` VARCHAR(50) NOT NULL,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`invoice_id\`) REFERENCES \`invoices\`(\`id\`) ON DELETE SET NULL,
  FOREIGN KEY (\`recurring_invoice_id\`) REFERENCES \`recurring_invoices\`(\`id\`) ON DELETE SET NULL,
  FOREIGN KEY (\`reminder_template_id\`) REFERENCES \`reminder_templates\`(\`id\`) ON DELETE SET NULL,
  FOREIGN KEY (\`email_id\`) REFERENCES \`emails\`(\`id\`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create contact_info table
CREATE TABLE IF NOT EXISTS \`contact_info\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`phone_number1\` VARCHAR(255) NOT NULL,
  \`phone_number2\` VARCHAR(255),
  \`email\` VARCHAR(255) NOT NULL,
  \`location\` VARCHAR(255) NOT NULL,
  \`google_map_link\` VARCHAR(255),
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create about_us table
CREATE TABLE IF NOT EXISTS \`about_us\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`title\` VARCHAR(255) NOT NULL,
  \`subtitle\` VARCHAR(255),
  \`content\` TEXT NOT NULL,
  \`mission\` TEXT,
  \`vision\` TEXT,
  \`values\` TEXT,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create team_members table
CREATE TABLE IF NOT EXISTS \`team_members\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`position\` VARCHAR(255) NOT NULL,
  \`bio\` TEXT,
  \`image_url\` VARCHAR(255),
  \`email\` VARCHAR(255),
  \`social_links\` JSON,
  \`is_active\` BOOLEAN DEFAULT TRUE,
  \`display_order\` INT DEFAULT 0,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create analytics_data table
CREATE TABLE IF NOT EXISTS \`analytics_data\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`date\` DATE NOT NULL,
  \`page_views\` INT DEFAULT 0,
  \`unique_visitors\` INT DEFAULT 0,
  \`conversion_rate\` DECIMAL(5, 2) DEFAULT 0,
  \`bounce_rate\` DECIMAL(5, 2) DEFAULT 0,
  \`top_sources_data\` JSON,
  \`visitors_by_location\` JSON,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
`;

async function createTables() {
  const connection = await mysql.createConnection(dbConfig);
  
  try {
    console.log('Creating MySQL tables...');
    await connection.query(createTablesSql);
    console.log('Tables created successfully');
  } catch (error) {
    console.error('Error creating tables:', error);
    throw error;
  } finally {
    await connection.end();
  }
}

async function insertInitialData() {
  const connection = await mysql.createConnection(dbConfig);
  
  try {
    console.log('Inserting initial data...');
    
    // Check if admin user exists
    const [adminCheck] = await connection.execute(
      'SELECT * FROM users WHERE username = ?', 
      ['admin']
    );
    
    if (adminCheck.length === 0) {
      // Create admin user
      const hashedPassword = await bcrypt.hash('admin123', 10);
      await connection.execute(
        `INSERT INTO users (username, email, password, full_name, role, verified) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        ['admin', 'admin@webexpertsolutions.co.ke', hashedPassword, 'System Administrator', 'admin', true]
      );
      console.log('Admin user created');
    }
    
    // Check if contact info exists
    const [contactCheck] = await connection.execute('SELECT * FROM contact_info');
    if (contactCheck.length === 0) {
      await connection.execute(
        `INSERT INTO contact_info (phone_number1, phone_number2, email, location) 
         VALUES (?, ?, ?, ?)`,
        ['+254112345366', '+254715026405', 'info@webexpertsolutions.co.ke', 'CBD, Nairobi, Kenya']
      );
      console.log('Contact info created');
    }
    
    // Check if about us exists
    const [aboutCheck] = await connection.execute('SELECT * FROM about_us');
    if (aboutCheck.length === 0) {
      await connection.execute(
        `INSERT INTO about_us (title, subtitle, content, mission, vision, values) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          'About Web Expert Solutions',
          'Your Trusted Technology Partner',
          'Web Expert Solutions is a leading web development and digital solutions provider based in Nairobi, Kenya. We specialize in creating custom web applications, mobile apps, and business management systems that help businesses grow and succeed in the digital age.',
          'Our mission is to empower businesses with innovative, reliable, and cost-effective digital solutions that drive growth and efficiency.',
          'To be the most trusted technology partner for businesses in East Africa, known for our exceptional quality, reliability, and customer service.',
          'Innovation, Integrity, Excellence, Customer Focus, Continuous Improvement'
        ]
      );
      console.log('About us info created');
    }
    
    // Insert web packages if they don't exist
    const [webPackagesCheck] = await connection.execute('SELECT * FROM web_packages');
    if (webPackagesCheck.length === 0) {
      const webPackages = [
        ['Basic Website', 'Perfect for small businesses and startups looking to establish their online presence.', 'Ksh 15,000-25,000', JSON.stringify(['Responsive design', 'Contact form', 'Social media integration', 'Google Maps integration', 'SEO optimization']), 5, 2, '7-14 days', '30 days', false, false],
        ['Standard Website', 'Ideal for growing businesses that need additional features and functionality.', 'Ksh 25,000-45,000', JSON.stringify(['All Basic features', 'Content Management System', 'Blog/News section', 'Photo gallery', 'Newsletter signup', 'Google Analytics integration', 'Speed optimization']), 10, 3, '14-21 days', '60 days', true, true],
        ['Premium Website', 'Comprehensive solution for established businesses requiring advanced features.', 'Ksh 45,000-85,000', JSON.stringify(['All Standard features', 'E-commerce integration', 'Custom database', 'User accounts', 'Advanced security', 'Payment gateway integration', 'Custom animations', 'Multilingual support']), 15, 5, '21-30 days', '90 days', true, false]
      ];
      
      for (const pkg of webPackages) {
        await connection.execute(
          `INSERT INTO web_packages (name, description, price_range, features, pages_included, revisions, delivery_time, support_period, featured, popular) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          pkg
        );
      }
      console.log('Web packages created');
    }
    
    // Insert hosting packages if they don't exist
    const [hostingPackagesCheck] = await connection.execute('SELECT * FROM hosting_packages');
    if (hostingPackagesCheck.length === 0) {
      const hostingPackages = [
        ['Basic Hosting', 'Affordable hosting solution for small websites and blogs.', 'Ksh 500-1,000/month', '5 GB', '50 GB/month', 5, JSON.stringify(['99.9% uptime guarantee', 'cPanel access', 'Free SSL certificate', 'Daily backups', '24/7 monitoring']), 'Email support', false, false],
        ['Business Hosting', 'Reliable hosting for business websites with moderate traffic.', 'Ksh 1,500-3,000/month', '20 GB', '200 GB/month', 10, JSON.stringify(['99.9% uptime guarantee', 'cPanel access', 'Free SSL certificate', 'Daily backups', '24/7 monitoring', 'CDN integration', 'Priority support', 'Malware scanning']), 'Email and chat support', true, true],
        ['Premium Hosting', 'High-performance hosting for high-traffic websites and e-commerce stores.', 'Ksh 5,000-10,000/month', '50 GB', 'Unlimited', 20, JSON.stringify(['99.9% uptime guarantee', 'cPanel access', 'Free SSL certificate', 'Daily backups', '24/7 monitoring', 'CDN integration', 'Priority support', 'Malware scanning', 'Dedicated resources', 'DDoS protection', 'Performance optimization', 'Advanced security features']), '24/7 phone, email, and chat support', true, false]
      ];
      
      for (const pkg of hostingPackages) {
        await connection.execute(
          `INSERT INTO hosting_packages (name, description, price_range, storage_space, bandwidth, email_accounts, features, support_period, featured, popular) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          pkg
        );
      }
      console.log('Hosting packages created');
    }
    
    console.log('Initial data insertion completed');
  } catch (error) {
    console.error('Error inserting initial data:', error);
    throw error;
  } finally {
    await connection.end();
  }
}

async function main() {
  try {
    console.log('Starting MySQL database setup for cPanel...');
    console.log('Database config:', { ...dbConfig, password: '***' });
    
    await createTables();
    await insertInitialData();
    
    console.log('MySQL database setup completed successfully!');
    console.log('Admin credentials: username=admin, password=admin123');
  } catch (error) {
    console.error('Database setup failed:', error);
    process.exit(1);
  }
}

// Export for use
export { createTables, insertInitialData };

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}