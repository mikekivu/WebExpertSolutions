#!/bin/bash

# Web Expert Solutions - cPanel Deployment Script
echo "Starting Web Expert Solutions deployment..."

# Check if Node.js is available
if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if npm is available
if ! command -v npm &> /dev/null; then
    echo "Error: npm is not installed. Please install npm first."
    exit 1
fi

# Install dependencies
echo "Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "Error: Failed to install dependencies"
    exit 1
fi

# Build client application
echo "Building client application..."
npm run build:client

if [ $? -ne 0 ]; then
    echo "Error: Failed to build client application"
    exit 1
fi

# Check if .env file exists
if [ ! -f .env ]; then
    echo "Warning: .env file not found. Copying from .env.example..."
    cp .env.example .env
    echo "Please edit .env file with your actual configuration before proceeding."
    exit 1
fi

# Test database connection
echo "Testing database connection..."
node -e "
import('./server/db-mysql-connection.js').then(async (db) => {
    const connected = await db.testConnection();
    if (connected) {
        console.log('Database connection successful');
        process.exit(0);
    } else {
        console.log('Database connection failed');
        process.exit(1);
    }
}).catch(err => {
    console.log('Database connection test failed:', err.message);
    process.exit(1);
});
" 2>/dev/null

if [ $? -ne 0 ]; then
    echo "Warning: Database connection test failed. Please check your database configuration."
    echo "You can proceed with deployment, but make sure to run database migration manually:"
    echo "node server/db-mysql.js"
fi

# Set proper permissions
echo "Setting file permissions..."
chmod 755 .
chmod 644 .env 2>/dev/null || true
chmod +x deploy.sh

echo "Deployment preparation completed!"
echo ""
echo "Next steps:"
echo "1. Edit .env file with your actual database credentials"
echo "2. Run database migration: node server/db-mysql.js"
echo "3. Start the application: npm start"
echo ""
echo "Default admin credentials:"
echo "Username: admin"
echo "Password: admin123"
echo ""
echo "Important: Change admin password after first login!"